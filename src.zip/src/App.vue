<template>
  <div id="app">
    <nav v-if="showNavigation" class="navbar navbar-expand-lg sticky-top">
      <div class="container navbar-container">
        <!-- Left side -->
        <router-link to="/" class="navbar-brand">
          <span class="brand-icon">🎓</span>
          Global Skills Sourcing
        </router-link>

        <!-- Middle navigation -->
        <div class="d-flex nav-middle">
          <router-link v-if="isAdmin && isAuthenticated" to="/admin/dashboard" class="nav-link">
            <span class="nav-icon">🏛️</span>
            Admin
          </router-link>
          <router-link v-if="isAuthenticated" to="/dashboard" class="nav-link">
            <span class="nav-icon">📊</span>
            Dashboard Formateur
          </router-link>
        </div>

        <!-- Right side logout - MOVED TO RIGHT CORNER -->
        <div class="nav-right">
          <button class="btn btn-danger btn-sm" @click="logout">
            <span class="nav-icon">🚪</span>
            Déconnexion
          </button>
        </div>
      </div>
    </nav>

    <main class="main-content" :class="{ 'no-nav': !showNavigation }">
      <router-view />
    </main>
  </div>
</template>

<script>
import { authService } from '@/services/authService'

export default {
  name: 'App',
  computed: {
    isAuthenticated() {
      return authService.isAuthenticated()
    },
    isAdmin() {
      const user = authService.getCurrentUser()
      return user && user.admin
    },
    showNavigation() {
      return this.$route.path !== '/' && this.isAuthenticated
    }
  },
  methods: {
    logout() {
      authService.logout()
      this.$router.push('/')
    }
  }
}
</script>

<style>
.navbar-container {
  display: flex !important;
  justify-content: space-between !important;
  align-items: center !important;
  width: 100% !important;
  position: relative !important;
}

.nav-middle {
  position: absolute !important;
  left: 50% !important;
  transform: translateX(-50%) !important;
}

.nav-right {
  margin-left: auto !important;
}

/* Ensure proper spacing */
.navbar-brand {
  margin-right: auto;
}

.nav-link {
  margin: 0 10px;
}

.btn-danger {
  white-space: nowrap;
}
</style>