import api from './api'

export const formateurService = {
  // Récupérer les infos d'un formateur
  getFormateur(id) {
    return api.get(`/formateurs/${id}`)
  },
  
  // Récupérer les statistiques
  getStats(id) {
    return api.get(`/formateurs/${id}/stats`)
  },
  
  // Récupérer les classes
  getClasses(id) {
    return api.get(`/formateurs/${id}/classes`)
  },
  
  // Récupérer les trajets
  getTrajets(id) {
    return api.get(`/trajets/formateur/${id}`)
  },

  createTrajet(formateurId, trajetData) {
    return api.post(`/trajets/formateur/${formateurId}`, trajetData)
  },

  deleteTrajet(trajetId) {
    return api.delete(`/trajets/${trajetId}`)
  },
  uploadPreuve(trajetId, file) {
    const formData = new FormData()
    formData.append('file', file)
    return api.post(`/preuves/trajet/${trajetId}`, formData, {
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    })
  },

  deletePreuve(preuveId) {
    return api.delete(`/preuves/${preuveId}`)
  }
  
}
