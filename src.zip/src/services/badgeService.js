import api from './api'

export const badgeService = {
  // Récupérer tous les badges
  getAllBadges() {
    return api.get('/badges')
  },
  
  // Récupérer les badges par type
  getBadgesByType(type) {
    return api.get(`/badges/type/${type}`)
  },
  
  // Créer un badge (admin)
  createBadge(badgeData) {
    return api.post('/badges', badgeData)
  },
  
  // Mettre à jour un badge (admin)
  updateBadge(id, badgeData) {
    return api.put(`/badges/${id}`, badgeData)
  },
  
  // Supprimer un badge (admin)
  deleteBadge(id) {
    return api.delete(`/badges/${id}`)
  }
}