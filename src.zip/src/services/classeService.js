import api from './api'

export const classeService = {
  // Récupérer toutes les classes d'un formateur
  getClassesByFormateur(formateurId) {
    return api.get(`/formateurs/${formateurId}/classes`)
  },
  
  // Récupérer une classe spécifique avec détails
  getClasseWithDetails(id) {
    return api.get(`/classes/${id}/with-details`)
  },
  
  // Récupérer toutes les classes (pour admin)
  getAllClasses() {
    return api.get('/classes')
  }
}
