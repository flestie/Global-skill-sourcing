
// Service pour gérer les sessions de formation

import api from './api'

export const sessionService = {
  // Récupérer toutes les sessions
  getAllSessions() {
    return api.get('/sessions')
  },

  // Récupérer les sessions d'une classe
  getSessionsByClasse(classeId) {
    return api.get(`/sessions/classe/${classeId}`)
  },

  // Créer une session
  createSession(data) {
    return api.post('/sessions', data)
  },

  // Mettre à jour une session
  updateSession(id, data) {
    return api.put(`/sessions/${id}`, data)
  },

  // Supprimer une session
  deleteSession(id) {
    return api.delete(`/sessions/${id}`)
  }
}

export default sessionService
