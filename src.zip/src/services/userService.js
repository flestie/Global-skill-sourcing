import api from './api'

export const userService = {
  // Récupérer les classes d'un utilisateur
  async getUserClasses(userId) {
    try {
      const response = await api.get(`/users/${userId}/classes`)
      return response
    } catch (error) {
      console.error('Erreur lors de la récupération des classes:', error)
      // Retourner des données mockées en attendant l'API
      return {
        data: [
          {
            id: 1,
            nom: 'Mathématiques A',
            description: 'Classe de mathématiques avancées',
            nbEleves: 25
          },
          {
            id: 2,
            nom: 'Physique B', 
            description: 'Cours de physique fondamentale',
            nbEleves: 20
          }
        ]
      }
    }
  },

  // Récupérer le profil utilisateur
  async getUserProfile(userId) {
    try {
      const response = await api.get(`/users/${userId}`)
      return response
    } catch (error) {
      console.error('Erreur lors de la récupération du profil:', error)
      throw error
    }
  },

  // Mettre à jour le profil utilisateur
  async updateUserProfile(userId, data) {
    try {
      const response = await api.put(`/users/${userId}`, data)
      return response
    } catch (error) {
      console.error('Erreur lors de la mise à jour du profil:', error)
      throw error
    }
  }
}

export default userService