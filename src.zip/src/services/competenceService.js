import api from './api'

export const competenceService = {
  // 🔹 Récupérer toutes les compétences d'un formateur
  getCompetencesByFormateur(formateurId) {
    return api.get(`/formateurs/${formateurId}/competences`)
  },

  // 🔹 Récupérer toutes les compétences disponibles
  getAllCompetences() {
    return api.get('/competences')
  },

  // 🔹 Ajouter une compétence à un formateur
  addCompetenceToFormateur(formateurId, competenceId) {
    return api.post(`/formateurs/${formateurId}/competences/${competenceId}`)
  },

  // 🔹 Supprimer une compétence d’un formateur (nouvelle fonction)
  removeCompetenceFromFormateur(formateurId, competenceId) {
    console.log('Supprimer clicked for ID:', competenceId)
    return api.delete(`/formateurs/${formateurId}/competences/${competenceId}`)
  },

  // 🔹 Créer une nouvelle compétence (admin)
  createCompetence(competenceData) {
    return api.post('/competences', competenceData)
  }
}
