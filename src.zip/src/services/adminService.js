// src/services/adminService.js
import api from './api'

// Service d'administration : formateurs, classes, formations, écoles, trajets, sessions
const adminService = {
  // ================= FORMATEURS =================
  getAllFormateurs () {
    return api.get('/formateurs')
  },

  createFormateur (formateurData) {
    return api.post('/formateurs', formateurData)
  },

  updateFormateur (id, formateurData) {
    return api.put(`/formateurs/${id}`, formateurData)
  },

  deleteFormateur (id) {
    return api.delete(`/formateurs/${id}`)
  },

  // ================= CLASSES =================
  getAllClasses () {
    return api.get('/classes/with-details')
  },

  createClasse (classeData) {
    return api.post('/classes', classeData)
  },

  updateClasse (id, classeData) {
    return api.put(`/classes/${id}`, classeData)
  },

  deleteClasse (id) {
    return api.delete(`/classes/${id}`)
  },

  // ================= FORMATIONS =================
  getAllFormations () {
    return api.get('/formations')
  },

  createFormation (formationData) {
    // formationData doit avoir la forme :
    // { nom, duree, objectifs, nbParticipantsMax, format }
    return api.post('/formations', formationData)
  },

  updateFormation (id, formationData) {
    return api.put(`/formations/${id}`, formationData)
  },

  deleteFormation (id) {
    return api.delete(`/formations/${id}`)
  },

  // ================= ECOLES =================
  getAllEcoles () {
    return api.get('/ecoles')
  },

  createEcole (ecoleData) {
    return api.post('/ecoles', ecoleData)
  },

  updateEcole (id, ecoleData) {
    return api.put(`/ecoles/${id}`, ecoleData)
  },

  deleteEcole (id) {
    return api.delete(`/ecoles/${id}`)
  },

  // ================= TRAJETS (ADMIN) =================
  // Récupérer les trajets d’un formateur (avec token admin)
  getTrajetsByFormateur (formateurId) {
    return api.get(`/trajets/formateur/${formateurId}`)
  },

  // ================= SESSIONS =================
  getAllSessions () {
    return api.get('/sessions')
  },

  createSession (sessionData) {
    return api.post('/sessions', sessionData)
  },

  updateSession (id, sessionData) {
    return api.put(`/sessions/${id}`, sessionData)
  },

  deleteSession (id) {
    return api.delete(`/sessions/${id}`)
  }
}

// Export nommé + export par défaut
export { adminService }
export default adminService
