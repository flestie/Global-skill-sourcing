// src/services/authService.js
import api from './api'

export const authService = {
  // Se connecter
  async login (credentials) {
    const res = await api.post('/auth/login', credentials)
    const data = res.data

    // Si pas de MFA demandé et qu'on a un token, on stocke l'état d'authentification
    if (!data.mfaRequired && data.token) {
      localStorage.setItem('authToken', data.token)
      localStorage.setItem('user', JSON.stringify(data.user || null))
      localStorage.setItem(
        'mustChangePassword',
        data.mustChangePassword ? '1' : '0'
      )
    }

    return res
  },

  // Se déconnecter
  logout () {
    localStorage.removeItem('authToken')
    localStorage.removeItem('user')
    localStorage.removeItem('mustChangePassword')
  },

  // Récupérer l'utilisateur connecté
  getCurrentUser () {
    try {
      return JSON.parse(localStorage.getItem('user'))
    } catch (e) {
      return null
    }
  },

  // Vérifier si connecté
  isAuthenticated () {
    return !!localStorage.getItem('authToken')
  },

  // Vérifier si l'utilisateur est admin
  isAdmin () {
    const user = this.getCurrentUser()
    return user && user.admin
  },

  // Indique si l'utilisateur doit changer son mot de passe
  mustChangePassword () {
    return localStorage.getItem('mustChangePassword') === '1'
  },

  // Rediriger vers le bon dashboard après login
  // NOTE: si mustChangePassword = true, on force d'abord la page de changement de mot de passe
  redirectAfterLogin () {
    if (this.mustChangePassword()) {
      return '/change-password'
    }

    const user = this.getCurrentUser()
    if (user && user.admin) {
      return '/admin/dashboard'
    }
    return '/dashboard'
  },

  // Changer le mot de passe après une première connexion avec mot de passe temporaire
  async changePassword (oldPassword, newPassword) {
    const token = localStorage.getItem('authToken')

    // Si aucun token → l'utilisateur n'est plus correctement authentifié
    if (!token) {
      // On nettoie l'état local puis on force la reconnexion
      this.logout()
      window.location.href = '/'
      throw new Error('Vous devez vous reconnecter pour changer votre mot de passe.')
    }

    const res = await api.post(
      '/auth/change-password',
      { oldPassword, newPassword },
      {
        headers: {
          Authorization: 'Bearer ' + token
        }
      }
    )

    // Succès → on supprime l’obligation de changer le mot de passe
    localStorage.setItem('mustChangePassword', '0')

    return res
  }
}
