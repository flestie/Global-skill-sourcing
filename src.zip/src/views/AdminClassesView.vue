<template>
  <div class="admin-classes">
    <div class="container-fluid">
      <!-- En-tête de page avec titre et bouton retour -->
      <div class="row mb-4 align-items-center">
        <div class="col">
          <h1>👥 Gestion des Classes</h1>
          <p class="text-muted">
            Créez, modifiez et gérez les classes de formation
          </p>
        </div>
        <div class="col-auto">
          <button
            class="btn btn-outline-secondary"
            @click="$router.push('/admin/dashboard')"
          >
            ← Retour Dashboard
          </button>
        </div>
      </div>

      <!-- Barre d'actions : bouton ajouter + recherche -->
      <div class="row mb-4 align-items-center">
        <div class="col d-flex align-items-center">
          <!-- Bouton pour ouvrir le formulaire de création -->
          <button class="btn btn-primary" style="margin-right: 20px;" @click="showAddForm = true">
          ➕ Créer une Classe
          </button>

          <!-- Champ de recherche pour filtrer les classes -->
          <input
            type="text"
            class="form-control search-input"
            placeholder="Rechercher une classe..."
            v-model="searchTerm"
          />
        </div>
      </div>

      <!-- Section principale : liste des classes -->
      <div class="row">
        <div class="col-12">
          <div class="card shadow-sm border-0">
            <div class="card-body">
              <!-- Indicateur de chargement -->
              <div v-if="loading" class="text-center">
                <div class="spinner-border text-primary" role="status">
                  <span class="visually-hidden">Chargement...</span>
                </div>
              </div>

              <!-- Message si aucune classe -->
              <div
                v-else-if="classes.length === 0"
                class="text-center text-muted"
              >
                <p>Aucune classe créée</p>
                <button class="btn btn-primary" @click="showAddForm = true">
                  Créer la première classe
                </button>
              </div>

              <!-- Tableau des classes -->
              <div v-else>
                <div class="table-responsive">
                  <table class="table table-hover align-middle">
                    <thead class="table-light">
                      <tr>
                        <th>Nom</th>
                        <th>Participants</th>
                        <th>Lieu</th>
                        <th>École</th>
                        <th>Formation</th>
                        <th>Formateur</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      <!-- Boucle sur les classes filtrées -->
                      <tr v-for="classe in filteredClasses" :key="classe.id">
                        <td><strong>{{ classe.nom }}</strong></td>
                        <td>
                          <span class="badge bg-info text-white">{{
                            classe.nbParticipants
                          }}</span>
                        </td>
                        <td>{{ classe.lieu || "Non spécifié" }}</td>
                        <td>
                          <!-- Affichage de l'école associée -->
                          <span v-if="classe.ecole" class="badge bg-secondary">
                            {{ classe.ecole.nom }}
                          </span>
                          <span v-else class="badge bg-light text-dark">
                            Non assignée
                          </span>
                        </td>
                        <td>
                          <!-- Affichage de la formation associée -->
                          <span
                            v-if="classe.formation"
                            class="badge bg-primary"
                          >
                            {{ classe.formation.nom }}
                          </span>
                          <span v-else class="badge bg-light text-dark">
                            Non assignée
                          </span>
                        </td>
                        <td>
                          <!-- Affichage du formateur associé -->
                          <span
                            v-if="classe.formateur"
                            class="badge bg-warning text-dark"
                          >
                            {{ classe.formateur.prenom }}
                            {{ classe.formateur.nom }}
                          </span>
                          <span v-else class="badge bg-light text-dark">
                            Non assigné
                          </span>
                        </td>
                        <td>
                          <!-- Boutons d'actions -->
                          <button
                            class="btn btn-sm btn-outline-primary me-1"
                            @click="viewClasseDetails(classe)"
                            title="Voir les détails"
                          >
                            🔍
                          </button>
                          <button
                            class="btn btn-sm btn-outline-secondary me-1"
                            @click="editClasse(classe)"
                            title="Modifier"
                          >
                            ✏️
                          </button>
                          <button
                            class="btn btn-sm btn-outline-danger"
                            @click="deleteClasse(classe.id)"
                            title="Supprimer"
                          >
                            🗑️
                          </button>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Modal pour afficher les détails d'une classe -->
      <div
        v-if="selectedClasse"
        class="modal fade show d-block"
        style="background-color: rgba(255, 255, 255, 0.3)"
      >
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">
                Détails de la Classe: {{ selectedClasse.nom }}
              </h5>
              <button
                type="button"
                class="btn-close"
                @click="selectedClasse = null"
              ></button>
            </div>
            <div class="modal-body">
              <div class="row">
                <!-- Colonne informations générales -->
                <div class="col-md-6">
                  <h6>Informations Générales</h6>
                  <p><strong>Nom:</strong> {{ selectedClasse.nom }}</p>
                  <p>
                    <strong>Participants:</strong>
                    {{ selectedClasse.nbParticipants }}
                  </p>
                  <p>
                    <strong>Lieu:</strong>
                    {{ selectedClasse.lieu || "Non spécifié" }}
                  </p>
                </div>
                <!-- Colonne relations (école, formation, formateur) -->
                <div class="col-md-6">
                  <h6>Relations</h6>
                  <p v-if="selectedClasse.ecole">
                    <strong>École:</strong> {{ selectedClasse.ecole.nom }}
                  </p>
                  <p v-if="selectedClasse.formation">
                    <strong>Formation:</strong>
                    {{ selectedClasse.formation.nom }}<br />
                    <small class="text-muted">
                      Durée: {{ selectedClasse.formation.duree }}h - Format:
                      {{ selectedClasse.formation.format }}
                    </small>
                  </p>
                  <p v-if="selectedClasse.formateur">
                    <strong>Formateur:</strong>
                    {{ selectedClasse.formateur.prenom }}
                    {{ selectedClasse.formateur.nom }}<br />
                    <small class="text-muted">
                      Email: {{ selectedClasse.formateur.email }}
                    </small>
                  </p>
                </div>
              </div>

              <!-- Section compétences du formateur -->
              <div
                v-if="
                  selectedClasse.formateur &&
                  selectedClasse.formateur.competences
                "
                class="mt-3"
              >
                <h6>Compétences du Formateur</h6>
                <div>
                  <span
                    v-for="competence in selectedClasse.formateur.competences"
                    :key="competence.id"
                    class="badge bg-primary me-1 mb-1"
                  >
                    {{ competence.nom }}
                  </span>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <button
                type="button"
                class="btn btn-secondary"
                @click="selectedClasse = null"
              >
                Fermer
              </button>
            </div>
          </div>
        </div>
      </div>

      <!-- Modal pour ajouter ou modifier une classe -->
      <div
        v-if="showAddForm || editingClasse"
        class="modal fade show d-block"
        style="background-color: rgba(255, 255, 255, 0.3)"
      >
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">
                {{ editingClasse ? "Modifier la Classe" : "Créer une Classe" }}
              </h5>
              <button
                type="button"
                class="btn-close"
                @click="closeModal"
              ></button>
            </div>
            <div class="modal-body">
              <!-- Formulaire de création/modification -->
              <form @submit.prevent="saveClasse">
                <div class="row">
                  <div class="col-md-6 mb-3">
                    <label class="form-label">Nom de la classe *</label>
                    <input
                      type="text"
                      class="form-control"
                      v-model="classeForm.nom"
                      required
                      placeholder="Ex: Classe Java Débutant"
                    />
                  </div>
                  <div class="col-md-6 mb-3">
                    <label class="form-label">Nombre de participants *</label>
                    <input
                      type="number"
                      class="form-control"
                      v-model="classeForm.nbParticipants"
                      min="7"
                      max="50"
                      required
                    />
                    <small class="text-muted">Entre 7 et 50 participants</small>
                  </div>
                </div>

                <div class="mb-3">
                  <label class="form-label">Lieu</label>
                  <input
                    type="text"
                    class="form-control"
                    v-model="classeForm.lieu"
                    placeholder="Ex: Salle 101, Bâtiment A"
                  />
                </div>

                <div class="row">
                  <!-- Sélection de l'école -->
                  <div class="col-md-4 mb-3">
                    <label class="form-label">École *</label>
                    <select
                      class="form-select"
                      v-model="classeForm.ecoleId"
                      required
                    >
                      <option value="">Sélectionnez une école</option>
                      <option
                        v-for="ecole in ecoles"
                        :key="ecole.id"
                        :value="ecole.id"
                      >
                        {{ ecole.nom }}
                      </option>
                    </select>
                  </div>

                  <!-- Sélection de la formation -->
                  <div class="col-md-4 mb-3">
                    <label class="form-label">Formation *</label>
                    <select
                      class="form-select"
                      v-model="classeForm.formationId"
                      required
                    >
                      <option value="">Sélectionnez une formation</option>
                      <option
                        v-for="formation in formations"
                        :key="formation.id"
                        :value="formation.id"
                      >
                        {{ formation.nom }} ({{ formation.duree }}h)
                      </option>
                    </select>
                  </div>

                  <!-- Sélection du formateur -->
                  <div class="col-md-4 mb-3">
                    <label class="form-label">Formateur *</label>
                    <select
                      class="form-select"
                      v-model="classeForm.formateurId"
                      required
                    >
                      <option value="">Sélectionnez un formateur</option>
                      <option
                        v-for="formateur in formateurs"
                        :key="formateur.id"
                        :value="formateur.id"
                      >
                        {{ formateur.prenom }} {{ formateur.nom }}
                      </option>
                    </select>
                  </div>
                </div>

                <div class="mb-3">
                  <small class="text-muted">* Champs obligatoires</small>
                </div>

                <!-- Messages de succès/erreur -->
                <div v-if="message" class="alert alert-success">
                  {{ message }}
                </div>
                <div v-if="error" class="alert alert-danger">
                  {{ error }}
                </div>
              </form>
            </div>
            <div class="modal-footer">
              <button
                type="button"
                class="btn btn-secondary"
                @click="closeModal"
              >
                Annuler
              </button>
              <button
                type="button"
                class="btn btn-primary"
                @click="saveClasse"
                :disabled="saving"
              >
                {{
                  saving
                    ? "Sauvegarde..."
                    : editingClasse
                    ? "Modifier"
                    : "Créer"
                }}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
// Import du service administrateur pour les appels API
import { adminService } from '@/services/adminService'

export default {
  name: 'AdminClassesView',
  data() {
    return {
      classes: [], // Liste de toutes les classes
      ecoles: [], // Liste des écoles disponibles
      formations: [], // Liste des formations disponibles
      formateurs: [], // Liste des formateurs disponibles
      loading: false, // État de chargement
      saving: false, // État de sauvegarde
      showAddForm: false, // Affichage du formulaire d'ajout
      editingClasse: null, // Classe en cours d'édition
      selectedClasse: null, // Classe sélectionnée pour détails
      searchTerm: '', // Terme de recherche
      message: '', // Message de succès
      error: '', // Message d'erreur
      // Formulaire pour créer/modifier une classe
      classeForm: {
        nom: '',
        nbParticipants: 7,
        lieu: '',
        ecoleId: '',
        formationId: '',
        formateurId: ''
      }
    }
  },
  computed: {
    /**
     * Filtre les classes selon le terme de recherche
     * Recherche dans le nom, l'école, la formation et le formateur
     */
    filteredClasses() {
      if (!this.searchTerm) return this.classes
      const term = this.searchTerm.toLowerCase()
      return this.classes.filter(
        (classe) =>
          classe.nom.toLowerCase().includes(term) ||
          (classe.ecole && classe.ecole.nom.toLowerCase().includes(term)) ||
          (classe.formation &&
            classe.formation.nom.toLowerCase().includes(term)) ||
          (classe.formateur &&
            (classe.formateur.nom.toLowerCase().includes(term) ||
              classe.formateur.prenom.toLowerCase().includes(term)))
      )
    }
  },
  /**
   * Hook de cycle de vie : chargement des données au montage du composant
   */
  async mounted() {
    await this.loadAllData()
  },
  methods: {
    /**
     * Charge toutes les données nécessaires depuis l'API
     * Classes, écoles, formations et formateurs
     */
    async loadAllData() {
      this.loading = true
      try {
        // Appels API parallèles pour optimiser le chargement
        const [classesRes, ecolesRes, formationsRes, formateursRes] =
          await Promise.all([
            adminService.getAllClasses(),
            adminService.getAllEcoles(),
            adminService.getAllFormations(),
            adminService.getAllFormateurs()
          ])
        this.classes = classesRes.data
        this.ecoles = ecolesRes.data
        this.formations = formationsRes.data
        this.formateurs = formateursRes.data
      } catch (error) {
        console.error('Erreur chargement données:', error)
        this.error = 'Erreur lors du chargement des données'
      } finally {
        this.loading = false
      }
    },

    /**
     * Affiche les détails d'une classe dans une modal
     * @param {Object} classe - La classe à afficher
     */
    viewClasseDetails(classe) {
      this.selectedClasse = classe
    },

    /**
     * Ouvre le formulaire d'édition pour une classe
     * Pré-remplit le formulaire avec les données de la classe
     * @param {Object} classe - La classe à modifier
     */
    editClasse(classe) {
      this.editingClasse = classe
      this.classeForm = {
        nom: classe.nom,
        nbParticipants: classe.nbParticipants,
        lieu: classe.lieu,
        ecoleId: classe.ecole ? classe.ecole.id : '',
        formationId: classe.formation ? classe.formation.id : '',
        formateurId: classe.formateur ? classe.formateur.id : ''
      }
    },

    /**
     * Sauvegarde une nouvelle classe ou les modifications d'une classe existante
     * Appelle l'API puis recharge les données
     */
    async saveClasse() {
      this.saving = true
      this.message = ''
      this.error = ''
      try {
        if (this.editingClasse) {
          // Modification d'une classe existante
          await adminService.updateClasse(this.editingClasse.id, this.classeForm)
          this.message = 'Classe modifiée avec succès!'
        } else {
          // Création d'une nouvelle classe
          await adminService.createClasse(this.classeForm)
          this.message = 'Classe créée avec succès!'
        }
        // Rechargement des données après sauvegarde
        await this.loadAllData()
        // Fermeture automatique après un délai
        setTimeout(() => {
          this.closeModal()
        }, 1500)
      } catch (error) {
        console.error('Erreur sauvegarde classe:', error)
        this.error =
          'Erreur lors de la sauvegarde: ' +
          (error.response?.data || error.message)
      } finally {
        this.saving = false
      }
    },

    /**
     * Supprime une classe après confirmation
     * @param {number} classeId - ID de la classe à supprimer
     */
    async deleteClasse(classeId) {
      if (confirm('Êtes-vous sûr de vouloir supprimer cette classe ?')) {
        try {
          await adminService.deleteClasse(classeId)
          this.message = 'Classe supprimée avec succès!'
          await this.loadAllData()
        } catch (error) {
          console.error('Erreur suppression classe:', error)
          this.error =
            'Erreur lors de la suppression: ' +
            (error.response?.data || error.message)
        }
      }
    },

    /**
     * Ferme tous les modals et réinitialise les formulaires
     */
    closeModal() {
      this.showAddForm = false
      this.editingClasse = null
      this.selectedClasse = null
      // Réinitialisation du formulaire
      this.classeForm = {
        nom: '',
        nbParticipants: 7,
        lieu: '',
        ecoleId: '',
        formationId: '',
        formateurId: ''
      }
      this.message = ''
      this.error = ''
    }
  }
}
</script>

<style scoped>
/* Styles principaux de la page */
.admin-classes {
  padding: 20px;
  min-height: 100vh;
  background: #f4f6f9;
  font-family: "Inter", sans-serif;
}

h1 {
  font-weight: 600;
  color: #2c3e50;
}

/* Styles des boutons */
.btn-primary {
  background-color: #5c7cfa;
  border: none;
}

.btn-primary:hover {
  background-color: #4c6ef5;
}

.btn-outline-secondary {
  border-color: #ced4da;
  color: #495057;
}

.btn-outline-secondary:hover {
  background-color: #e9ecef;
  color: #212529;
}

/* Styles des cartes */
.card {
  border-radius: 12px;
  background-color: #ffffff;
}

/* Styles du tableau */
.table th {
  font-weight: 600;
  color: #8c97a1;
}

.badge {
  border-radius: 8px;
  font-size: 0.8rem;
  padding: 0.4em 0.6em;
}

/* Style du champ de recherche */
.search-input {
  width: 280px;
  border-radius: 10px;
  border: 1px solid #ced4da;
  padding: 0.5rem 0.75rem;
  transition: all 0.2s ease;
}

.search-input:focus {
  border-color: #5c7cfa;
  box-shadow: 0 0 0 0.15rem rgba(92, 124, 250, 0.25);
}

/* Effet de survol sur les lignes du tableau */
.table-hover tbody tr:hover {
  background-color: #f1f3f5;
}

/* Styles pour un tableau bien aligné */
.table {
  width: 100%;
  border-collapse: collapse;
  table-layout: fixed; /* Maintient la consistance des colonnes */
}

/* Alignement parfait des en-têtes et cellules */
.table th,
.table td {
  padding: 12px 16px; /* Padding identique */
  text-align: left;
  vertical-align: middle; /* Centre le texte verticalement */
}

/* Style distinct pour les en-têtes */
.table thead th {
  background-color: #f1f3f5;
  font-weight: 600;
  text-transform: uppercase;
  font-size: 0.9rem;
  color: #495057;
  border-bottom: 2px solid #dee2e6;
}

/* Suppression des espaces de bordure supplémentaires */
.table tr {
  border-bottom: 1px solid #dee2e6;
}

/* Alignement horizontal des boutons et badges */
.table td .btn {
  vertical-align: middle;
  margin: 0 2px;
}

/* Empêche le badge d'ajouter de la hauteur */
.table td .badge {
  vertical-align: middle;
  margin: 0;
}

/* Optionnel : garde le tableau compact et net */
.table tbody tr:last-child {
  border-bottom: none;
}
</style>