<template>
  <div class="classes">
    <div class="container">
      <!-- En-tête de page avec titre et bouton retour -->
      <div class="row mb-4">
        <div class="col">
          <h1>Mes Classes</h1>
        </div>
        <div class="col-auto">
          <button class="btn btn-secondary" @click="$router.push('/dashboard')">
            ← Retour Dashboard
          </button>
        </div>
      </div>

      <!-- Section principale : liste des classes -->
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-body">
              <!-- Indicateur de chargement -->
              <div v-if="loading" class="text-center">
                <div class="spinner-border" role="status">
                  <span class="visually-hidden">Chargement...</span>
                </div>
              </div>

              <!-- Message si aucune classe assignée -->
              <div
                v-else-if="classes.length === 0"
                class="text-center text-muted"
              >
                <p>Aucune classe assignée</p>
              </div>

              <!-- Tableau des classes -->
              <div v-else>
                <div class="table-responsive">
                  <table class="table table-hover">
                    <thead>
                      <tr>
                        <th>Nom</th>
                        <th>Participants</th>
                        <th>Lieu</th>
                        <th>École</th>
                        <th>Formation</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      <!-- Boucle sur les classes du formateur -->
                      <tr v-for="classe in classes" :key="classe.id">
                        <td>{{ classe.nom }}</td>
                        <td>{{ classe.nbParticipants }}</td>
                        <td>{{ classe.lieu }}</td>
                        <td>
                          <!-- Badge de l'école -->
                          <span v-if="classe.ecole" class="badge bg-primary">
                            {{ classe.ecole.nom }}
                          </span>
                          <span v-else class="text-muted">Non assignée</span>
                        </td>
                        <td>
                          <!-- Badge de la formation -->
                          <span v-if="classe.formation" class="badge bg-info">
                            {{ classe.formation.nom }}
                          </span>
                          <span v-else class="text-muted">Non assignée</span>
                        </td>
                        <td>
                          <!-- Bouton pour voir les détails -->
                          <button
                            class="btn btn-sm btn-outline-primary"
                            @click="viewClasseDetails(classe.id)"
                          >
                            Détails
                          </button>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Modal pour afficher les détails d'une classe -->
      <div
        v-if="selectedClasse"
        class="modal fade show d-block"
        style="background-color: white"
      >
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Détails de la Classe</h5>
              <button
                type="button"
                class="btn-close"
                @click="selectedClasse = null"
              ></button>
            </div>
            <div class="modal-body">
              <div v-if="selectedClasse">
                <div class="row">
                  <!-- Colonne informations générales -->
                  <div class="col-md-6">
                    <h6>Informations Générales</h6>
                    <p><strong>Nom:</strong> {{ selectedClasse.nom }}</p>
                    <p>
                      <strong>Participants:</strong>
                      {{ selectedClasse.nbParticipants }}
                    </p>
                    <p><strong>Lieu:</strong> {{ selectedClasse.lieu }}</p>
                  </div>
                  <!-- Colonne relations (école, formation, formateur) -->
                  <div class="col-md-6">
                    <p v-if="selectedClasse.ecole">
                      <strong>École:</strong> {{ selectedClasse.ecole.nom }}
                    </p>
                    <p v-if="selectedClasse.formation">
                      <strong>Formation:</strong>
                      {{ selectedClasse.formation.nom }}<br />
                      <small class="text-muted">
                        Durée: {{ selectedClasse.formation.duree }}h - Format:
                        {{ selectedClasse.formation.format }}
                      </small>
                    </p>
                    <p v-if="selectedClasse.formateur">
                      <strong>Formateur:</strong>
                      {{ selectedClasse.formateur.prenom }}
                      {{ selectedClasse.formateur.nom }}
                    </p>
                  </div>
                </div>

                <!-- Section compétences du formateur -->
                <div
                  v-if="
                    selectedClasse.formateur &&
                    selectedClasse.formateur.competences
                  "
                  class="mt-3"
                >
                  <h6>Compétences du Formateur</h6>
                  <div>
                    <!-- Boucle sur les compétences -->
                    <span
                      v-for="competence in selectedClasse.formateur.competences"
                      :key="competence.id"
                      class="badge bg-success me-4 mb-1"
                    >
                      {{ competence.nom }}
                    </span>
                  </div>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <button
                type="button"
                class="btn btn-secondary"
                @click="selectedClasse = null"
              >
                Fermer
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { authService } from '@/services/authService'
import { classeService } from '@/services/classeService'

export default {
  name: 'ClassesView',
  data() {
    return {
      user: {}, // Utilisateur connecté
      classes: [], // Liste des classes assignées
      selectedClasse: null, // Classe sélectionnée pour détails
      loading: false // État de chargement
    }
  },
  /**
   * Hook de cycle de vie : chargement des données au montage
   */
  async mounted() {
    // Récupération de l'utilisateur connecté
    this.user = authService.getCurrentUser()
    if (!this.user) {
      this.$router.push('/')
      return
    }
    // Chargement des classes du formateur
    await this.loadClasses()
  },
  methods: {
    /**
     * Charge les classes assignées au formateur connecté
     */
    async loadClasses() {
      this.loading = true
      try {
        const response = await classeService.getClassesByFormateur(
          this.user.formateur.id
        )
        this.classes = response.data
      } catch (error) {
        console.error('Erreur chargement classes:', error)
        this.classes = []
      } finally {
        this.loading = false
      }
    },

    /**
     * Affiche les détails d'une classe spécifique
     * @param {number} classeId - ID de la classe à afficher
     */
    async viewClasseDetails(classeId) {
      try {
        const response = await classeService.getClasseWithDetails(classeId)
        this.selectedClasse = response.data
      } catch (error) {
        console.error('Erreur chargement détails:', error)
        alert('Erreur lors du chargement des détails')
      }
    }
  }
}
</script>

<style scoped>
/* Conteneur principal de la page */
.classes {
  padding: 20px 0;
  min-height: 100vh;
  background-color: #f8f9fa;
}

/* Conteneur fluide prenant toute la largeur */
.container {
  max-width: 100% !important;
  padding: 0 30px;
  margin: 0;
}

/* Section d'en-tête avec marge cohérente */
.header-section {
  margin-left: 5%; /* Marge alignée avec l'intérieur du tableau */
  margin-bottom: 0;
}

/* Style du titre principal */
.page-title {
  font-weight: 600;
  margin-bottom: 0;
}

/* Configuration de base du tableau */
.table {
  width: 100%;
  border-collapse: collapse;
  margin-bottom: 0;
}

/* Conteneur responsive du tableau */
.table-responsive{
  width: 100%;
}

/* Alignement des cellules du tableau */
.table th,
.table td {
  vertical-align: middle !important;
  text-align: left;
  padding: 14px 20px;
}

/* Style de l'en-tête du tableau - bleu pastel */
.table thead th {
  background-color: #d8e6f3;
  color: #0c3557;
  font-weight: 600;
  text-transform: uppercase;
  border-bottom: 2px solid #c4d6e6;
}

/* Style des cellules du corps du tableau */
.table tbody td {
  background-color: #ffffff;
  color: #1f1f1f;
  transition: background-color 0.2s ease-in-out; /* Transition fluide */
}

/* Effet de survol bleu clair sur les lignes du tableau */
.table tbody tr:hover td {
  background-color: #e3f2fd !important; /* Bleu clair au survol */
  cursor: pointer;
}

/* Ajustement des bords gauche des cellules */
.table th:first-child,
.table td:first-child {
  padding-left: 30px;
}

/* Style de la carte contenant le tableau */
.card {
  border-radius: 0;
  border: none;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
  margin: 0;
  width: 100%;
}

/* Style du bouton "Détails" avec effet de transition */
.btn-outline-primary {
  border-width: 1.5px;
  transition: all 0.2s ease-in-out;
}

/* États actif et focus du bouton "Détails" */
.btn-outline-primary:active,
.btn-outline-primary:focus {
  background-color: rgba(0, 123, 255, 0.12) !important;
  color: #0a58ca !important;
  border-color: #0a58ca !important;
}

/* Style du bouton secondaire (Retour) */
.btn-secondary {
  background-color: #13558b !important;
  color: white !important;
  border: none !important;
}

/* Effet au survol du bouton secondaire */
.btn-secondary:hover {
  background-color: #0c3557 !important;
  color: white !important;
  border: none !important;
}

/* ---------- STYLES DES MODALS ---------- */

/* Taille et poids du titre du modal */
.modal-title {
  font-size: 1.5rem;   /* Taille de police augmentée */
  font-weight: 700;  /* Poids de police renforcé */
}

/* Arrière-plan de l'overlay du modal */
.modal-overlay {
  background-color: rgba(222, 222, 226, 0.923) !important;
  backdrop-filter: blur(4px);
  transition: background-color 0.3s ease;
}

/* Style du contenu du modal */
.modal-content {
  border-radius: 12px;
  background-color: rgba(237, 240, 242, 0.941);
  box-shadow: none;
}

/* Style de l'en-tête et du pied du modal */
.modal-header,
.modal-footer {
  background-color: rgba(246, 247, 250, 0.526);
}

/* Style du corps du modal */
.modal-body {
  color: #212529;
  background: transparent;
}

/* Style du texte secondaire dans le modal */
.modal-body small.text-muted {
  color: #212529 !important;
  opacity: 0.9 !important;
}

/* Style des badges de compétences */
.badge {
  font-size: 0.85rem;
  border-radius: 6px;
  border-right: 20rem;
  margin: 0.25rem;
}
</style>