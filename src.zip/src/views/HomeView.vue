<template>
  <div class="login-container">
    <!-- Simple Header -->
    <div class="login-header">
      <h1 class="website-title">Global Skills Sourcing</h1>
    </div>

    <!-- Login Form -->
    <div class="row justify-content-center">
      <div class="col-md-6 col-lg-5">
        <div class="card shadow-lg border-0 rounded-3">
          <div
            class="card-header text-center text-white py-4"
            :style="{
              background:
                'linear-gradient(135deg, var(--primary-600), var(--primary-700))'
            }"
          >
            <h2 class="mb-0">🔐 Connexion</h2>
          </div>
          <div class="card-body p-4">
            <form @submit.prevent="login">
              <!-- Email -->
              <div class="mb-3">
                <input
                  type="email"
                  class="form-control rounded-2"
                  v-model="credentials.email"
                  required
                  placeholder="Adresse email"
                />
              </div>

              <!-- Password -->
              <div class="mb-3">
                <input
                  type="password"
                  class="form-control rounded-2"
                  v-model="credentials.password"
                  required
                  placeholder="Mot de passe"
                />
              </div>

              <!-- Submit -->
            <div class="buttons-container"></div>
              <button
                type="submit"
                class="btn btn-primary btn-lg"
                :disabled="loading"
              >
                <span v-if="loading">Connexion...</span>
                <span v-else>Se connecter</span>
              </button>

              <!-- Forgot Password (full width) -->
              <button
                type="button"
                class="btn btn-outline-secondary btn-lg forgot-btn"
                @click="forgotPassword"
              >
                Mot de passe oublié ?
              </button>
            </form>
          
            <!-- Error -->
            <div v-if="error" class="alert alert-danger mt-3 rounded-2">
              {{ error }}
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { authService } from '@/services/authService'

export default {
  name: 'LoginView',
  data() {
    return {
      credentials: {
        email: '',
        password: ''
      },
      loading: false,
      error: ''
    }
  },
  methods: {
    async login() {
      this.loading = true
      this.error = ''

      try {
        const response = await authService.login(this.credentials)

        localStorage.setItem('authToken', response.data.token)
        localStorage.setItem('user', JSON.stringify(response.data.user))

        if (response.data.user && response.data.user.admin) {
          this.$router.push('/admin/dashboard')
        } else {
          this.$router.push('/dashboard')
        }
      } catch (error) {
        this.error =
          error.response?.data?.message ||
          'Erreur de connexion. Vérifiez vos identifiants.'
      } finally {
        this.loading = false
      }
    },

    forgotPassword() {
      alert('Fonctionnalité de réinitialisation de mot de passe à implémenter')
    }
  }
}
</script>

<style scoped>
.login-container {
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
  padding: 20px;
}

.login-header {
  margin-bottom: 3rem;
  text-align: center;
}

.website-title {
  font-size: 2.5rem;
  font-weight: 700;
  color: var(--primary-700);
  margin: 0;
  text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.card {
  border-radius: 1rem;
  border: none;
  width: 100%;
}

.card-header h2 {
  font-weight: 600;
}

.form-control {
  padding: 0.9rem 1rem;
  border: 1px solid #dee2e6;
  transition: all 0.2s ease;
  width: 100%;
  height: 3.2rem; /* ensures same height as buttons */
}

.form-control:focus {
  border-color: var(--primary-600);
  box-shadow: 0 0 0 0.2rem rgba(37, 99, 235, 0.25);
}

.btn {
  font-weight: 500;
  letter-spacing: 0.5px;
  transition: all 0.2s ease;
  padding: 0.75rem 1rem;
  height: 3.2rem; /* same height as inputs */
}

.btn-primary {
  font-size: 1rem;
  background: linear-gradient(135deg, var(--primary-500), var(--primary-600));
  border: none;
  margin-right: 1rem;
}

.btn-primary:hover {
  background: linear-gradient(135deg, var(--primary-600), var(--primary-700));
}

.btn-outline-secondary {
  border: 1px solid #d1d5db;
  background: #f9fafc;
  color: #374151;
}

.btn-outline-secondary:hover {
  background: #e5e7eb;
  color: #111827;
}

.alert {
  border: none;
  font-size: 0.9rem;
  text-align: center;
}

/* Responsive design */
@media (max-width: 768px) {
  .website-title {
    font-size: 2rem;
  }

  .login-header {
    margin-bottom: 2rem;
  }
}
</style>
