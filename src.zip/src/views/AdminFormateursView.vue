<template>
  <div class="admin-formateurs">
    <div class="container-fluid">
      <!-- En-tête de page -->
      <div class="row mb-4 align-items-center">
        <div class="col">
          <h1>👨‍🏫 Gestion des Formateurs</h1>
          <p class="text-muted">
            Créez, modifiez et gérez les formateurs
          </p>
        </div>
        <div class="col-auto">
          <button
            class="btn btn-outline-secondary"
            @click="$router.push('/admin/dashboard')"
          >
            ← Retour Dashboard
          </button>
        </div>
      </div>

      <!-- Barre d'actions : bouton ajouter + recherche -->
      <div class="row mb-4 align-items-center">
        <div class="col d-flex align-items-center">
          <!-- Bouton pour ajouter un formateur -->
          <button
            class="btn btn-primary"
            style="margin-right: 20px;"
            @click="showAddForm = true"
          >
            ➕ Ajouter un Formateur
          </button>
          <!-- Champ de recherche -->
          <input
            type="text"
            class="form-control search-input"
            placeholder="Rechercher un formateur..."
            v-model="searchTerm"
          />
        </div>
      </div>

      <!-- Section chargement -->
      <div v-if="loading" class="text-center py-5">
        <div class="spinner-border text-primary" role="status">
          <span class="visually-hidden">Chargement...</span>
        </div>
      </div>

      <!-- Contenu principal -->
      <div v-else>
        <!-- Message si aucun formateur trouvé -->
        <div
          v-if="filteredFormateurs.length === 0"
          class="text-center text-muted"
        >
          <p>Aucun formateur trouvé</p>
        </div>

        <!-- Grille des formateurs -->
        <div v-else class="row">
          <!-- Carte formateur -->
          <div
            class="col-md-4 mb-4"
            v-for="formateur in filteredFormateurs"
            :key="formateur.id"
          >
            <div class="card shadow-sm border-0 h-100">
              <div class="card-body d-flex flex-column justify-content-between">
                <!-- Informations du formateur -->
                <div>
                  <h5 class="card-title mb-1">
                    {{ formateur.nom }} {{ formateur.prenom }}
                  </h5>
                  <p class="text-muted small mb-1">
                    📧 {{ formateur.email }}
                  </p>
                  <p class="text-muted small mb-1">
                    📞 {{ formateur.telephone }}
                  </p>
                  <p class="text-muted small mb-0">
                    📍 {{ formateur.ville }} {{ formateur.codePostal }}
                  </p>
                </div>

                <!-- Boutons d'actions -->
                <div class="mt-3 d-flex gap-2">
                  <!-- Voir les trajets + preuves du formateur -->
                  <button
                    class="btn btn-sm btn-outline-secondary"
                    @click="openTrajetsModal(formateur)"
                    title="Voir les trajets et preuves"
                  >
                    🚗 Trajets
                  </button>

                  <!-- Modifier le formateur -->
                  <button
                    class="btn btn-sm btn-outline-primary"
                    @click="editFormateur(formateur)"
                    title="Modifier"
                  >
                    ✏️
                  </button>

                  <!-- Supprimer le formateur -->
                  <button
                    class="btn btn-sm btn-outline-danger"
                    @click="deleteFormateur(formateur.id)"
                    title="Supprimer"
                  >
                    🗑️
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Modal Ajouter/Modifier Formateur -->
      <div
        v-if="showAddForm || editingFormateur"
        class="modal fade show d-block"
        style="background-color: rgba(255, 255, 255, 0.3);"
      >
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <!-- En-tête du modal -->
            <div class="modal-header">
              <h5 class="modal-title">
                {{ editingFormateur ? 'Modifier le Formateur' : 'Ajouter un Formateur' }}
              </h5>
              <button
                type="button"
                class="btn-close"
                @click="closeModal"
              ></button>
            </div>

            <!-- Corps du modal -->
            <div class="modal-body">
              <form @submit.prevent="saveFormateur">
                <!-- Ligne nom et prénom -->
                <div class="row">
                  <div class="col-md-6 mb-3">
                    <label class="form-label">Nom *</label>
                    <input
                      type="text"
                      class="form-control"
                      v-model="formateurForm.nom"
                      required
                    />
                  </div>
                  <div class="col-md-6 mb-3">
                    <label class="form-label">Prénom *</label>
                    <input
                      type="text"
                      class="form-control"
                      v-model="formateurForm.prenom"
                      required
                    />
                  </div>
                </div>

                <!-- Ligne email et téléphone -->
                <div class="row">
                  <div class="col-md-6 mb-3">
                    <label class="form-label">Email *</label>
                    <input
                      type="email"
                      class="form-control"
                      v-model="formateurForm.email"
                      required
                    />
                  </div>
                  <div class="col-md-6 mb-3">
                    <label class="form-label">Téléphone *</label>
                    <input
                      type="tel"
                      class="form-control"
                      v-model="formateurForm.telephone"
                      required
                    />
                  </div>
                </div>

                <!-- Ligne ville et code postal -->
                <div class="row">
                  <div class="col-md-6 mb-3">
                    <label class="form-label">Ville</label>
                    <input
                      type="text"
                      class="form-control"
                      v-model="formateurForm.ville"
                    />
                  </div>
                  <div class="col-md-6 mb-3">
                    <label class="form-label">Code Postal</label>
                    <input
                      type="text"
                      class="form-control"
                      v-model="formateurForm.codePostal"
                    />
                  </div>
                </div>

                <!-- 🔐 Mot de passe temporaire (uniquement à la création) -->
                <div class="row" v-if="!editingFormateur">
                  <div class="col-md-12 mb-3">
                    <label class="form-label">
                      Mot de passe temporaire (optionnel)
                    </label>
                    <input
                      type="password"
                      class="form-control"
                      v-model="temporaryPassword"
                      placeholder="Ex: Temp@2025 (min. 8 caractères)"
                    />
                    <small class="text-muted">
                      Ce mot de passe sera utilisé lors de la première connexion du formateur.
                      Il devra ensuite le modifier.
                    </small>
                  </div>
                </div>

                <!-- Messages de statut -->
                <div v-if="message" class="alert alert-success">
                  {{ message }}
                </div>
                <div v-if="error" class="alert alert-danger">
                  {{ error }}
                </div>
              </form>
            </div>

            <!-- Pied du modal -->
            <div class="modal-footer">
              <button
                type="button"
                class="btn btn-secondary"
                @click="closeModal"
              >
                Annuler
              </button>
              <button
                type="button"
                class="btn btn-primary"
                @click="saveFormateur"
                :disabled="saving"
              >
                {{ saving ? 'Sauvegarde...' : editingFormateur ? 'Modifier' : 'Créer' }}
              </button>
            </div>
          </div>
        </div>
      </div>

      <!-- Modal : trajets + preuves d'un formateur -->
      <div
        v-if="showTrajetsModal && selectedFormateur"
        class="modal fade show d-block"
        style="background-color: rgba(0, 0, 0, 0.4);"
      >
        <div class="modal-dialog modal-xl">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">
                Trajets de {{ selectedFormateur.nom }} {{ selectedFormateur.prenom }}
              </h5>
              <button type="button" class="btn-close" @click="closeTrajetsModal"></button>
            </div>

            <div class="modal-body">
              <!-- Etat de chargement des trajets -->
              <div v-if="loadingTrajets" class="text-center py-4">
                <div class="spinner-border text-primary" role="status">
                  <span class="visually-hidden">Chargement...</span>
                </div>
              </div>

              <!-- Aucun trajet -->
              <div v-else-if="trajetsFormateur.length === 0" class="text-muted">
                Aucun trajet enregistré pour ce formateur.
              </div>

              <!-- Liste des trajets -->
              <div v-else>
                <div
                  v-for="trajet in trajetsFormateur"
                  :key="trajet.id"
                  class="mb-3 p-3 border rounded bg-light"
                >
                  <div class="d-flex justify-content-between">
                    <div>
                      <strong>{{ trajet.villeDepart }} → {{ trajet.villeArrivee }}</strong>
                      <span class="text-muted ms-2">({{ trajet.distance }} km)</span>
                      <div v-if="trajet.correspondances" class="small text-muted">
                        📋 {{ trajet.correspondances }}
                      </div>

                      <!-- Badges utilisés -->
                      <div
                        v-if="trajet.badgesUtilises && trajet.badgesUtilises.length > 0"
                        class="mt-1"
                      >
                        <span
                          v-for="badge in trajet.badgesUtilises"
                          :key="badge"
                          class="badge bg-primary text-white me-1"
                        >
                          {{ badge }}
                        </span>
                      </div>
                    </div>
                  </div>

                  <!-- Preuves (fichiers) -->
                  <div
                    v-if="trajet.preuves && trajet.preuves.length > 0"
                    class="mt-2"
                  >
                    <div class="small text-muted mb-1">Preuves / justificatifs :</div>
                    <div
                      v-for="preuve in trajet.preuves"
                      :key="preuve.id"
                      class="d-flex align-items-center mb-1"
                    >
                      <span class="badge bg-light text-dark me-2">
                        📎 {{ preuve.fileName }}
                      </span>
                      <a
                        :href="getPreuveUrl(preuve)"
                        target="_blank"
                        class="btn btn-sm btn-outline-primary"
                      >
                        📥 Ouvrir / Télécharger
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" @click="closeTrajetsModal">
                Fermer
              </button>
            </div>
          </div>
        </div>
      </div>
      <!-- FIN MODAL TRAJETS -->
    </div>
  </div>
</template>

<script>
import { adminService } from '@/services/adminService'

export default {
  name: 'AdminFormateursView',
  data () {
    return {
      formateurs: [], // Liste des formateurs
      loading: false, // Etat de chargement global
      saving: false, // Etat de sauvegarde
      showAddForm: false, // Affichage du modal d'ajout/modification
      editingFormateur: null, // Formateur en cours d'édition
      searchTerm: '', // Terme de recherche
      message: '', // Message de succès
      error: '', // Message d'erreur

      // Formulaire formateur (sans mot de passe temporaire)
      formateurForm: {
        nom: '',
        prenom: '',
        email: '',
        telephone: '',
        ville: '',
        codePostal: ''
      },

      // Mot de passe temporaire utilisé uniquement à la création
      temporaryPassword: '',

      // Etat pour le modal des trajets
      showTrajetsModal: false, // Afficher/cacher le modal trajets
      selectedFormateur: null, // Formateur sélectionné
      trajetsFormateur: [], // Trajets du formateur sélectionné
      loadingTrajets: false // Etat de chargement des trajets
    }
  },
  computed: {
    /**
     * Filtre les formateurs selon le terme de recherche
     * Recherche dans le nom, prénom, email et ville
     */
    filteredFormateurs () {
      if (!this.searchTerm) return this.formateurs
      const term = this.searchTerm.toLowerCase()
      return this.formateurs.filter(
        (f) =>
          f.nom.toLowerCase().includes(term) ||
          f.prenom.toLowerCase().includes(term) ||
          f.email.toLowerCase().includes(term) ||
          (f.ville && f.ville.toLowerCase().includes(term))
      )
    }
  },
  async mounted () {
    await this.loadFormateurs()
  },

  methods: {
    /**
     * Charge la liste des formateurs depuis l'API
     */
    async loadFormateurs () {
      this.loading = true
      try {
        const response = await adminService.getAllFormateurs()
        this.formateurs = response.data
      } catch (error) {
        console.error(error)
        this.error = 'Erreur lors du chargement des formateurs'
      } finally {
        this.loading = false
      }
    },

    /**
     * Ouvre le formulaire d'édition pour un formateur existant
     */
    editFormateur (formateur) {
      this.editingFormateur = formateur
      this.formateurForm = {
        nom: formateur.nom,
        prenom: formateur.prenom,
        email: formateur.email,
        telephone: formateur.telephone,
        ville: formateur.ville,
        codePostal: formateur.codePostal
      }
      this.temporaryPassword = ''
    },

    /**
     * Sauvegarde un formateur (création ou modification)
     */
    async saveFormateur () {
      this.saving = true
      this.message = ''
      this.error = ''
      try {
        if (this.editingFormateur) {
          // Mise à jour d'un formateur existant
          const payload = { ...this.formateurForm }
          await adminService.updateFormateur(this.editingFormateur.id, payload)
          this.message = 'Formateur modifié avec succès !'
        } else {
          // Création d'un nouveau formateur
          const payload = { ...this.formateurForm }
          // Ajout du mot de passe temporaire uniquement s'il est renseigné
          if (this.temporaryPassword && this.temporaryPassword.length >= 8) {
            payload.temporaryPassword = this.temporaryPassword
          }
          await adminService.createFormateur(payload)
          this.message = 'Formateur créé avec succès !'
        }

        await this.loadFormateurs()
        setTimeout(() => this.closeModal(), 1500)
      } catch (error) {
        console.error(error)
        const errorMsg =
          error.response?.data?.message ||
          JSON.stringify(error.response?.data) ||
          error.message
        this.error = 'Erreur lors de la sauvegarde : ' + errorMsg
      } finally {
        this.saving = false
      }
    },

    /**
     * Supprime un formateur après confirmation
     */
    async deleteFormateur (id) {
      if (confirm('Êtes-vous sûr de vouloir supprimer ce formateur ?')) {
        try {
          await adminService.deleteFormateur(id)
          this.message = 'Formateur supprimé avec succès !'
          await this.loadFormateurs()
        } catch (error) {
          console.error(error)
          this.error =
            'Erreur lors de la suppression : ' +
            (error.response?.data || error.message)
        }
      }
    },

    /**
     * Ferme le modal d'ajout/modification et réinitialise les formulaires
     */
    closeModal () {
      this.showAddForm = false
      this.editingFormateur = null
      this.formateurForm = {
        nom: '',
        prenom: '',
        email: '',
        telephone: '',
        ville: '',
        codePostal: ''
      }
      this.temporaryPassword = ''
      this.message = ''
      this.error = ''
    },

    /**
     * Ouvre le modal des trajets pour un formateur donné
     */
    async openTrajetsModal (formateur) {
      this.selectedFormateur = formateur
      this.showTrajetsModal = true
      this.trajetsFormateur = []
      this.loadingTrajets = true
      this.error = ''

      try {
        const response = await adminService.getTrajetsByFormateur(formateur.id)
        this.trajetsFormateur = response.data
      } catch (error) {
        console.error(error)
        this.error =
          'Erreur lors du chargement des trajets : ' +
          (error.response?.data || error.message)
      } finally {
        this.loadingTrajets = false
      }
    },

    /**
     * Ferme le modal des trajets
     */
    closeTrajetsModal () {
      this.showTrajetsModal = false
      this.selectedFormateur = null
      this.trajetsFormateur = []
    },

    /**
     * Construit l'URL de visualisation / téléchargement d'une preuve
     */
    getPreuveUrl (preuve) {
      // Adapter le host/port si nécessaire
      return `http://localhost:31010/api/preuves/download/${preuve.id}`
    }
  }
}
</script>

<style scoped>
/* Conteneur principal de la page */
.admin-formateurs {
  padding: 20px;
  min-height: 100vh;
  background: #f4f6f9;
  font-family: "Inter", sans-serif;
}

/* Style du titre principal */
h1 {
  font-weight: 600;
  color: #2c3e50;
}

/* Style du bouton primaire */
.btn-primary {
  background-color: #5c7cfa;
  border: none;
}

/* Effet au survol du bouton primaire */
.btn-primary:hover {
  background-color: #4c6ef5;
}

/* Style du bouton secondaire */
.btn-outline-secondary {
  border-color: #ced4da;
  color: #495057;
}

/* Effet au survol du bouton secondaire */
.btn-outline-secondary:hover {
  background-color: #e9ecef;
  color: #212529;
}

/* Style des cartes formateur */
.card {
  border-radius: 12px;
  background-color: #ffffff;
  transition: all 0.2s ease;
}

/* Effet au survol des cartes */
.card:hover {
  transform: translateY(-3px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
  background-color: #b9d8ef; /* Bleu clair au survol */
}

/* Style du champ de recherche */
.search-input {
  width: 280px;
  border-radius: 10px;
  border: 1px solid #ced4da;
  padding: 0.5rem 0.75rem;
  transition: all 0.2s ease;
}

/* Effet de focus sur le champ de recherche */
.search-input:focus {
  border-color: #5c7cfa;
  box-shadow: 0 0 0 0.15rem rgba(92, 124, 250, 0.25);
}

/* Style des alertes de succès */
.alert-success {
  margin-top: 10px;
  background: #e9f7ef;
  color: #2e7d32;
  padding: 10px;
  border-radius: 8px;
}

/* Style des alertes d'erreur */
.alert-danger {
  margin-top: 10px;
  background: #fdecea;
  color: #c0392b;
  padding: 10px;
  border-radius: 8px;
}
</style>
