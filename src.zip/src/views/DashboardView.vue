<template>
  <!-- 🔹 Template principal du tableau de bord utilisateur -->
  <div class="user-dashboard">
    <div class="container-fluid">
      <!-- En-tête avec informations utilisateur -->
      <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
          <h1 class="fw-bold">📊 Tableau de Bord</h1>
          <p class="text-muted">Bienvenue, {{ user.email }}</p>
        </div>
      </div>

      <!-- Cartes de statistiques -->
      <!-- IMPORTANT: Les cartes utilisent v-for pour éviter la répétition de code -->
      <div class="row mb-5">
        <div
          class="col-md-3 mb-4"
          v-for="stat in statsCards"
          :key="stat.title"
        >
          <div class="card dashboard-stat h-100">
            <div class="card-body d-flex justify-content-between align-items-center">
              <div>
                <h6 class="text-light mb-1">{{ stat.title }}</h6>
                <h2 class="fw-bold text-white mb-0">{{ stat.value }}</h2>
                <small class="text-light opacity-75">{{ stat.subtitle }}</small>
              </div>
              <div class="icon-circle fs-2">
                <span>{{ stat.icon }}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Section des actions rapides -->
      <!-- NOTE: Les boutons utilisent la navigation programmatique de Vue Router -->
      <div class="row mb-5">
        <div class="col">
          <h3>⚡ Actions Rapides</h3>
          <div class="d-grid gap-2 d-md-flex">
            <button
              class="btn btn-primary me-2"
              @click="$router.push('/trajets')"
            >
              📝 Mes Trajets
            </button>
            <button
              class="btn btn-outline-primary me-2"
              @click="$router.push('/classes')"
            >
              👥 Mes Classes
            </button>
            <button
              class="btn btn-outline-primary"
              @click="$router.push('/competences')"
            >
              🎯 Mes Compétences
            </button>
          </div>
        </div>
      </div>

      <!-- Section "Mes classes" avec état de chargement -->
      <!-- ATTENTION: Gérer les états loading, empty et data pour une bonne UX -->
      <div class="row">
        <div class="col-12">
          <div class="card shadow-sm border-0 rounded-4">
            <div class="card-header bg-white border-0">
              <h5 class="mb-0">👥 Mes Classes</h5>
            </div>
            <div class="card-body">
              <!-- État de chargement -->
              <div v-if="loading" class="text-center">
                <div class="spinner-border" role="status">
                  <span class="visually-hidden">Chargement...</span>
                </div>
              </div>
              <!-- État vide -->
              <div v-else-if="classes.length === 0" class="text-muted text-center">
                <p>Aucune classe assignée</p>
              </div>
              <!-- Données chargées -->
              <div v-else class="row g-3">
                <div
                  v-for="classe in classes"
                  :key="classe.id"
                  class="col-md-6 col-lg-4"
                >
                  <div class="card h-100 border-0 shadow-sm class-card">
                    <div class="card-body">
                      <h5 class="card-title">{{ classe.nom }}</h5>
                      <p class="card-text text-muted">
                        {{ classe.description }}
                      </p>
                      <button
                        class="btn btn-sm btn-primary w-100"
                        @click="$router.push(`/classes/${classe.id}`)"
                      >
                        Voir détails
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Section activité récente -->
      <!-- TODO: Remplacer les données mockées par des données réelles de l'API -->
      <div class="row mt-4">
        <div class="col-12">
          <div class="card shadow-sm border-0 rounded-4">
            <div class="card-header bg-white border-0">
              <h5 class="mb-0">🕒 Activité Récente</h5>
            </div>
            <div class="card-body">
              <div v-if="recentActivity.length === 0" class="text-muted text-center">
                <p>Aucune activité récente</p>
              </div>
              <div v-else class="list-group list-group-flush">
                <div
                  v-for="activity in recentActivity"
                  :key="activity.id"
                  class="list-group-item border-0 border-bottom"
                >
                  <div class="d-flex w-100 justify-content-between">
                    <h6 class="mb-1">{{ activity.title }}</h6>
                    <small class="text-muted">{{ activity.time }}</small>
                  </div>
                  <p class="mb-1 text-muted">{{ activity.description }}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
// 🔹 Import des services pour la gestion des données
// NOTE: Les services centralisent les appels API et la logique métier
import { authService } from '@/services/authService'
import { userService } from '@/services/userService'
import { formateurService } from '@/services/formateurService'

export default {
  name: 'DashboardView',
  data() {
    return {
      // Données utilisateur récupérées depuis le service d'authentification
      user: {},
      // Tableau des cartes de statistiques (rempli dynamiquement)
      statsCards: [],
      // Liste des classes de l'utilisateur
      classes: [],
      // Activités récentes (actuellement mockées)
      recentActivity: [],
      // État de chargement pour le UX
      loading: false
    }
  },
  async mounted() {
    // 🔹 Hook de cycle de vie - exécuté après le montage du composant
    // Récupération de l'utilisateur connecté
    this.user = authService.getCurrentUser()
    
    // Redirection si utilisateur non authentifié
    if (!this.user) {
      this.$router.push('/')
      return
    }
    
    // Chargement des données utilisateur
    await this.loadUserData()
  },
  methods: {
    async loadUserData() {
      // 🔹 Méthode principale de chargement des données
      this.loading = true
      try {
        // 1. Chargement des classes utilisateur
        const classesRes = await userService.getUserClasses(this.user.id)
        this.classes = classesRes.data || []

        // 2. Chargement des statistiques formateur
        const statsRes = await formateurService.getStats(this.user.formateur.id)
        const stats = statsRes.data || {}

        // 3. Construction dynamique des cartes de statistiques
        // NOTE: L'ordre des cartes est important pour le CSS nth-child
        this.statsCards = [
          {
            title: 'Mes Classes',
            value: stats.nbClasses || this.classes.length,
            subtitle: 'Classes assignées',
            icon: '📘',
            color: '#6366f1'
          },
          {
            title: 'Élèves',
            // Calcul du nombre total d'élèves sur toutes les classes
            value: this.classes.reduce((acc, c) => acc + (c.nbEleves || 0), 0),
            subtitle: 'Élèves au total',
            icon: '👥',
            color: '#22c55e'
          },
          {
            title: 'Mes Trajets',
            value: stats.nbTrajets || 0,
            subtitle: 'Trajets enregistrés',
            icon: '🛣️',
            color: '#3b82f6'
          },
          {
            title: 'Distance Totale',
            value: Math.round(stats.distanceTotale || 0) + ' km',
            subtitle: 'Parcourue cette année',
            icon: '📏',
            color: '#f59e0b'
          }
        ]

        // 4. Données mockées pour l'activité récente
        // TODO: Remplacer par un appel API réel
        this.recentActivity = [
          {
            id: 1,
            title: 'Nouvelle classe assignée',
            description: 'Vous avez été ajouté à la classe "Mathématiques A".',
            time: 'Il y a 3 heures'
          },
          {
            id: 2,
            title: 'Connexion réussie',
            description: 'Vous vous êtes connecté au tableau de bord.',
            time: 'Aujourd\'hui'
          }
        ]
      } catch (error) {
        // 🔹 Gestion centralisée des erreurs
        console.error('Erreur chargement données user:', error)
        // TODO: Ajouter une notification toast pour l'utilisateur
      } finally {
        // Désactivation du loader dans tous les cas (succès ou erreur)
        this.loading = false
      }
    },
    logout() {
      // 🔹 Déconnexion et redirection vers la page d'accueil
      authService.logout()
      this.$router.push('/')
    }
  }
}
</script>

<style scoped>
/* 🔹 Styles scopés au composant Dashboard */

.user-dashboard {
  padding: 30px;
  min-height: 100vh;
  background: #f8fafc;
}

/* === En-tête === */
h1 {
  font-size: 1.8rem;
  color: #0f172a;
}

/* === Container des cartes de stats (disposition horizontale) === */
.row.mb-5 {
  display: flex;
  flex-wrap: nowrap;         /* Empêche le retour à la ligne */
  overflow-x: auto;          /* Scroll horizontal si trop de cartes */
  gap: 20px;                 /* Espacement entre les cartes */
  padding-bottom: 10px;
  scrollbar-width: thin;     /* Style Firefox pour la scrollbar */
}
.row.mb-5::-webkit-scrollbar {
  height: 6px;
}
.row.mb-5::-webkit-scrollbar-thumb {
  background-color: rgba(0, 0, 0, 0.2);
  border-radius: 3px;
}

/* Chaque carte de stats prend un espace égal */
.col-md-3.mb-4 {
  flex: 1 1 0;              /* Distribution égale de l'espace */
  min-width: 200px;         /* Largeur minimale pour la lisibilité */
}

/* === Cartes de statistiques (style gradient) === */
.dashboard-stat {
  border-radius: 16px;
  color: white;
  background: linear-gradient(135deg, #728ecc, #5076df);
  transition: transform 0.2s ease, box-shadow 0.2s ease;
  min-height: 150px;
}
/* IMPORTANT: Les couleurs correspondent à l'ordre dans le tableau statsCards */
.dashboard-stat:nth-child(2) {
  background: linear-gradient(135deg, #4f46e5, #3730a3);
}
.dashboard-stat:nth-child(3) {
  background: linear-gradient(135deg, #0284c7, #0369a1);
}
.dashboard-stat:nth-child(4) {
  background: linear-gradient(135deg, #059669, #047857);
}
.dashboard-stat:hover {
  transform: translateY(-4px);
  box-shadow: 0 6px 16px rgba(0, 0, 0, 0.15);
}

.icon-circle {
  background: rgba(255, 255, 255, 0.15);
  border-radius: 50%;
  padding: 14px;
  display: flex;
  align-items: center;
  justify-content: center;
}

/* === Section classes === */
.class-card {
  border-radius: 12px;
  transition: transform 0.2s ease, box-shadow 0.2s ease;
}
.class-card:hover {
  transform: translateY(-3px);
  box-shadow: 0 6px 14px rgba(0, 0, 0, 0.1);
}

/* === Boutons === */
.btn-primary {
  border-radius: 10px;
}
.btn-outline-primary {
  border-radius: 10px;
}

/* === Activité récente === */
.list-group-item {
  background: transparent;
}

/* === Uniformité des cartes === */
.card {
  border-radius: 16px;
}
.d-grid.gap-2.d-md-flex button {
  margin-right: 12px;
}

.d-grid.gap-2.d-md-flex button:last-child {
  margin-right: 0;
}
</style>