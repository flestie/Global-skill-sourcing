<template>
  <div class="change-password-page">
    <div class="card change-password-card">
      <h2 class="mb-3">Changer votre mot de passe</h2>
      <p class="text-muted mb-4">
        Vous vous êtes connecté avec un mot de passe temporaire.
        Merci d’en choisir un nouveau pour sécuriser votre compte.
      </p>

      <form @submit.prevent="onSubmit">
        <!-- Mot de passe actuel (temporaire) -->
        <div class="mb-3">
          <label class="form-label">Mot de passe actuel (temporaire)</label>
          <input
            type="password"
            class="form-control"
            v-model="oldPassword"
            required
          />
        </div>

        <!-- Nouveau mot de passe -->
        <div class="mb-3">
          <label class="form-label">Nouveau mot de passe</label>
          <input
            type="password"
            class="form-control"
            v-model="newPassword"
            required
            minlength="8"
          />
          <small class="text-muted">
            Minimum 8 caractères, utilisez une combinaison de lettres, chiffres et symboles.
          </small>
        </div>

        <!-- Confirmation du nouveau mot de passe -->
        <div class="mb-3">
          <label class="form-label">Confirmer le nouveau mot de passe</label>
          <input
            type="password"
            class="form-control"
            v-model="confirmPassword"
            required
            minlength="8"
          />
        </div>

        <!-- Messages d'erreur / succès -->
        <div v-if="error" class="alert alert-danger mt-2">
          {{ error }}
        </div>
        <div v-if="success" class="alert alert-success mt-2">
          {{ success }}
        </div>

        <!-- Bouton de validation -->
        <button
          type="submit"
          class="btn btn-primary w-100 mt-3"
          :disabled="loading"
        >
          <span v-if="loading">Enregistrement...</span>
          <span v-else>Valider le nouveau mot de passe</span>
        </button>
      </form>
    </div>
  </div>
</template>

<script>
import { authService } from '@/services/authService'

export default {
  name: 'ChangePasswordView',
  data () {
    return {
      oldPassword: '',
      newPassword: '',
      confirmPassword: '',
      loading: false,
      error: '',
      success: ''
    }
  },
  mounted () {
    // 🔒 Sécurité côté front :
    // - si l'utilisateur n'est pas authentifié → retour à la page d'accueil
    // - si l'utilisateur est authentifié mais ne doit plus changer son mot de passe
    //   (mustChangePassword = false) → redirection vers son tableau de bord
    if (!authService.isAuthenticated()) {
      this.$router.push('/')
    } else if (!authService.mustChangePassword()) {
      this.$router.push(authService.redirectAfterLogin())
    }
  },
  methods: {
    async onSubmit () {
      this.error = ''
      this.success = ''

      // Vérification basique côté front
      if (this.newPassword !== this.confirmPassword) {
        this.error = 'Les nouveaux mots de passe ne correspondent pas.'
        return
      }

      if (this.newPassword.length < 8) {
        this.error = 'Le nouveau mot de passe doit contenir au moins 8 caractères.'
        return
      }

      try {
        this.loading = true

        // Appel au service d’authentification
        const res = await authService.changePassword(this.oldPassword, this.newPassword)

        // Si l'API renvoie un message (string) → on l'affiche, sinon message par défaut
        this.success = typeof res.data === 'string'
          ? res.data
          : 'Mot de passe changé avec succès !'

        // Petit délai puis redirection vers le dashboard approprié
        setTimeout(() => {
          this.$router.push(authService.redirectAfterLogin())
        }, 1200)
      } catch (err) {
        console.error(err)
        this.error =
          err.response?.data ||
          err.message ||
          'Erreur lors du changement de mot de passe.'
      } finally {
        this.loading = false
      }
    }
  }
}
</script>

<style scoped>
.change-password-page {
  min-height: 100vh;
  background: #f3f4f6;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 24px;
}

.change-password-card {
  width: 100%;
  max-width: 480px;
  background: #ffffff;
  border-radius: 16px;
  padding: 24px 28px;
  box-shadow: 0 12px 30px rgba(15, 23, 42, 0.08);
}

h2 {
  font-size: 1.5rem;
  font-weight: 600;
  color: #111827;
}

.form-label {
  font-weight: 500;
}

.btn-primary {
  background-color: #2563eb;
  border: none;
  border-radius: 10px;
  padding: 10px 14px;
  font-weight: 600;
}

.btn-primary:hover {
  background-color: #1d4ed8;
}

.alert {
  border-radius: 10px;
  padding: 10px 12px;
  font-size: 0.9rem;
}
</style>
