<template>
  <div class="admin-sessions">
    <div class="container-fluid">
      <!-- En-tête de page -->
      <div class="row mb-4 align-items-center">
        <div class="col">
          <h1>📅 Gestion des Sessions</h1>
          <p class="text-muted">
            Créez, modifiez et gérez les sessions de formation.
          </p>
        </div>
        <div class="col-auto">
          <button
            class="btn btn-outline-secondary"
            @click="$router.push('/admin/dashboard')"
          >
            ← Retour Dashboard
          </button>
        </div>
      </div>

      <!-- Barre d’actions : bouton ajouter + recherche -->
      <div class="row mb-4 align-items-center">
        <div class="col d-flex align-items-center">
          <!-- Bouton pour ajouter une session -->
          <button
            class="btn btn-primary"
            style="margin-right: 20px;"
            @click="openCreateModal"
          >
            ➕ Ajouter une Session
          </button>

          <!-- Champ de recherche -->
          <input
            type="text"
            class="form-control search-input"
            placeholder="Rechercher une session..."
            v-model="searchTerm"
          />
        </div>
      </div>

      <!-- Section chargement global -->
      <div v-if="loading" class="text-center py-5">
        <div class="spinner-border text-primary" role="status">
          <span class="visually-hidden">Chargement...</span>
        </div>
      </div>

      <!-- Contenu principal -->
      <div v-else>
        <!-- Message si aucune session -->
        <div v-if="filteredSessions.length === 0" class="text-center text-muted">
          <p>Aucune session trouvée</p>
        </div>

        <!-- Tableau des sessions -->
        <div v-else class="card shadow-sm border-0">
          <div class="card-body">
            <h5 class="card-title mb-3">Liste des Sessions</h5>

            <div class="table-responsive">
              <table class="table align-middle table-hover">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Nom de la session</th>
                    <th>Début</th>
                    <th>Fin</th>
                    <th class="text-end">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  <tr v-for="session in filteredSessions" :key="session.id">
                    <td>
                      <span class="badge bg-light text-dark">
                        {{ session.id }}
                      </span>
                    </td>
                    <td>{{ session.nom }}</td>
                    <td>{{ formatDate(session.dateDebut || session.date_debut_cours) }}</td>
                    <td>{{ formatDate(session.dateFin || session.date_fin_cours) }}</td>
                    <td class="text-end">
                      <button
                        class="btn btn-sm btn-outline-primary me-2"
                        @click="editSession(session)"
                        title="Modifier la session"
                      >
                        ✏️
                      </button>
                      <button
                        class="btn btn-sm btn-outline-danger"
                        @click="deleteSession(session.id)"
                        title="Supprimer la session"
                      >
                        🗑️
                      </button>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>

            <!-- Messages de statut sous le tableau -->
            <div v-if="message" class="alert alert-success mt-3">
              {{ message }}
            </div>
            <div v-if="error" class="alert alert-danger mt-3">
              {{ error }}
            </div>
          </div>
        </div>
      </div>

      <!-- Modal Ajouter / Modifier Session -->
      <div
        v-if="showAddForm || editingSession"
        class="modal fade show d-block"
        style="background-color: rgba(255, 255, 255, 0.3);"
      >
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <!-- En-tête du modal -->
            <div class="modal-header">
              <h5 class="modal-title">
                {{ editingSession ? 'Modifier la Session' : 'Ajouter une Session' }}
              </h5>
              <button
                type="button"
                class="btn-close"
                @click="closeModal"
              ></button>
            </div>

            <!-- Corps du modal -->
            <div class="modal-body">
              <form @submit.prevent="saveSession">
                <div class="row">
                  <!-- Nom de la session -->
                  <div class="col-md-6 mb-3">
                    <label class="form-label">Nom de la session *</label>
                    <input
                      type="text"
                      class="form-control"
                      v-model="sessionForm.nom"
                      required
                    />
                  </div>

                  <!-- Date de début -->
                  <div class="col-md-3 mb-3">
                    <label class="form-label">Date de début *</label>
                    <input
                      type="date"
                      class="form-control"
                      v-model="sessionForm.dateDebut"
                      required
                    />
                  </div>

                  <!-- Date de fin -->
                  <div class="col-md-3 mb-3">
                    <label class="form-label">Date de fin *</label>
                    <input
                      type="date"
                      class="form-control"
                      v-model="sessionForm.dateFin"
                      required
                    />
                  </div>
                </div>

                <!-- Messages de statut dans le formulaire -->
                <div v-if="message" class="alert alert-success">
                  {{ message }}
                </div>
                <div v-if="error" class="alert alert-danger">
                  {{ error }}
                </div>
              </form>
            </div>

            <!-- Pied du modal -->
            <div class="modal-footer">
              <button
                type="button"
                class="btn btn-secondary"
                @click="closeModal"
              >
                Annuler
              </button>
              <button
                type="button"
                class="btn btn-primary"
                @click="saveSession"
                :disabled="saving"
              >
                {{ saving ? 'Sauvegarde...' : editingSession ? 'Modifier' : 'Créer' }}
              </button>
            </div>
          </div>
        </div>
      </div>
      <!-- Fin modal -->
    </div>
  </div>
</template>

<script>
import { sessionService } from '@/services/sessionService'

export default {
  name: 'AdminSessionsView',
  data () {
    return {
      // Liste des sessions (normalisées pour l’affichage)
      sessions: [],
      // États de chargement / sauvegarde
      loading: false,
      saving: false,
      // Gestion du modal
      showAddForm: false,
      editingSession: null,
      // Recherche
      searchTerm: '',
      // Messages utilisateur
      message: '',
      error: '',
      // Formulaire de session
      sessionForm: {
        nom: '',
        dateDebut: '',
        dateFin: ''
      }
    }
  },
  computed: {
    /**
     * Filtre les sessions selon le terme de recherche.
     * Recherche dans le nom et les dates (en texte).
     */
    filteredSessions () {
      if (!this.searchTerm) return this.sessions
      const term = this.searchTerm.toLowerCase()
      return this.sessions.filter((s) => {
        const nom = (s.nom || '').toLowerCase()
        const debut = (s.dateDebut || s.date_debut_cours || '').toString().toLowerCase()
        const fin = (s.dateFin || s.date_fin_cours || '').toString().toLowerCase()
        return nom.includes(term) || debut.includes(term) || fin.includes(term)
      })
    }
  },
  async mounted () {
    await this.loadSessions()
  },
  methods: {
    /**
     * Charge la liste des sessions depuis l’API.
     * On normalise les noms de champs pour l’UI : dateDebut / dateFin.
     */
    async loadSessions () {
      this.loading = true
      this.error = ''
      try {
        const res = await sessionService.getAllSessions()
        const apiSessions = res.data || []
        this.sessions = apiSessions.map((s) => ({
          id: s.id,
          nom: s.nom || s.nomSession || '',
          // on accepte plusieurs formats de champs venant du backend
          dateDebut:
            s.date_debut_cours ||
            s.dateDebut ||
            s.date_debut ||
            '',
          dateFin:
            s.date_fin_cours ||
            s.dateFin ||
            s.date_fin ||
            ''
        }))
      } catch (err) {
        console.error(err)
        this.error =
          err.response?.data || 'Erreur lors du chargement des sessions.'
      } finally {
        this.loading = false
      }
    },

    /**
     * Ouvre le modal en mode création.
     */
    openCreateModal () {
      this.editingSession = null
      this.sessionForm = {
        nom: '',
        dateDebut: '',
        dateFin: ''
      }
      this.message = ''
      this.error = ''
      this.showAddForm = true
    },

    /**
     * Prépare le formulaire pour l’édition d’une session existante.
     */
    editSession (session) {
      this.editingSession = session
      const debut = session.dateDebut || session.date_debut_cours
      const fin = session.dateFin || session.date_fin_cours

      this.sessionForm = {
        nom: session.nom,
        dateDebut: debut ? debut.toString().substring(0, 10) : '',
        dateFin: fin ? fin.toString().substring(0, 10) : ''
      }
      this.message = ''
      this.error = ''
      this.showAddForm = true
    },

    /**
     * Crée ou met à jour une session via l’API.
     * On mappe les champs du formulaire vers ceux attendus par l’entity Session.
     */
    async saveSession () {
      this.saving = true
      this.message = ''
      this.error = ''

      try {
        const payload = {
          nom: this.sessionForm.nom,
          date_debut_cours: this.sessionForm.dateDebut,
          date_fin_cours: this.sessionForm.dateFin,
          date_debut_stage: this.sessionForm.dateDebut,
          date_fin_stage: this.sessionForm.dateFin
        }

        if (this.editingSession) {
          await sessionService.updateSession(this.editingSession.id, payload)
          this.message = 'Session mise à jour avec succès !'
        } else {
          await sessionService.createSession(payload)
          this.message = 'Session créée avec succès !'
        }

        await this.loadSessions()
        setTimeout(() => this.closeModal(), 1200)
      } catch (err) {
        console.error(err)
        this.error =
          err.response?.data || 'Erreur lors de la sauvegarde de la session.'
      } finally {
        this.saving = false
      }
    },

    /**
     * Supprime une session après confirmation.
     */
    async deleteSession (id) {
      if (!confirm('Êtes-vous sûr de vouloir supprimer cette session ?')) {
        return
      }
      this.error = ''
      this.message = ''
      try {
        await sessionService.deleteSession(id)
        this.message = 'Session supprimée avec succès !'
        await this.loadSessions()
      } catch (err) {
        console.error(err)
        this.error =
          err.response?.data || 'Erreur lors de la suppression de la session.'
      }
    },

    /**
     * Ferme le modal et réinitialise le formulaire.
     */
    closeModal () {
      this.showAddForm = false
      this.editingSession = null
      this.sessionForm = {
        nom: '',
        dateDebut: '',
        dateFin: ''
      }
      this.message = ''
      this.error = ''
    },

    /**
     * Formatte une date en chaîne lisible (YYYY-MM-DD → DD/MM/YYYY).
     */
    formatDate (value) {
      if (!value) {
        return ''
      }
      const str = value.toString().substring(0, 10)
      const parts = str.split('-')
      if (parts.length !== 3) {
        return str
      }
      const [y, m, d] = parts
      return `${d}/${m}/${y}`
    }
  }
}
</script>

<style scoped>
.admin-sessions {
  padding: 20px;
  min-height: 100vh;
  background: #f4f6f9;
  font-family: "Inter", sans-serif;
}

h1 {
  font-weight: 600;
  color: #2c3e50;
}

/* Bouton primaire */
.btn-primary {
  background-color: #5c7cfa;
  border: none;
}

.btn-primary:hover {
  background-color: #4c6ef5;
}

/* Bouton secondaire (retour) */
.btn-outline-secondary {
  border-color: #ced4da;
  color: #495057;
}

.btn-outline-secondary:hover {
  background-color: #e9ecef;
  color: #212529;
}

/* Cartes */
.card {
  border-radius: 12px;
  background-color: #ffffff;
  transition: all 0.2s ease;
  border: none;
}

.card:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
}

/* Champ de recherche */
.search-input {
  width: 280px;
  border-radius: 10px;
  border: 1px solid #ced4da;
  padding: 0.5rem 0.75rem;
  transition: all 0.2s ease;
}

.search-input:focus {
  border-color: #5c7cfa;
  box-shadow: 0 0 0 0.15rem rgba(92, 124, 250, 0.25);
}

/* Tableau des sessions */
.table thead th {
  background-color: #f1f3f5;
  border-bottom: none;
  font-weight: 600;
  color: #495057;
}

.table tbody tr:hover {
  background-color: #f8f9fa;
}

/* Alertes */
.alert-success {
  margin-top: 10px;
  background: #e9f7ef;
  color: #2e7d32;
  padding: 10px;
  border-radius: 8px;
}

.alert-danger {
  margin-top: 10px;
  background: #fdecea;
  color: #c0392b;
  padding: 10px;
  border-radius: 8px;
}
</style>
