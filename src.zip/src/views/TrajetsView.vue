<template>
  <div class="trajets container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
      <h1>Gestion des Trajets</h1>
      <div>
        <button class="btn btn-secondary me-2" @click="$router.push('/dashboard')">
          ← Retour Dashboard
        </button>
        <button class="btn btn-primary" @click="showForm = !showForm">
          {{ showForm ? 'Fermer le formulaire' : '+ Nouveau Trajet' }}
        </button>
      </div>
    </div>

    <!-- Formulaire nouveau trajet -->
    <transition name="fade">
      <div v-if="showForm" class="card mb-4 shadow-sm">
        <div class="card-body">
          <h5 class="card-title">Nouveau Trajet</h5>

          <form @submit.prevent="createTrajet">
            <div class="mb-3 row">
              <label class="col-sm-4 col-form-label">Ville de départ</label>
              <div class="col-sm-8">
                <input type="text" class="form-control" v-model="newTrajet.villeDepart" required />
              </div>
            </div>

            <div class="mb-3 row">
              <label class="col-sm-4 col-form-label">Ville d'arrivée</label>
              <div class="col-sm-8">
                <input type="text" class="form-control" v-model="newTrajet.villeArrivee" required />
              </div>
            </div>

            <div class="mb-3 row">
              <label class="col-sm-4 col-form-label">Distance (km)</label>
              <div class="col-sm-8">
                <input type="number" class="form-control" v-model="newTrajet.distance" step="0.1" required />
              </div>
            </div>

            <div class="mb-3 row">
              <label class="col-sm-4 col-form-label">Correspondances</label>
              <div class="col-sm-8">
                <input type="text" class="form-control" v-model="newTrajet.correspondances"
                  placeholder="Bus 12, Métro ligne 3" />
              </div>
            </div>

            <div class="mb-3">
              <label class="form-label">Badges utilisés</label>
              <div v-if="badges.length > 0">
                <div v-for="badge in badges" :key="badge.id" class="form-check">
                  <input class="form-check-input" type="checkbox" :value="badge.nom"
                    v-model="newTrajet.badgesUtilises" :id="'badge-' + badge.id" />
                  <label class="form-check-label" :for="'badge-' + badge.id">
                    🏷️ {{ badge.nom }} <small class="text-muted">({{ badge.type }})</small>
                  </label>
                </div>
              </div>
              <div v-else class="text-muted">Aucun badge disponible</div>
            </div>

            <div class="mb-3">
              <label class="form-label">Preuve (PDF, Image)</label>
              <input type="file" class="form-control" ref="fileInput" @change="onFileSelected"
                accept=".pdf,.jpg,.jpeg,.png" />
              <small class="text-muted">Formats acceptés: PDF, JPG, PNG (max 5MB)</small>

              <div v-if="selectedFile" class="alert alert-info mt-2 d-flex justify-content-between align-items-center">
                <small>
                  <strong>Fichier sélectionné:</strong> {{ selectedFile.name }}
                  ({{ (selectedFile.size / 1024 / 1024).toFixed(2) }} MB)
                </small>
                <button type="button" class="btn-close btn-sm" @click="removeFile"></button>
              </div>
            </div>

            <div class="text-end">
              <button type="submit" class="btn btn-primary" :disabled="loading">
                {{ loading ? "Création..." : "Créer le trajet" }}
              </button>
            </div>
          </form>

          <div v-if="message" class="alert alert-success mt-3">{{ message }}</div>
          <div v-if="error" class="alert alert-danger mt-3">{{ error }}</div>
        </div>
      </div>
    </transition>

    <!-- Liste des trajets existants -->
    <div>
      <h4 class="mb-3">Mes Trajets</h4>
      <div v-if="trajets.length === 0" class="text-muted">Aucun trajet enregistré</div>

      <div class="trajet-container">
        <div v-for="trajet in trajets" :key="trajet.id" class="trajet-card">
          <div class="card-body">
            <div class="d-flex justify-content-between align-items-start">
              <div>
                <h5 class="card-title mb-1">{{ trajet.villeDepart }} → {{ trajet.villeArrivee }}</h5>
                <p class="text-muted small mb-2">{{ trajet.distance }} km</p>

                <div v-if="trajet.correspondances" class="small mb-2">📋 {{ trajet.correspondances }}</div>

                <div v-if="trajet.badgesUtilises && trajet.badgesUtilises.length > 0" class="mb-2">
                  <span v-for="badge in trajet.badgesUtilises" :key="badge"
                    class="badge bg-primary text-white me-1">{{ badge }}</span>
                </div>
              </div>
              <button class="btn btn-sm btn-primary delete-btn" @click="deleteTrajet(trajet.id)">
                Supprimer
              </button>
            </div>

            <div v-if="trajet.preuves && trajet.preuves.length > 0" class="mt-3">
              <h6 class="small text-muted mb-1">Preuves:</h6>
              <div v-for="preuve in trajet.preuves" :key="preuve.id"
                class="d-flex justify-content-between align-items-center mb-1">
                <span class="badge bg-light text-dark">📎 {{ preuve.fileName }}</span>
                <div>
                  <button class="btn btn-sm btn-outline-primary me-1" @click="viewPreuve(preuve)">🔍 Voir</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal de visualisation -->
    <div v-if="selectedPreuve" class="modal fade show d-block" style="background-color: rgba(0, 0, 0, 0.5)">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Preuve: {{ selectedPreuve.fileName }}</h5>
              <button type="button" class="btn btn-outline-danger btn-sm" @click="deletePreuve(selectedPreuve.id)">
              🗑️ Supprimer le fichier
               </button>
          </div>
          <div class="modal-body text-center">
            <div v-if="isImage(selectedPreuve.fileName)">
              <img :src="getPreuveUrl(selectedPreuve)" class="img-fluid rounded" style="max-height: 500px" />
            </div>
            <div v-else-if="isPdf(selectedPreuve.fileName)">
              <div class="alert alert-info">
                <p>📄 PDF: {{ selectedPreuve.fileName }}</p>
                <a :href="getPreuveUrl(selectedPreuve)" target="_blank" class="btn btn-primary">📥 Télécharger</a>
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" @click="selectedPreuve = null">Fermer</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { authService } from '@/services/authService'
import { formateurService } from '@/services/formateurService'
import { badgeService } from '@/services/badgeService'

export default {
  name: 'TrajetsView',
  data() {
    return {
      user: {},
      trajets: [],
      badges: [],
      showForm: false,
      newTrajet: {
        villeDepart: '',
        villeArrivee: '',
        distance: 0,
        correspondances: '',
        badgesUtilises: []
      },
      selectedFile: null,
      selectedPreuve: null,
      loading: false,
      message: '',
      error: ''
    }
  },
  async mounted() {
    this.user = authService.getCurrentUser()
    if (!this.user) {
      this.$router.push('/')
      return
    }
    await this.loadTrajets()
    await this.loadBadges()
  },
  methods: {
    async loadTrajets() {
      const response = await formateurService.getTrajets(this.user.formateur.id)
      this.trajets = response.data
    },
    async loadBadges() {
      const response = await badgeService.getAllBadges()
      this.badges = response.data
    },
    async createTrajet() {
      this.loading = true
      this.message = ''
      this.error = ''
      try {
        const trajetResponse = await formateurService.createTrajet(this.user.formateur.id, this.newTrajet)
        if (this.selectedFile) {
          await formateurService.uploadPreuve(trajetResponse.data.id, this.selectedFile)
          this.message = 'Trajet créé avec succès + preuve ajoutée'
        } else {
          this.message = 'Trajet créé avec succès'
        }
        this.resetForm()
        await this.loadTrajets()
        this.showForm = false
      } catch (error) {
        this.error = error.response?.data || error.message
      } finally {
        this.loading = false
      }
    },
    async deleteTrajet(trajetId) {
      if (confirm('Supprimer ce trajet et toutes ses preuves ?')) {
        await formateurService.deleteTrajet(trajetId)
        await this.loadTrajets()
      }
    },
    async deletePreuve(preuveId, trajetId) {
      if (confirm('Supprimer cette preuve ?')) {
        await formateurService.deletePreuve(preuveId)
        await this.loadTrajets()
      }
    },
    onFileSelected(event) {
      this.selectedFile = event.target.files[0]
    },
    removeFile() {
      this.selectedFile = null
      this.$refs.fileInput.value = ''
    },
    resetForm() {
      this.newTrajet = { villeDepart: '', villeArrivee: '', distance: 0, correspondances: '', badgesUtilises: [] }
      this.removeFile()
    },
    isImage(filename) {
      return /\.(jpg|jpeg|png|gif|webp)$/i.test(filename)
    },
    isPdf(filename) {
      return filename.toLowerCase().endsWith('.pdf')
    },
    getPreuveUrl(preuve) {
      return `http://localhost:31010/api/preuves/download/${preuve.id}`
    },
    viewPreuve(preuve) {
      if (this.isImage(preuve.fileName)) {
        window.open(this.getPreuveUrl(preuve), '_blank')
      } else {
        this.selectedPreuve = preuve
      }
    }
  }
}
</script>

<style scoped>
.trajets {
  padding: 20px 40px;
  min-height: 100vh;
  background-color: #f8f9fa;
}

/* Smooth fade for form opening */
.fade-enter-active,
.fade-leave-active {
  transition: all 0.3s ease;
}
.fade-enter-from,
.fade-leave-to {
  opacity: 0;
  transform: translateY(-10px);
}

/* Horizontal layout for trajets - 4 per row using GRID */
.trajet-container {
  display: grid;
  grid-template-columns: repeat(5, 1fr); /* 5 per row */
  gap: 1.2rem;
  width: 100%;
  padding: 0 1.5rem; /* equal space left & right */
  box-sizing: border-box;
}

/* Card styling with blue/grey background */
.trajet-card {
  background-color: #e9ecef;
  border: 1px solid #ced4da;
  border-radius: 10px;
  transition: all 0.25s ease;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
  min-width: 0; /* Important for grid items */
}

/* Hover effect */
.trajet-card:hover {
  background-color: #dee2e6;
  transform: translateY(-3px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.12);
}

/* Delete button styling - same as "Nouveau Trajet" button */
.delete-btn {
  background-color: #0d6efd;
  border-color: #0d6efd;
  color: white;
  white-space: nowrap;
}

.delete-btn:hover {
  background-color: #0b5ed7;
  border-color: #0a58ca;
}
.container {
  max-width: 100% !important;
  padding-right: 0 !important;  /* removes Bootstrap's default right padding */
}

/* Optional – slightly increase heading spacing */
h1 {
  margin-left: 5px;
}

/* Buttons line up nicely */
button {
  white-space: nowrap;
}
.btn-close {
  margin-left: 10px;
}
.modal-header .btn-outline-danger {
  white-space: nowrap;
}
/* Responsive design */
@media (max-width: 1400px) {
  .trajet-container {
    grid-template-columns: repeat(3, 1fr);
  }
}

@media (max-width: 992px) {
  .trajet-container {
    grid-template-columns: repeat(2, 1fr);
  }
}

@media (max-width: 576px) {
  .trajet-container {
    grid-template-columns: 1fr;
  }
}
</style>