<template>
  <div class="admin-formations">
    <div class="container-fluid">
      <!-- En-tête de page -->
      <div class="row mb-4">
        <div class="col">
          <h1>🎓 Gestion des Formations</h1>
          <p class="text-muted">
            Créez, modifiez et gérez les programmes de formation
          </p>
        </div>
        <div class="col-auto">
          <button
            class="btn btn-secondary"
            @click="$router.push('/admin/dashboard')"
          >
            ← Retour Dashboard
          </button>
        </div>
      </div>

      <!-- Barre d'actions : bouton ajouter + recherche -->
      <div class="row mb-4 align-items-center">
        <div class="col d-flex align-items-center">
          <!-- Bouton pour créer une nouvelle formation -->
          <button
            class="btn btn-info"
            style="margin-right: 20px;"
            @click="showAddForm = true"
          >
            ➕ Nouvelle Formation
          </button>

          <!-- Champ de recherche pour filtrer les formations -->
          <input
            type="text"
            class="form-control search-input"
            placeholder="Rechercher une formation..."
            v-model="searchTerm"
          />
        </div>
      </div>

      <!-- Section principale : liste des formations -->
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-body">
              <!-- Indicateur de chargement -->
              <div v-if="loading" class="text-center">
                <div class="spinner-border" role="status">
                  <span class="visually-hidden">Chargement...</span>
                </div>
              </div>

              <!-- Message si aucune formation -->
              <div
                v-else-if="formations.length === 0"
                class="text-center text-muted"
              >
                <p>Aucune formation créée</p>
                <button class="btn btn-info" @click="showAddForm = true">
                  Créer la première formation
                </button>
              </div>

              <!-- Tableau des formations -->
              <div v-else>
                <div class="table-responsive">
                  <table class="table table-hover">
                    <thead>
                      <tr>
                        <th>Nom</th>
                        <th>Durée</th>
                        <th>Participants Max</th>
                        <th>Format</th>
                        <th>Objectifs</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      <!-- Boucle sur les formations filtrées -->
                      <tr
                        v-for="formation in filteredFormations"
                        :key="formation.id"
                      >
                        <td>
                          <strong>{{ formation.nom }}</strong>
                        </td>
                        <td>
                          <!-- Badge pour la durée -->
                          <span class="badge bg-primary"
                            >{{ formation.duree }}h</span
                          >
                        </td>
                        <td>
                          <!-- Badge pour le nombre de participants -->
                          <span class="badge bg-info">{{
                            formation.nbParticipantsMax
                          }}</span>
                        </td>
                        <td>
                          <!-- Badge coloré selon le format -->
                          <span
                            :class="[
                              'badge',
                              formation.format === 'PRESENTIEL'
                                ? 'bg-success'
                                : 'bg-warning text-dark',
                            ]"
                          >
                            {{ formation.format }}
                          </span>
                        </td>
                        <td>
                          <!-- Objectifs tronqués pour l'affichage -->
                          <small class="text-muted">
                            {{ truncateText(formation.objectifs, 50) }}
                          </small>
                        </td>
                        <td>
                          <!-- Boutons d'actions -->
                          <button
                            class="btn btn-sm btn-outline-primary me-1"
                            @click="viewFormationDetails(formation)"
                            title="Voir les détails"
                          >
                            🔍
                          </button>
                          <button
                            class="btn btn-sm btn-outline-secondary me-1"
                            @click="editFormation(formation)"
                            title="Modifier"
                          >
                            ✏️
                          </button>
                          <button
                            class="btn btn-sm btn-outline-danger"
                            @click="deleteFormation(formation.id)"
                            title="Supprimer"
                          >
                            🗑️
                          </button>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Modal pour afficher les détails d'une formation -->
      <div
        v-if="selectedFormation"
        class="modal fade show d-block"
        style="background-color: rgba(0, 0, 0, 0.5)"
      >
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">
                Détails de la Formation: {{ selectedFormation.nom }}
              </h5>
              <button
                type="button"
                class="btn-close"
                @click="selectedFormation = null"
              ></button>
            </div>
            <div class="modal-body">
              <div class="row">
                <!-- Colonne informations générales -->
                <div class="col-md-6">
                  <h6>Informations Générales</h6>
                  <p><strong>Nom:</strong> {{ selectedFormation.nom }}</p>
                  <p>
                    <strong>Durée:</strong> {{ selectedFormation.duree }} heures
                  </p>
                  <p>
                    <strong>Participants Maximum:</strong>
                    {{ selectedFormation.nbParticipantsMax }}
                  </p>
                  <p>
                    <strong>Format:</strong>
                    <span
                      :class="[
                        'badge',
                        selectedFormation.format === 'PRESENTIEL'
                          ? 'bg-success'
                          : 'bg-warning text-dark',
                      ]"
                    >
                      {{ selectedFormation.format }}
                    </span>
                  </p>
                </div>
                <!-- Colonne statistiques -->
                <div class="col-md-6">
                  <h6>Statistiques</h6>
                  <p>
                    <strong>Classes associées:</strong>
                    {{ getClassesCount(selectedFormation.id) }}
                  </p>
                  <p>
                    <strong>Créée le:</strong>
                    {{ new Date().toLocaleDateString() }}
                  </p>
                </div>
              </div>

              <!-- Section objectifs de la formation -->
              <div class="mt-3">
                <h6>Objectifs de la Formation</h6>
                <div class="card">
                  <div class="card-body">
                    <p class="mb-0">{{ selectedFormation.objectifs }}</p>
                  </div>
                </div>
              </div>

              <!-- Liste des classes utilisant cette formation -->
              <div
                v-if="getClassesByFormation(selectedFormation.id).length > 0"
                class="mt-3"
              >
                <h6>Classes utilisant cette formation</h6>
                <div class="list-group">
                  <!-- Boucle sur les classes associées -->
                  <div
                    v-for="classe in getClassesByFormation(
                      selectedFormation.id
                    )"
                    :key="classe.id"
                    class="list-group-item"
                  >
                    <div
                      class="d-flex justify-content-between align-items-center"
                    >
                      <div>
                        <strong>{{ classe.nom }}</strong>
                        <br />
                        <small class="text-muted">
                          {{ classe.nbParticipants }} participants •
                          {{ classe.lieu }}
                        </small>
                      </div>
                      <div>
                        <!-- Badge de l'école -->
                        <span class="badge bg-primary me-1">
                          {{ classe.ecole.nom }}
                        </span>
                        <!-- Badge du formateur -->
                        <span class="badge bg-warning text-dark">
                          {{ classe.formateur.prenom }}
                          {{ classe.formateur.nom }}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <button
                type="button"
                class="btn btn-secondary"
                @click="selectedFormation = null"
              >
                Fermer
              </button>
            </div>
          </div>
        </div>
      </div>

      <!-- Modal pour ajouter ou modifier une formation -->
      <div
        v-if="showAddForm || editingFormation"
        class="modal fade show d-block"
        style="background-color: rgba(173, 216, 230, 0.4)"
      >
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">
                {{
                  editingFormation
                   ? "Modifier la Formation"
                    : "Créer une Formation"
                }}
              </h5>
              <button
                type="button"
                class="btn-close"
                @click="closeModal"
              ></button>
            </div>
            <div class="modal-body">
              <!-- Formulaire de création/modification -->
              <form @submit.prevent="saveFormation">
                <div class="row">
                  <div class="col-md-6 mb-3">
                    <label class="form-label">Nom de la formation *</label>
                    <input
                      type="text"
                      class="form-control"
                      v-model="formationForm.nom"
                      required
                      placeholder="Ex: Java Débutant, Spring Boot Avancé"
                    />
                  </div>
                  <div class="col-md-3 mb-3">
                    <label class="form-label">Durée (heures) *</label>
                    <input
                      type="number"
                      class="form-control"
                      v-model="formationForm.duree"
                      min="14"
                      max="1500"
                      required
                    />
                    <small class="text-muted"
                      >Minimum 14 heures, maximum 1500 heures</small
                    >
                  </div>
                  <div class="col-md-3 mb-3">
                    <label class="form-label">Participants Max *</label>
                    <input
                      type="number"
                      class="form-control"
                      v-model="formationForm.nbParticipantsMax"
                      min="7"
                      max="100"
                      required
                    />
                    <small class="text-muted">Entre 7 et 100</small>
                  </div>
                </div>

                <div class="row">
                  <div class="col-md-6 mb-3">
                    <label class="form-label">Format *</label>
                    <select
                      class="form-select"
                      v-model="formationForm.format"
                      required
                    >
                      <option value="">Sélectionnez un format</option>
                      <option value="PRESENTIEL">Présentiel</option>
                      <option value="DISTANCIEL">Distanciel</option>
                    </select>
                  </div>
                </div>

                <div class="mb-3">
                  <label class="form-label">Objectifs de la formation *</label>
                  <textarea
                    class="form-control"
                    v-model="formationForm.objectifs"
                    rows="4"
                    required
                    placeholder="Décrivez les objectifs pédagogiques de cette formation..."
                  ></textarea>
                  <small class="text-muted">
                    {{ formationForm.objectifs.length }}/500 caractères
                  </small>
                </div>

                <div class="mb-3">
                  <small class="text-muted">* Champs obligatoires</small>
                </div>

                <!-- Messages de statut -->
                <div v-if="message" class="alert alert-success">
                  {{ message }}
                </div>
                <div v-if="error" class="alert alert-danger">
                  {{ error }}
                </div>
              </form>
            </div>
            <div class="modal-footer">
              <button
                type="button"
                class="btn btn-secondary"
                @click="closeModal"
              >
                Annuler
              </button>
              <button
                type="button"
                class="btn btn-info"
                @click="saveFormation"
                :disabled="saving"
              >
                {{
                  saving
                    ? "Sauvegarde..."
                    : editingFormation
                    ? "Modifier"
                    : "Créer"
                }}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { adminService } from '@/services/adminService'

export default {
  name: 'AdminFormationsView',
  data() {
    return {
      formations: [], // Liste des formations
      classes: [], // Liste des classes (pour les statistiques)
      loading: false, // État de chargement
      saving: false, // État de sauvegarde
      showAddForm: false, // Afficher formulaire d'ajout
      editingFormation: null, // Formation en cours d'édition
      selectedFormation: null, // Formation sélectionnée pour détails
      searchTerm: '', // Terme de recherche
      message: '', // Message de succès
      error: '', // Message d'erreur
      // Formulaire pour créer/modifier une formation
      formationForm: {
        nom: '',
        duree: 35,
        objectifs: '',
        nbParticipantsMax: 15,
        format: 'PRESENTIEL'
      }
    }
  },
  computed: {
    /**
     * Filtre les formations selon le terme de recherche
     * Recherche dans le nom, les objectifs et le format
     */
    filteredFormations() {
      if (!this.searchTerm) return this.formations

      const term = this.searchTerm.toLowerCase()
      return this.formations.filter(
        (formation) =>
          formation.nom.toLowerCase().includes(term) ||
          formation.objectifs.toLowerCase().includes(term) ||
          formation.format.toLowerCase().includes(term)
      )
    }
  },
  /**
   * Hook de cycle de vie : chargement des données au montage
   */
  async mounted() {
    await this.loadAllData()
  },
  methods: {
    /**
     * Charge toutes les données nécessaires (formations et classes)
     */
    async loadAllData() {
      this.loading = true
      try {
        // Charger formations et classes en parallèle
        const [formationsRes, classesRes] = await Promise.all([
          adminService.getAllFormations(),
          adminService.getAllClasses()
        ])

        this.formations = formationsRes.data
        this.classes = classesRes.data
      } catch (error) {
        console.error('Erreur chargement données:', error)
        this.error = 'Erreur lors du chargement des données'
      } finally {
        this.loading = false
      }
    },

    /**
     * Tronque un texte à une longueur maximale
     * @param {string} text - Texte à tronquer
     * @param {number} length - Longueur maximale
     * @returns {string} Texte tronqué
     */
    truncateText(text, length) {
      if (!text) return ''
      return text.length > length ? text.substring(0, length) + '...' : text
    },

    /**
     * Retourne le nombre de classes pour une formation donnée
     * @param {number} formationId - ID de la formation
     * @returns {number} Nombre de classes
     */
    getClassesCount(formationId) {
      return this.classes.filter(
        (classe) => classe.formation && classe.formation.id === formationId
      ).length
    },

    /**
     * Retourne les classes d'une formation donnée
     * @param {number} formationId - ID de la formation
     * @returns {Array} Liste des classes
     */
    getClassesByFormation(formationId) {
      return this.classes.filter(
        (classe) => classe.formation && classe.formation.id === formationId
      )
    },

    /**
     * Affiche les détails d'une formation
     * @param {Object} formation - Formation à afficher
     */
    viewFormationDetails(formation) {
      this.selectedFormation = formation
    },

    /**
     * Ouvre le formulaire d'édition pour une formation
     * @param {Object} formation - Formation à modifier
     */
    editFormation(formation) {
      this.editingFormation = formation
      this.formationForm = {
        nom: formation.nom,
        duree: formation.duree,
        objectifs: formation.objectifs,
        nbParticipantsMax: formation.nbParticipantsMax,
        format: formation.format
      }
    },

    /**
     * Sauvegarde une formation (création ou modification)
     */
    async saveFormation() {
      this.saving = true
      this.message = ''
      this.error = ''

      // DEBUG: Log des données envoyées
      console.log('📤 Sending formation data:', this.formationForm)

      try {
        if (this.editingFormation) {
          // Modification d'une formation existante
          await adminService.updateFormation(
            this.editingFormation.id,
            this.formationForm
          )
          this.message = 'Formation modifiée avec succès!'
        } else {
          // Création d'une nouvelle formation
          await adminService.createFormation(this.formationForm)
          this.message = 'Formation créée avec succès!'
        }

        // Recharger la liste après sauvegarde
        await this.loadAllData()

        // Fermer le modal après un délai
        setTimeout(() => {
          this.closeModal()
        }, 1500)
      } catch (error) {
        console.error('Erreur sauvegarde formation:', error)
        this.error =
          'Erreur lors de la sauvegarde: ' +
          (error.response?.data || error.message)
      } finally {
        this.saving = false
      }
    },

    /**
     * Supprime une formation après confirmation
     * @param {number} formationId - ID de la formation à supprimer
     */
    async deleteFormation(formationId) {
      // Vérifier si la formation est utilisée dans des classes
      const classesUsingFormation = this.getClassesByFormation(formationId)

      if (classesUsingFormation.length > 0) {
        alert(
          `Cette formation est utilisée dans ${classesUsingFormation.length} classe(s). Vous ne pouvez pas la supprimer.`
        )
        return
      }

      if (confirm('Êtes-vous sûr de vouloir supprimer cette formation ?')) {
        try {
          await adminService.deleteFormation(formationId)
          this.message = 'Formation supprimée avec succès!'
          await this.loadAllData()
        } catch (error) {
          console.error('Erreur suppression formation:', error)
          this.error =
            'Erreur lors de la suppression: ' +
            (error.response?.data || error.message)
        }
      }
    },

    /**
     * Ferme les modals et réinitialise les formulaires
     */
    closeModal() {
      this.showAddForm = false
      this.editingFormation = null
      this.selectedFormation = null
      this.formationForm = {
        nom: '',
        duree: 35,
        objectifs: '',
        nbParticipantsMax: 15,
        format: 'PRESENTIEL'
      }
      this.message = ''
      this.error = ''
    }
  }
}
</script>

<style scoped>
/* Conteneur principal de la page */
.admin-formations {
  padding: 20px;
  min-height: 100vh;
  background-color: #f7f8f9;
}

/* Arrière-plan des modals */
.modal-backdrop {
  background-color: rgba(250, 248, 248, 0.963);
}

/* Conteneur du tableau avec débordement contrôlé */
.table-responsive {
  border-radius: 8px;
  overflow: hidden;
}

/* Configuration de base du tableau */
.table {
  width: 100%;
  border-collapse: collapse;
  table-layout: fixed; /* Maintient la consistance des colonnes */
}

/* Alignement parfait des en-têtes et cellules */
.table th,
.table td {
  padding: 12px 16px; /* Padding identique */
  text-align: left;
  vertical-align: middle; /* Centre le texte verticalement */
}

/* Style distinct pour les en-têtes du tableau */
.table thead th {
  background-color: #f1f3f5;
  font-weight: 600;
  text-transform: uppercase;
  font-size: 0.9rem;
  color: #495057;
  border-bottom: 2px solid #dee2e6;
}

/* Bordures entre les lignes du tableau */
.table tr {
  border-bottom: 1px solid #dee2e6;
}

/* Alignement horizontal des boutons dans les cellules */
.table td .btn {
  vertical-align: middle;
  margin: 0 2px;
}

/* Alignement des badges dans les cellules */
.table td .badge {
  vertical-align: middle;
  margin: 0;
}

/* Supprime la bordure sur la dernière ligne */
.table tbody tr:last-child {
  border-bottom: none;
}

/* Style des petits boutons */
.btn-sm {
  padding: 0.25rem 0.5rem;
  font-size: 0.875rem;
}

/* Style des badges */
.badge {
  font-size: 0.75em;
}

/* Style des éléments de liste groupe */
.list-group-item {
  border-left: none;
}

/* Arrière-plan du corps des modals */
.modal-body {
  background-color: #bfd9ebd5;
}

/* Style des cartes */
.card {
  background: linear-gradient(#f6f9f7)
}

/* Style du contenu des modals */
.modal-content,
.modal-body,
.modal-footer {
  background-color: #ffffff;
  border: none;
}
</style>