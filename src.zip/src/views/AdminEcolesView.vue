<template>
  <div class="admin-ecoles">
    <div class="container-fluid">
      <!-- En-tête de la page -->
      <div class="row mb-4">
        <div class="col">
          <h1>🏫 Gestion des Écoles</h1>
          <p class="text-muted">
            Créez, modifiez et gérez les établissements scolaires
          </p>
        </div>
      <div class="col-auto">
          <button
            class="btn btn-secondary"
            @click="$router.push('/admin/dashboard')"
          >
            ← Retour Dashboard
          </button>
        </div>
    </div>
  </div>
      <!-- Bouton Ajouter et Recherche -->
      <div class="row mb-4 align-items-center">
  <div class="col d-flex align-items-center">
    <!-- Bouton Ajouter -->
    <button
      class="btn btn-primary"
      style="margin-right: 20px;"
      @click="showAddForm = true"
    >
      ➕ Ajouter une École
    </button>
    <!-- Input à côté du bouton, taille normale -->
    <input
      type="text"
      class="form-control"
      placeholder="Rechercher une école..."
      v-model="searchTerm"
      style="max-width: 300px;"
    />
  </div>
</div>
      <!-- Liste des écoles -->
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-body">
              <!-- Indicateur de chargement -->
              <div v-if="loading" class="text-center">
                <div class="spinner-border" role="status">
                  <span class="visually-hidden">Chargement...</span>
                </div>
              </div>

              <!-- Message si aucune école -->
              <div
                v-else-if="ecoles.length === 0"
                class="text-center text-muted"
              >
                <p>Aucune école créée</p>
                <button class="btn btn-warning" @click="showAddForm = true">
                  Créer la première école
                </button>
              </div>

              <!-- Tableau des écoles -->
              <div v-else>
                <div class="table-responsive">
                  <table class="table table-hover">
                    <thead>
                      <tr>
                        <th>Nom de l'école</th>
                        <th>Classes associées</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      <!-- Boucle sur les écoles filtrées -->
                      <tr v-for="ecole in filteredEcoles" :key="ecole.id">
                        <td>
                          <strong>{{ ecole.nom }}</strong>
                        </td>
                        <td>
                          <!-- Affiche le nombre de classes pour cette école -->
                          <span class="badge bg-primary">
                            {{ getClassesCount(ecole.id) }} classe(s)
                          </span>
                        </td>
                        <td>
                          <!-- Bouton Voir les détails -->
                          <button
                            class="btn btn-sm btn-outline-primary me-1"
                            @click="viewEcoleDetails(ecole)"
                            title="Voir les détails"
                          >
                            🔍
                          </button>
                          <!-- Bouton Modifier -->
                          <button
                            class="btn btn-sm btn-outline-secondary me-1"
                            @click="editEcole(ecole)"
                            title="Modifier"
                          >
                            ✏️
                          </button>
                          <!-- Bouton Supprimer (désactivé si l'école a des classes) -->
                          <button
                            class="btn btn-sm"
                            :class="
                              getClassesCount(ecole.id) > 0
                                ? 'btn-outline-secondary'
                                : 'btn-outline-danger'
                            "
                            @click="deleteEcole(ecole.id)"
                            :title="
                              getClassesCount(ecole.id) > 0
                                ? 'Impossible de supprimer - école utilisée'
                                : 'Supprimer'
                            "
                            :disabled="getClassesCount(ecole.id) > 0"
                          >
                            🗑️
                          </button>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Modal Détails École -->
      <div
        v-if="selectedEcole"
        class="modal fade show d-block"
        style="background-color: rgba(173, 216, 230, 0.4)"
      >
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">
                Détails de l'École: {{ selectedEcole.nom }}
              </h5>
              <button
                type="button"
                class="btn-close"
                @click="selectedEcole = null"
              ></button>
            </div>
            <div class="modal-body">
              <div class="row">
                <!-- Colonne informations générales -->
                <div class="col-md-6">
                  <h6>Informations Générales</h6>
                  <p><strong>Nom:</strong> {{ selectedEcole.nom }}</p>
                  <p><strong>ID:</strong> {{ selectedEcole.id }}</p>
                </div>
                <!-- Colonne statistiques -->
                <div class="col-md-6">
                  <h6>Statistiques</h6>
                  <p>
                    <strong>Classes associées:</strong>
                    {{ getClassesCount(selectedEcole.id) }}
                  </p>
                  <p>
                    <strong>Créée le:</strong>
                    {{ new Date().toLocaleDateString() }}
                  </p>
                </div>
              </div>

              <!-- Liste des classes de cette école -->
              <div
                v-if="getClassesByEcole(selectedEcole.id).length > 0"
                class="mt-3"
              >
                <h6>Classes de cette école</h6>
                <div class="list-group">
                  <!-- Boucle sur les classes de l'école -->
                  <div
                    v-for="classe in getClassesByEcole(selectedEcole.id)"
                    :key="classe.id"
                    class="list-group-item"
                  >
                    <div
                      class="d-flex justify-content-between align-items-center"
                    >
                      <div>
                        <strong>{{ classe.nom }}</strong>
                        <br />
                        <small class="text-muted">
                          {{ classe.nbParticipants }} participants •
                          {{ classe.lieu }}
                        </small>
                      </div>
                      <div>
                        <!-- Badge de la formation -->
                        <span class="badge bg-success me-1">
                          {{ classe.formation.nom }}
                        </span>
                        <!-- Badge du formateur -->
                        <span class="badge bg-warning text-dark">
                          {{ classe.formateur.prenom }}
                          {{ classe.formateur.nom }}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <!-- Message si aucune classe -->
              <div v-else class="mt-3">
                <div class="alert alert-info">
                  <p class="mb-0">
                    Aucune classe n'est actuellement associée à cette école.
                  </p>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <button
                type="button"
                class="btn btn-secondary"
                @click="selectedEcole = null"
              >
                Fermer
              </button>
            </div>
          </div>
        </div>
      </div>

      <!-- Modal Ajouter/Modifier École -->
      <div
        v-if="showAddForm || editingEcole"
        class="modal fade show d-block"
        style="background-color: rgba(173, 216, 230, 0.4)"
      >
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">
                {{ editingEcole ? "Modifier l'École" : "Ajouter une École" }}
              </h5>
              <button
                type="button"
                class="btn-close"
                @click="closeModal"
              ></button>
            </div>
            <div class="modal-body">
              <!-- Formulaire école -->
              <form @submit.prevent="saveEcole">
                <div class="mb-3">
                  <label class="form-label">Nom de l'école *</label>
                  <input
                    type="text"
                    class="form-control"
                    v-model="ecoleForm.nom"
                    required
                    placeholder="Ex: École Centrale, Université de Lyon"
                    :maxlength="150"
                  />
                  <small class="text-muted">Maximum 150 caractères</small>
                </div>

                <!-- Messages de succès/erreur -->
                <div v-if="message" class="alert alert-success">
                  {{ message }}
                </div>
                <div v-if="error" class="alert alert-danger">
                  {{ error }}
                </div>
              </form>
            </div>
            <div class="modal-footer">
              <button
                type="button"
                class="btn btn-secondary"
                @click="closeModal"
              >
                Annuler
              </button>
              <button
                type="button"
                class="btn btn-warning"
                @click="saveEcole"
                :disabled="saving"
              >
                {{
                  saving ? "Sauvegarde..." : editingEcole ? "Modifier" : "Créer"
                }}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
</template>

<script>
import { adminService } from '@/services/adminService'

export default {
  name: 'AdminEcolesView',
  data() {
    return {
      ecoles: [], // Liste des écoles
      classes: [], // Liste des classes (pour les statistiques)
      loading: false, // Indicateur de chargement
      saving: false, // Indicateur de sauvegarde
      showAddForm: false, // Afficher le formulaire d'ajout
      editingEcole: null, // École en cours de modification
      selectedEcole: null, // École sélectionnée pour voir les détails
      searchTerm: '', // Terme de recherche
      message: '', // Message de succès
      error: '', // Message d'erreur
      ecoleForm: {
        nom: '' // Formulaire de l'école (seul le nom est nécessaire)
      }
    }
  },
  computed: {
    /**
     * Filtre les écoles selon le terme de recherche
     */
    filteredEcoles() {
      if (!this.searchTerm) return this.ecoles

      const term = this.searchTerm.toLowerCase()
      return this.ecoles.filter((ecole) =>
        ecole.nom.toLowerCase().includes(term)
      )
    }
  },
  async mounted() {
    // Charger les données au montage du composant
    await this.loadAllData()
  },
  methods: {
    /**
     * Charge toutes les données nécessaires (écoles et classes)
     */
    async loadAllData() {
      this.loading = true
      try {
        // Charger les écoles et classes en parallèle
        const [ecolesRes, classesRes] = await Promise.all([
          adminService.getAllEcoles(),
          adminService.getAllClasses()
        ])

        this.ecoles = ecolesRes.data
        this.classes = classesRes.data
      } catch (error) {
        console.error('Erreur chargement données:', error)
        this.error = 'Erreur lors du chargement des données'
      } finally {
        this.loading = false
      }
    },

    /**
     * Retourne le nombre de classes pour une école donnée
     * @param {Number} ecoleId - ID de l'école
     * @returns {Number} Nombre de classes
     */
    getClassesCount(ecoleId) {
      return this.classes.filter(
        (classe) => classe.ecole && classe.ecole.id === ecoleId
      ).length
    },

    /**
     * Retourne les classes d'une école donnée
     * @param {Number} ecoleId - ID de l'école
     * @returns {Array} Liste des classes
     */
    getClassesByEcole(ecoleId) {
      return this.classes.filter(
        (classe) => classe.ecole && classe.ecole.id === ecoleId
      )
    },

    /**
     * Affiche les détails d'une école
     * @param {Object} ecole - École à afficher
     */
    viewEcoleDetails(ecole) {
      this.selectedEcole = ecole
    },

    /**
     * Prépare la modification d'une école
     * @param {Object} ecole - École à modifier
     */
    editEcole(ecole) {
      this.editingEcole = ecole
      this.ecoleForm = {
        nom: ecole.nom
      }
    },

    /**
     * Sauvegarde une école (création ou modification)
     */
    async saveEcole() {
      this.saving = true
      this.message = ''
      this.error = ''

      try {
        if (this.editingEcole) {
          // Modification d'une école existante
          await adminService.updateEcole(this.editingEcole.id, this.ecoleForm)
          this.message = 'École modifiée avec succès!'
        } else {
          // Création d'une nouvelle école
          await adminService.createEcole(this.ecoleForm)
          this.message = 'École créée avec succès!'
        }

        // Recharger la liste après sauvegarde
        await this.loadAllData()

        // Fermer le modal après un délai
        setTimeout(() => {
          this.closeModal()
        }, 1500)
      } catch (error) {
        console.error('Erreur sauvegarde école:', error)
        this.error =
          'Erreur lors de la sauvegarde: ' +
          (error.response?.data || error.message)
      } finally {
        this.saving = false
      }
    },

    /**
     * Supprime une école
     * @param {Number} ecoleId - ID de l'école à supprimer
     */
    async deleteEcole(ecoleId) {
      // Vérifier si l'école est utilisée dans des classes
      const classesUsingEcole = this.getClassesByEcole(ecoleId)

      if (classesUsingEcole.length > 0) {
        alert(
          `Cette école est utilisée dans ${classesUsingEcole.length} classe(s). Vous ne pouvez pas la supprimer.`
        )
        return
      }

      if (confirm('Êtes-vous sûr de vouloir supprimer cette école ?')) {
        try {
          await adminService.deleteEcole(ecoleId)
          this.message = 'École supprimée avec succès!'
          await this.loadAllData()
        } catch (error) {
          console.error('Erreur suppression école:', error)
          this.error =
            'Erreur lors de la suppression: ' +
            (error.response?.data || error.message)
        }
      }
    },

    /**
     * Ferme les modals et réinitialise les formulaires
     */
    closeModal() {
      this.showAddForm = false
      this.editingEcole = null
      this.selectedEcole = null
      this.ecoleForm = {
        nom: ''
      }
      this.message = ''
      this.error = ''
    }
  }
}
</script>

<style scoped>
.admin-ecoles {
  padding: 20px;
  min-height: 100vh;
  background-color: #f8f9fa;
}

.modal-backdrop {
  background-color: rgba(0, 0, 0, 0.5);
}

.table-responsive {
  border-radius: 8px;
  overflow: hidden;
}

.btn-sm {
  padding: 0.25rem 0.5rem;
  font-size: 0.875rem;
}

.badge {
  font-size: 0.75em;
}

.list-group-item {
  border-left: none;
}

.table {
  width: 100%;
  border-collapse: collapse;
  table-layout: fixed; /* Maintient la consistance des colonnes */
}

/* Alignement parfait des en-têtes et cellules */
.table th,
.table td {
  padding: 12px 16px; /* Padding identique */
  text-align: left;
  vertical-align: middle; /* Centre le texte verticalement */
}

/* Style distinct pour les en-têtes */
.table thead th {
  background-color: #f1f3f5;
  font-weight: 600;
  text-transform: uppercase;
  font-size: 0.9rem;
  color: #495057;
  border-bottom: 2px solid #dee2e6;
}

/* Suppression des espaces de bordure supplémentaires */
.table tr {
  border-bottom: 1px solid #dee2e6;
}

/* Alignement horizontal des boutons et badges */
.table td .btn {
  vertical-align: middle;
  margin: 0 2px;
}

/* Empêche le badge d'ajouter de la hauteur */
.table td .badge {
  vertical-align: middle;
  margin: 0;
}

/* Optionnel : garde le tableau compact et net */
.table tbody tr:last-child {
  border-bottom: none;
}
</style>