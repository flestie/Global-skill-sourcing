<template>
  <div class="competences">
    <div class="container-fluid px-4">
      <!-- En-tête de page -->
      <div class="row mb-4 align-items-center page-head">
        <div class="col">
          <h1>Mes Compétences</h1>
          <p class="text-muted">Gérez vos compétences et spécialités</p>
        </div>
        <div class="col-auto">
          <button class="btn btn-secondary" @click="$router.push('/dashboard')">
            ← Retour Dashboard
          </button>
        </div>
      </div>

      <div class="row">
        <!-- Section : Mes compétences actuelles -->
        <div class="col-md-6">
          <div class="card card-stats">
            <div class="card-header bg-primary text-white">
              <h5 class="mb-0">Mes Compétences</h5>
            </div>
            <div class="card-body">
              <!-- Indicateur de chargement -->
              <div v-if="loading" class="text-center">
                <div class="spinner-border" role="status">
                  <span class="visually-hidden">Chargement...</span>
                </div>
              </div>

              <!-- Message si aucune compétence -->
              <div
                v-else-if="mesCompetences.length === 0"
                class="text-center text-muted"
              >
                <p>Aucune compétence assignée</p>
                <p class="small">
                  Utilisez le formulaire à droite pour ajouter des compétences
                </p>
              </div>

              <!-- Liste des compétences assignées -->
              <div v-else>
                <!-- Conteneur horizontal pour les compétences -->
                <div class="competences-horizontal">
                  <!-- Boucle sur les compétences de l'utilisateur -->
                  <div
                    v-for="competence in mesCompetences"
                    :key="competence.id"
                    class="competence-block"
                  >
                    <!-- Nom de la compétence centré -->
                    <div class="competence-info text-center">
                      {{ competence.nom }}
                    </div>
                    <!-- Bouton de suppression -->
                    <button
                      class="btn btn-sm btn-danger"
                      title="Supprimer cette compétence"
                      @click="retirerCompetence(competence.id)"
                    >
                      Supprimer
                    </button>
                  </div>
                </div>

                <!-- Compteur des compétences -->
                <div class="mt-3 text-center">
                  <small class="text-muted">
                    {{ mesCompetences.length }} compétence(s) au total
                  </small>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Section : Ajouter des compétences -->
        <div class="col-md-6">
          <div class="card">
            <div class="card-header bg-success text-white">
              <h5 class="mb-0">Ajouter une Compétence</h5>
            </div>
            <div class="card-body">
              <!-- Message si aucune compétence disponible -->
              <div
                v-if="competencesDisponibles.length === 0"
                class="text-muted"
              >
                <p>Aucune compétence disponible à ajouter</p>
              </div>

              <!-- Liste des compétences disponibles -->
              <div v-else>
                <p class="small text-muted mb-3">
                  Sélectionnez une compétence à ajouter à votre profil
                </p>

                <!-- Grille des compétences disponibles -->
                <div class="add-list">
                  <!-- Boucle sur les compétences disponibles -->
                  <div
                    v-for="competence in competencesDisponibles"
                    :key="competence.id"
                    class="add-box"
                    :class="{ assigned: competenceDejaAssignee(competence.id) }"
                  >
                    <div class="add-box-body">
                      <!-- Nom de la compétence centré -->
                      <span class="add-name text-center w-100"> 
                        {{ competence.nom }}
                      </span>
                      <!-- Indicateur si déjà assignée -->
                      <span
                        v-if="competenceDejaAssignee(competence.id)"
                        class="badge assigned"
                      >Déjà assignée</span>
                    </div>
                    <!-- Bouton d'ajout -->
                    <button
                      class="btn-add"
                      :disabled="ajoutEnCours || competenceDejaAssignee(competence.id)"
                      @click="ajouterCompetence(competence.id)"
                    >
                      Ajouter la compétence
                    </button>
                  </div>
                </div>

                <!-- Messages de statut -->
                <div v-if="message" class="alert alert-success mt-3">
                  {{ message }}
                </div>
                <div v-if="error" class="alert alert-danger mt-3">
                  {{ error }}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Section : Statistiques -->
      <div class="row mt-4">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h5 class="mb-0">Statistiques</h5>
            </div>
            <div class="card-body">
              <div class="row text-center">
                <!-- Compétences maîtrisées -->
                <div class="col-md-4">
                  <h3>{{ mesCompetences.length }}</h3>
                  <p class="text-muted">Compétences maîtrisées</p>
                </div>
                <!-- Compétences disponibles -->
                <div class="col-md-4">
                  <h3>{{ competencesDisponibles.length }}</h3>
                  <p class="text-muted">Compétences disponibles</p>
                </div>
                <!-- Total compétences système -->
                <div class="col-md-4">
                  <h3>{{ totalCompetences }}</h3>
                  <p class="text-muted">Total compétences système</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
// Import des services d'authentification et de compétences
import { authService } from '@/services/authService'
import { competenceService } from '@/services/competenceService'

export default {
  name: 'CompetencesView',
  data() {
    return {
      user: {}, // Utilisateur connecté
      mesCompetences: [], // Compétences assignées à l'utilisateur
      competencesDisponibles: [], // Compétences disponibles pour l'ajout
      loading: false, // État de chargement
      ajoutEnCours: false, // État d'ajout en cours
      message: '', // Message de succès
      error: '' // Message d'erreur
    }
  },
  computed: {
    /**
     * Calcule le total des compétences dans le système
     */
    totalCompetences() {
      return this.mesCompetences.length + this.competencesDisponibles.length
    }
  },
  /**
   * Hook de cycle de vie : chargement des données au montage
   */
  async mounted() {
    // Récupération de l'utilisateur connecté
    this.user = authService.getCurrentUser()
    if (!this.user) {
      this.$router.push('/')
      return
    }
    // Chargement des compétences
    await this.loadCompetences()
  },
  methods: {
    /**
     * Charge les compétences de l'utilisateur et les compétences disponibles
     */
    async loadCompetences() {
      this.loading = true
      try {
        // Récupération des compétences de l'utilisateur
        const mesCompetencesResponse =
          await competenceService.getCompetencesByFormateur(
            this.user.formateur.id
          )
        this.mesCompetences = mesCompetencesResponse.data

        // Récupération de toutes les compétences du système
        const allCompetencesResponse =
          await competenceService.getAllCompetences()
        const toutesCompetences = allCompetencesResponse.data

        // Filtrage des compétences disponibles
        this.competencesDisponibles = toutesCompetences.filter(
          (comp) => !this.mesCompetences.some((mc) => mc.id === comp.id)
        )
      } catch (error) {
        console.error('Erreur chargement compétences:', error)
        this.error = 'Erreur lors du chargement des compétences'
        setTimeout(() => (this.error = ''), 5000)
      } finally {
        this.loading = false
      }
    },

    /**
     * Ajoute une compétence à l'utilisateur
     * @param {number} competenceId - ID de la compétence à ajouter
     */
    async ajouterCompetence(competenceId) {
      this.ajoutEnCours = true
      this.message = ''
      this.error = ''

      try {
        // Appel API pour ajouter la compétence
        await competenceService.addCompetenceToFormateur(
          this.user.formateur.id,
          competenceId
        )

        // Mise à jour des listes locales
        const addedCompetence = this.competencesDisponibles.find(c => c.id === competenceId)
        if (addedCompetence) {
          this.mesCompetences.push(addedCompetence)
          this.competencesDisponibles = this.competencesDisponibles.filter(c => c.id !== competenceId)
        }

        this.message = 'Compétence ajoutée avec succès!'
        setTimeout(() => (this.message = ''), 4000)
      } catch (error) {
        console.error('Erreur ajout compétence:', error)
        this.error =
          'Erreur lors de l\'ajout de la compétence: ' +
          (error.response?.data || error.message)
        setTimeout(() => (this.error = ''), 5000)
      } finally {
        this.ajoutEnCours = false
      }
    },

    /**
     * Retire une compétence de l'utilisateur
     * @param {number} competenceId - ID de la compétence à retirer
     */
    async retirerCompetence(competenceId) {
      this.message = ''
      this.error = ''
      try {
        // Appel API pour retirer la compétence
        await competenceService.removeCompetenceFromFormateur(
          this.user.formateur.id,
          competenceId
        )

        // Mise à jour des listes locales
        const competenceRetiree = this.mesCompetences.find(c => c.id === competenceId)
        this.mesCompetences = this.mesCompetences.filter(c => c.id !== competenceId)
        if (competenceRetiree) {
          this.competencesDisponibles.push(competenceRetiree)
        }

        this.message = 'Compétence supprimée avec succès !'
        setTimeout(() => (this.message = ''), 4000)
      } catch (error) {
        console.error('Erreur suppression compétence:', error)
        this.error =
          'Erreur lors de la suppression de la compétence: ' +
          (error.response?.data || error.message)
        setTimeout(() => (this.error = ''), 5000)
      }
    },

    /**
     * Vérifie si une compétence est déjà assignée à l'utilisateur
     * @param {number} competenceId - ID de la compétence à vérifier
     * @returns {boolean} True si la compétence est déjà assignée
     */
    competenceDejaAssignee(competenceId) {
      return this.mesCompetences.some((comp) => comp.id === competenceId)
    }
  }
}
</script>

<style scoped>
/* ---------- Variables de palette de couleurs calmes ---------- */
:root {
  --bg-main: #f5f7fa;
  --bg-card: #ffffff;
  --bg-header: #eef3f9;
  --primary: #4a90e2;
  --primary-light: #dce8f7;
  --success: #6274c5;
  --muted: #87a6c8;
  --border: #e1e7ed;
  --shadow-sm: 0 2px 4px rgba(0,0,0,.04);
  --shadow-md: 0 4px 12px rgba(0,0,0,.06);
  --radius: 10px;
  --transition: .25s ease;
}

/* Conteneur principal de la page */
.competences {
  min-height: 100vh;
  background: var(--bg-main);
  font-family: "Inter", "Segoe UI", Roboto, sans-serif;
}

/* Style de l'en-tête de page */
.page-head {
  background: var(--bg-card);
  border-radius: var(--radius);
  box-shadow: var(--shadow-sm);
  padding: 1.2rem 1.5rem;
  margin: 0 0 1.5rem;
}

/* Style du titre principal */
.page-head h1 {
  color: var(--primary);
  font-weight: 600;
  font-size: 1.75rem;
}

/* Style des boutons dans l'en-tête */
.page-head .btn {
  border-radius: 6px;
  padding: .45rem 1.1rem;
  font-size: .9rem;
  transition: var(--transition);
}
.page-head .btn:hover {
  transform: translateY(-2px);
  box-shadow: var(--shadow-md);
}

/* Style de base des cartes */
.card {
  background: var(--bg-card);
  border: 1px solid var(--border);
  border-radius: var(--radius);
  box-shadow: var(--shadow-sm);
  transition: var(--transition);
  height: 100%;
}
.card:hover {
  box-shadow: var(--shadow-md);
}

/* Style des en-têtes de carte */
.card-header {
  background: var(--bg-header) !important;
  color: var(--primary) !important;
  border-bottom: 1px solid var(--border);
  font-weight: 600;
  padding: .9rem 1.25rem;
}

/* Style des éléments de liste */
.list-group-item {
  border: none;
  border-radius: 8px !important;
  margin-bottom: .6rem;
  padding: .9rem 1.1rem;
  background: var(--bg-card);
  box-shadow: 0 1px 2px rgba(0,0,0,.03);
  transition: var(--transition);
  cursor: pointer;
}
.list-group-item:hover {
  background: var(--primary-light);
  transform: translateY(-2px);
  box-shadow: 0 4px 8px rgba(74,144,226,.12);
}

/* Style des éléments de liste assignés */
.list-group-item.bg-assigned {
  background: #e6f4ea !important;
  color: #1e7e34;
  cursor: default;
}
.list-group-item.bg-assigned:hover {
  transform: none;
  box-shadow: 0 1px 2px rgba(0,0,0,.03);
}

/* Style des badges */
.badge {
  font-size: .75rem;
  font-weight: 500;
  padding: .35em .65em;
  border-radius: 50rem;
}

/* Style du bouton de suppression */
.btn-danger {
  background-color: #dc3545;
  border: none;
  padding: 0.3rem 0.7rem;
  font-size: 0.8rem;
  border-radius: 6px;
  transition: background 0.2s ease;
}
.btn-danger:hover {
  background-color: #bb2d3b;
}

/* Conteneur de la liste d'ajout */
.add-list {
  display: flex;
  flex-wrap: wrap;
  gap: 1.2rem;
}

/* Style des boîtes d'ajout de compétences */
.add-box {
  flex: 1 1 260px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  background: #e8f1ff;
  border: 1px solid #c2d6ff;
  border-radius: 10px;
  padding: 1rem 1.2rem 1.2rem;
  transition: background 0.25s ease, transform 0.25s ease;
}
.add-box:hover:not(.assigned) {
  background: #bfd5ff;
  transform: translateY(-3px);
}
.add-box.assigned {
  background: #f0f0f0;
  border-color: #dcdcdc;
  cursor: not-allowed;
}

/* Corps des boîtes d'ajout */
.add-box-body {
  display: flex;
  flex-direction: column; /* Changement en colonne pour centrer */
  justify-content: center;
  align-items: center;
  margin-bottom: 0.8rem;
  gap: 0.5rem; /* Espace entre le nom et le badge */
}

/* Nom des compétences dans les boîtes d'ajout - CENTRÉ */
.add-name {
  font-weight: 500;
  text-align: center;
  width: 100%;
}

/* Style du bouton d'ajout */
.btn-add {
  align-self: center;
  background: #4a90e2;
  color: #fff;
  border: none;
  border-radius: 6px;
  padding: 0.4rem 1rem;
  font-size: 0.85rem;
  transition: background 0.2s ease;
}
.btn-add:hover:not(:disabled) {
  background: #3a7bc8;
}
.btn-add:disabled {
  background: #a0b9dd;
  cursor: not-allowed;
}

/* Style du badge "Déjà assignée" */
.badge.assigned {
  background: #7f8c9b;
  font-size: 0.75rem;
}

/* Conteneur horizontal pour les compétences */
.competences-horizontal {
  display: flex;
  gap: 1rem;
  overflow-x: auto;
  padding-bottom: 0.5rem;
}

/* Style des blocs de compétences */
.competence-block {
  flex: 1;
  min-width: 200px;
  background: #e6f0ff;
  border: 1px solid #c5d8ff;
  border-radius: 10px;
  padding: 1rem;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  gap: 0.5rem;
  transition: background 0.25s ease, transform 0.25s ease;
}

/* Effet de survol sur les blocs de compétences */
.competence-block:hover {
  background: #bcd2ff;
  transform: translateY(-3px);
}

/* Style des informations de compétence - CENTRÉ */
.competence-info {
  font-weight: 500;
  color: #2a4e8a;
  text-align: center;
  width: 100%;
  margin-bottom: 0.6rem;
}
</style>