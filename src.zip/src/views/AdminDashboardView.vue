<template>
  <div class="admin-dashboard">
    <div class="container-fluid">

      <!-- En-tête de la page -->
      <div class="row mb-4">
        <div class="col">
          <h1>🏛️ Tableau de bord administrateur</h1>
          <p class="text-muted">Bienvenue, {{ user.email }}</p>
        </div>
      </div>

      <!-- Cartes de statistiques -->
      <div class="row mb-5 g-3">

        <!-- Formateurs -->
        <div class="col">
          <div
            class="card text-white h-100 stat-card"
            :style="{ background: 'linear-gradient(135deg, #020617 0%, #22d3ee 100%)' }"
          >
            <div class="card-body d-flex flex-column justify-content-center align-items-center text-center">
              <h6 class="card-title text-white-50 mb-2">Formateurs</h6>
              <h2 class="mb-0">{{ stats.nbFormateurs }}</h2>
              <small>Formateurs actifs</small>

              <div class="icon-circle">
                <img
                  src="https://img.icons8.com/3d-fluency/94/training.png"
                  alt="Icône formateur"
                />
              </div>
            </div>
          </div>
        </div>

        <!-- Classes -->
        <div class="col">
          <div
            class="card text-white h-100 stat-card"
            :style="{ background: 'linear-gradient(135deg, #020617 0%, #22c55e 100%)' }"
          >
            <div class="card-body d-flex flex-column justify-content-center align-items-center text-center">
              <h6 class="card-title text-white-50 mb-2">Classes</h6>
              <h2 class="mb-0">{{ stats.nbClasses }}</h2>
              <small>Classes créées</small>

              <div class="icon-circle">
                <img
                  src="https://img.icons8.com/3d-fluency/94/students.png"
                  alt="Icône classes"
                />
              </div>
            </div>
          </div>
        </div>

        <!-- Formations -->
        <div class="col">
          <div
            class="card text-white h-100 stat-card"
            :style="{ background: 'linear-gradient(135deg, #020617 0%, #a855f7 100%)' }"
          >
            <div class="card-body d-flex flex-column justify-content-center align-items-center text-center">
              <h6 class="card-title text-white-50 mb-2">Formations</h6>
              <h2 class="mb-0">{{ stats.nbFormations }}</h2>
              <small>Programmes actifs</small>

              <div class="icon-circle">
                <img
                  src="https://img.icons8.com/3d-fluency/94/graduation-cap.png"
                  alt="Icône formation"
                />
              </div>
            </div>
          </div>
        </div>

        <!-- Écoles -->
        <div class="col">
          <div
            class="card text-white h-100 stat-card"
            :style="{ background: 'linear-gradient(135deg, #020617 0%, #f97316 100%)' }"
          >
            <div class="card-body d-flex flex-column justify-content-center align-items-center text-center">
              <h6 class="card-title text-white-50 mb-2">Écoles</h6>
              <h2 class="mb-0">{{ stats.nbEcoles }}</h2>
              <small>Écoles partenaires</small>

              <div class="icon-circle">
                <img
                  src="https://img.icons8.com/3d-fluency/94/school-building.png"
                  alt="Icône école"
                />
              </div>
            </div>
          </div>
        </div>

        <!-- Sessions -->
        <div class="col">
          <div
            class="card text-white h-100 stat-card"
            :style="{ background: 'linear-gradient(135deg, #020617 0%, #38bdf8 100%)' }"
          >
            <div class="card-body d-flex flex-column justify-content-center align-items-center text-center">
              <h6 class="card-title text-white-50 mb-2">Sessions</h6>
              <h2 class="mb-0">{{ stats.nbSessions }}</h2>
              <small>Sessions programmées</small>

              <div class="icon-circle">
                <img
                  src="https://img.icons8.com/3d-fluency/94/calendar.png"
                  alt="Icône session"
                />
              </div>
            </div>
          </div>
        </div>

      </div>

      <!-- Actions administrateur (navigation rapide) -->
      <div class="row g-3 mb-4">
        <div class="col" v-for="action in actions" :key="action.title">
          <div class="card h-100 text-center d-flex flex-column action-card">
            <div class="card-body d-flex flex-column justify-content-between">
              <div>
                <h5>{{ action.icon }} {{ action.title }}</h5>
                <p class="text-muted action-text">{{ action.text }}</p>
              </div>
              <button
                class="btn w-100"
                :class="action.btnClass"
                @click="$router.push(action.route)"
              >
                Gérer
              </button>
            </div>
          </div>
        </div>
      </div>

      <!-- Activité récente -->
      <div class="row mt-4">
        <div class="col-12">
          <div class="card activity-card">
            <div class="card-header">
              <h5 class="mb-0">Activité récente</h5>
            </div>
            <div class="card-body">
              <div v-if="loading" class="text-center">
                <div class="spinner-border"></div>
              </div>

              <p
                v-else-if="recentActivity.length === 0"
                class="text-muted text-center"
              >
                Aucune activité récente
              </p>

              <div v-else>
                <div class="list-group">
                  <div
                    v-for="activity in recentActivity"
                    :key="activity.id"
                    class="list-group-item"
                  >
                    <div class="d-flex w-100 justify-content-between">
                      <h6 class="mb-1">{{ activity.title }}</h6>
                      <small>{{ activity.time }}</small>
                    </div>
                    <p class="mb-0">{{ activity.description }}</p>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </div>
      </div>

    </div>
  </div>
</template>

<script>
import { authService } from '@/services/authService'
import { adminService } from '@/services/adminService'

export default {
  name: 'AdminDashboard',

  data () {
    return {
      user: {},
      stats: {
        nbFormateurs: 0,
        nbClasses: 0,
        nbFormations: 0,
        nbEcoles: 0,
        nbSessions: 0
      },
      recentActivity: [],
      loading: false,
      actions: [
        {
          title: 'Formateurs',
          text: 'Gérer les formateurs',
          route: '/admin/formateurs',
          icon: '👨‍🏫',
          btnClass: 'btn-primary'
        },
        {
          title: 'Classes',
          text: 'Gérer les classes',
          route: '/admin/classes',
          icon: '👥',
          btnClass: 'btn-success'
        },
        {
          title: 'Formations',
          text: 'Gérer les formations',
          route: '/admin/formations',
          icon: '🎓',
          btnClass: 'btn-info'
        },
        {
          title: 'Écoles',
          text: 'Gérer les écoles',
          route: '/admin/ecoles',
          icon: '🏫',
          btnClass: 'btn-warning'
        },
        {
          title: 'Sessions',
          text: 'Gérer les sessions',
          route: '/admin/sessions',
          icon: '📅',
          btnClass: 'btn-primary'
        }
      ]
    }
  },

  async mounted () {
    this.user = authService.getCurrentUser()
    if (!this.user?.admin) {
      this.$router.push('/')
      return
    }
    await this.loadAdminData()
  },

  methods: {
    async loadAdminData () {
      this.loading = true
      try {
        const [
          formateursRes,
          classesRes,
          formationsRes,
          ecolesRes,
          sessionsRes
        ] = await Promise.all([
          adminService.getAllFormateurs(),
          adminService.getAllClasses(),
          adminService.getAllFormations(),
          adminService.getAllEcoles(),
          adminService.getAllSessions()
        ])

        this.stats.nbFormateurs = formateursRes.data.length
        this.stats.nbClasses = classesRes.data.length
        this.stats.nbFormations = formationsRes.data.length
        this.stats.nbEcoles = ecolesRes.data.length
        this.stats.nbSessions = sessionsRes.data.length
      } catch (error) {
        console.error('Erreur lors du chargement du tableau de bord :', error)
      } finally {
        this.loading = false
      }
    }
  }
}
</script>

<style scoped>
/* ======= FOND GÉNÉRAL NÉON ======= */
.admin-dashboard {
  padding: 2rem;
  min-height: 100vh;
  background: radial-gradient(circle at top left, #4f46e5 0%, #020617 45%) , 
              radial-gradient(circle at bottom right, #ec4899 0%, #020617 55%);
  position: relative;
  overflow-x: hidden;
}

/* ======= TITRES ET TEXTES DU HEADER ======= */
h1 {
  font-size: 2.5rem;
  font-weight: 800;
  background: linear-gradient(135deg, #ffffff 0%, #e5e7eb 100%);
  -webkit-background-clip: text;
  background-clip: text;
  color: transparent;
  margin-bottom: 0.5rem;
  text-shadow: 0 2px 6px rgba(15, 23, 42, 0.45);
}

.text-muted {
  color: rgba(226, 232, 240, 0.9) !important;
  font-size: 1.05rem;
  font-weight: 500;
}

/* ======= CARTES DE STATISTIQUES ======= */
.stat-card {
  border: none;
  border-radius: 20px;
  overflow: hidden;
  position: relative;
  transition: all 0.35s cubic-bezier(0.19, 1, 0.22, 1);
  box-shadow: 0 18px 40px rgba(15, 23, 42, 0.55);
  min-height: 260px;
  margin-bottom: 2.6rem;
}

.stat-card::before {
  content: '';
  position: absolute;
  inset: 0;
  background: radial-gradient(circle at top left, rgba(255, 255, 255, 0.35), transparent 55%);
  opacity: 0.35;
  pointer-events: none;
}

.stat-card::after {
  content: '';
  position: absolute;
  inset: 0;
  background: linear-gradient(120deg, transparent 0%, rgba(255, 255, 255, 0.35) 40%, transparent 80%);
  opacity: 0;
  transform: translateX(-40%);
  transition: opacity 0.4s ease, transform 0.4s ease;
}

.stat-card:hover {
  transform: translateY(-12px) scale(1.02);
  box-shadow: 0 26px 60px rgba(15, 23, 42, 0.85);
}

.stat-card:hover::after {
  opacity: 1;
  transform: translateX(15%);
}

.stat-card .card-body {
  position: relative;
  z-index: 1;
  padding: 2rem 1.5rem;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  text-align: center;
  min-height: 260px;
  padding-bottom: 95px; /* place pour le cercle icône */
}

.card-title {
  font-size: 0.9rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.12em;
  margin-bottom: 0.8rem;
  color: rgba(248, 250, 252, 0.9) !important;
}

.stat-card h2 {
  font-size: 3rem;
  font-weight: 800;
  margin-bottom: 0.5rem;
  line-height: 1;
  background: linear-gradient(135deg, #ffffff 0%, #e5e7eb 100%);
  -webkit-background-clip: text;
  background-clip: text;
  color: transparent;
  text-shadow: 0 4px 14px rgba(15, 23, 42, 0.8);
}

.stat-card small {
  font-size: 0.9rem;
  color: rgba(241, 245, 249, 0.95);
}

/* ======= CERCLES AVEC ICÔNE 3D ======= */
.icon-circle {
  position: absolute;
  bottom: 18px;
  left: 50%;
  transform: translateX(-50%);
  width: 80px;
  height: 80px;
  border-radius: 50%;
  background: rgba(15, 23, 42, 0.65);
  box-shadow: 0 10px 30px rgba(15, 23, 42, 0.85);
  display: flex;
  align-items: center;
  justify-content: center;
  border: 2px solid rgba(148, 163, 184, 0.8);
  transition: all 0.35s ease;
}

.icon-circle img {
  width: 42px;
  height: 42px;
  object-fit: contain;
  filter: drop-shadow(0 6px 12px rgba(15, 23, 42, 0.9));
  transition: transform 0.3s ease;
}

.stat-card:hover .icon-circle {
  transform: translateX(-50%) translateY(-6px) scale(1.07);
  border-color: rgba(248, 250, 252, 0.9);
}

.stat-card:hover .icon-circle img {
  transform: scale(1.08);
}

/* ======= CARTES D’ACTION (BAS) ======= */
.action-card {
  background: rgba(15, 23, 42, 0.7);
  border-radius: 18px;
  border: 1px solid rgba(148, 163, 184, 0.35);
  box-shadow: 0 14px 32px rgba(15, 23, 42, 0.8);
  overflow: hidden;
  transition: all 0.3s ease;
}

.action-card:hover {
  transform: translateY(-6px);
  box-shadow: 0 22px 46px rgba(15, 23, 42, 0.95);
}

.action-card .card-body {
  padding: 1.75rem 1.5rem;
}

.action-card h5 {
  font-size: 1.1rem;
  font-weight: 600;
  color: #e5e7eb;
  margin-bottom: 0.6rem;
}

.action-text {
  color: rgba(148, 163, 184, 0.95) !important;
  font-size: 0.9rem;
}
/* ======= BOUTONS (outline + effet de vague au survol) ======= */
.btn {
  position: relative;
  display: inline-flex;
  align-items: center;
  justify-content: center;

  padding: 0.75rem 1.8rem;
  font-weight: 600;
  font-size: 0.95rem;
  border-radius: 999px;

  background: transparent;
  border-width: 2px;
  border-style: solid;

  cursor: pointer;
  overflow: hidden;

  color: #e5e7eb;
  z-index: 0;
}

/* pseudo-élément pour l’animation de remplissage */
.btn::before {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: inherit;

  /* au départ, la vague est complètement à gauche, hors du bouton */
  transform: translateX(-120%) skewX(-20deg);
  transform-origin: left center;

  transition: transform 0.45s ease-out;
  z-index: -1;
}

/* texte au-dessus de la vague */
.btn > * {
  position: relative;
  z-index: 1;
}

/* état au survol : la vague traverse et remplit le bouton */
.btn:hover::before {
  transform: translateX(0) skewX(-20deg);
}

.btn:focus-visible {
  outline: 2px solid rgba(248, 250, 252, 0.9);
  outline-offset: 2px;
}

/* ----- Variante : bleu (Formateurs / Sessions) ----- */
.btn-primary {
  border-color: #60a5fa;          /* bleu clair pour le contour */
  color: #60a5fa;
  background: transparent;
}

.btn-primary::before {
  background: linear-gradient(135deg, #3b82f6 0%, #6366f1 100%);
}

.btn-primary:hover {
  color: #f9fafb;                /* texte blanc quand rempli */
}

/* ----- Variante : vert (Classes) ----- */
.btn-success {
  border-color: #4ade80;
  color: #4ade80;
  background: transparent;
}

.btn-success::before {
  background: linear-gradient(135deg, #22c55e 0%, #16a34a 100%);
}

.btn-success:hover {
  color: #f9fafb;
}

/* ----- Variante : cyan (Formations) ----- */
.btn-info {
  border-color: #22d3ee;
  color: #22d3ee;
  background: transparent;
}

.btn-info::before {
  background: linear-gradient(135deg, #06b6d4 0%, #0e7490 100%);
}

.btn-info:hover {
  color: #f9fafb;
}

/* ----- Variante : orange (Écoles) ----- */
.btn-warning {
  border-color: #fb923c;
  color: #fb923c;
  background: transparent;
}

.btn-warning::before {
  background: linear-gradient(135deg, #f97316 0%, #c2410c 100%);
}

.btn-warning:hover {
  color: #f9fafb;
}

/* ======= ACTIVITÉ RÉCENTE ======= */
.activity-card {
  background: rgba(15, 23, 42, 0.85);
  border-radius: 20px;
  border: 1px solid rgba(148, 163, 184, 0.4);
  box-shadow: 0 16px 40px rgba(15, 23, 42, 0.95);
  overflow: hidden;
}

.activity-card .card-header {
  background: linear-gradient(90deg, rgba(15, 23, 42, 0.9), rgba(30, 64, 175, 0.9));
  border-bottom: 1px solid rgba(148, 163, 184, 0.4);
  padding: 1.2rem 1.8rem;
}

.activity-card .card-header h5 {
  margin: 0;
  color: #e5e7eb;
  font-weight: 600;
  font-size: 1.1rem;
}

.activity-card .card-body {
  padding: 1.8rem;
}

/* ======= LISTE D’ACTIVITÉS ======= */
.list-group {
  border-radius: 12px;
  overflow: hidden;
}

.list-group-item {
  background: rgba(15, 23, 42, 0.9);
  border: 1px solid rgba(75, 85, 99, 0.6);
  border-bottom: none;
  padding: 1.1rem 1.4rem;
  transition: all 0.25s ease;
  position: relative;
}

.list-group-item:last-child {
  border-bottom: 1px solid rgba(75, 85, 99, 0.6);
}

.list-group-item::before {
  content: '';
  position: absolute;
  left: 0;
  top: 0;
  bottom: 0;
  width: 3px;
  background: linear-gradient(180deg, #4f46e5, #ec4899);
  opacity: 0;
  transition: opacity 0.25s ease;
}

.list-group-item:hover {
  background: rgba(15, 23, 42, 0.98);
  transform: translateX(6px);
}

.list-group-item:hover::before {
  opacity: 1;
}

.list-group-item h6 {
  color: #e5e7eb;
  font-weight: 600;
  margin-bottom: 0.4rem;
}

.list-group-item p {
  color: rgba(148, 163, 184, 0.95);
  margin: 0;
}

.list-group-item small {
  color: rgba(148, 163, 184, 0.9);
}

/* ======= SPINNER ======= */
.spinner-border {
  width: 3rem;
  height: 3rem;
  border-width: 0.3em;
  color: #6366f1;
}

/* ======= RESPONSIVE ======= */
@media (max-width: 768px) {
  .admin-dashboard {
    padding: 1.25rem;
  }

  h1 {
    font-size: 2.1rem;
  }

  .stat-card {
    min-height: 240px;
  }

  .stat-card .card-body {
    min-height: 240px;
    padding-bottom: 85px;
  }

  .stat-card h2 {
    font-size: 2.4rem;
  }

  .icon-circle {
    width: 70px;
    height: 70px;
    bottom: 16px;
  }

  .icon-circle img {
    width: 36px;
    height: 36px;
  }
}

/* ======= ANIMATION D’ENTRÉE ======= */
@keyframes fadeInUp {
  from {
    opacity: 0;
    transform: translateY(28px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.stat-card,
.action-card,
.activity-card {
  animation: fadeInUp 0.6s ease-out;
}
</style>
