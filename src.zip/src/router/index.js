import { createRouter, createWebHistory } from 'vue-router'

// --- VUES ---
import HomeView from '@/views/HomeView.vue'
import DashboardView from '@/views/DashboardView.vue'

import AdminDashboardView from '@/views/AdminDashboardView.vue'
import AdminFormateursView from '@/views/AdminFormateursView.vue'
import AdminClassesView from '@/views/AdminClassesView.vue'
import AdminFormationsView from '@/views/AdminFormationsView.vue'
import AdminEcolesView from '@/views/AdminEcolesView.vue'

// 👇👇👇 این را اضافه کن
import AdminSessionsView from '@/views/AdminSessionsView.vue'

import ClassesView from '@/views/ClassesView.vue'
import CompetencesView from '@/views/CompetencesView.vue'
import TrajetsView from '@/views/TrajetsView.vue'

import ChangePasswordView from '@/views/ChangePasswordView.vue'

import { authService } from '@/services/authService'

const routes = [
  {
    path: '/',
    name: 'home',
    component: HomeView
  },
  {
    path: '/dashboard',
    name: 'dashboard',
    component: DashboardView,
    meta: { requiresAuth: true }
  },

  // ----- ADMIN -----
  {
    path: '/admin/dashboard',
    name: 'admin-dashboard',
    component: AdminDashboardView,
    meta: { requiresAdmin: true }
  },
  {
    path: '/admin/formateurs',
    name: 'admin-formateurs',
    component: AdminFormateursView,
    meta: { requiresAdmin: true }
  },
  {
    path: '/admin/classes',
    name: 'admin-classes',
    component: AdminClassesView,
    meta: { requiresAdmin: true }
  },
  {
    path: '/admin/formations',
    name: 'admin-formations',
    component: AdminFormationsView,
    meta: { requiresAdmin: true }
  },
  {
    path: '/admin/ecoles',
    name: 'admin-ecoles',
    component: AdminEcolesView,
    meta: { requiresAdmin: true }
  },

  // ⭐⭐⭐ این Route که نبود → مشکل همین بود ⭐⭐⭐
  {
    path: '/admin/sessions',
    name: 'admin-sessions',
    component: AdminSessionsView,
    meta: { requiresAdmin: true }
  },

  // ----- FORMATEUR -----
  {
    path: '/classes',
    name: 'classes',
    component: ClassesView,
    meta: { requiresAuth: true }
  },
  {
    path: '/competences',
    name: 'competences',
    component: CompetencesView,
    meta: { requiresAuth: true }
  },
  {
    path: '/trajets',
    name: 'trajets',
    component: TrajetsView,
    meta: { requiresAuth: true }
  },

  {
    path: '/change-password',
    name: 'change-password',
    component: ChangePasswordView,
    meta: { requiresAuth: true }
  }
]

const router = createRouter({
  history: createWebHistory('/'),
  routes
})

router.beforeEach((to, from, next) => {
  const isAuth = authService.isAuthenticated()
  const user = authService.getCurrentUser()
  const mustChange = authService.mustChangePassword()

  if (to.meta.requiresAuth && !isAuth) {
    return next('/')
  }

  if (to.meta.requiresAdmin && (!isAuth || !user?.admin)) {
    return next('/')
  }

  if (isAuth && mustChange && to.path !== '/change-password') {
    return next('/change-password')
  }

  if (isAuth && !mustChange && to.path === '/change-password') {
    return next(authService.redirectAfterLogin())
  }

  next()
})

export default router
