import { createApp } from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'

// Import global styles
import '@/assets/styles/global.css'

createApp(App).use(store).use(router).mount('#app')
