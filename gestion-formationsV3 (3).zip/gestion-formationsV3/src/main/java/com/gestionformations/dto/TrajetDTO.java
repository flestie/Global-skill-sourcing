package com.gestionformations.dto;

import java.util.List;

/**
 * DTO (Data Transfer Object) pour les trajets
 * Utilisé pour l'API REST - évite les problèmes de sérialisation JSON
 * Contient seulement les données nécessaires pour le frontend
 */
public class TrajetDTO {
    private Long id;
    private double distance;
    private String correspondances;
    private String villeDepart;
    private String villeArrivee;
    private Long formateurId; // Juste l'ID, pas l'objet Formateur entier
    private List<String> badgesUtilises;
    private List<PreuveInfoDTO> preuves; // ← AJOUTE CE CHAMP

    // ====================
    // CONSTRUCTEURS
    // ====================

    public TrajetDTO() {}

    /**
     * Constructeur complet avec tous les champs
     */
    public TrajetDTO(Long id, double distance, String correspondances, 
                    String villeDepart, String villeArrivee, Long formateurId,
                    List<String> badgesUtilises, List<PreuveInfoDTO> preuves) { // ← AJOUTE preuves
        this.id = id;
        this.distance = distance;
        this.correspondances = correspondances;
        this.villeDepart = villeDepart;
        this.villeArrivee = villeArrivee;
        this.formateurId = formateurId;
        this.badgesUtilises = badgesUtilises;
        this.preuves = preuves; // ← AJOUTE
    }

    // ====================
    // GETTERS & SETTERS
    // ====================

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public double getDistance() { return distance; }
    public void setDistance(double distance) { this.distance = distance; }

    public String getCorrespondances() { return correspondances; }
    public void setCorrespondances(String correspondances) { this.correspondances = correspondances; }

    public String getVilleDepart() { return villeDepart; }
    public void setVilleDepart(String villeDepart) { this.villeDepart = villeDepart; }

    public String getVilleArrivee() { return villeArrivee; }
    public void setVilleArrivee(String villeArrivee) { this.villeArrivee = villeArrivee; }

    public Long getFormateurId() { return formateurId; }
    public void setFormateurId(Long formateurId) { this.formateurId = formateurId; }

    public List<String> getBadgesUtilises() { return badgesUtilises; }
    public void setBadgesUtilises(List<String> badgesUtilises) { this.badgesUtilises = badgesUtilises; }

    // AJOUTE CES GETTERS/SETTERS
    public List<PreuveInfoDTO> getPreuves() { return preuves; }
    public void setPreuves(List<PreuveInfoDTO> preuves) { this.preuves = preuves; }
}