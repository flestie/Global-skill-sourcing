package com.gestionformations.dto;

public class FormationInfoDTO {
    private Long id;
    private String nom;
    private int duree;
    private String format;

    public FormationInfoDTO() {}
    public FormationInfoDTO(Long id, String nom, int duree, String format) {
        this.id = id;
        this.nom = nom;
        this.duree = duree;
        this.format = format;
    }
    
    public Long getId() { return id; }
    public String getNom() { return nom; }
    public void setNom(String nom) { this.nom = nom; }
    public int getDuree() { return duree; }
    public void setDuree(int duree) { this.duree = duree; }
    public String getFormat() { return format; }
    public void setFormat(String format) { this.format = format; }
}