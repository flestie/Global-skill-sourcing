package com.gestionformations.dto;

import java.util.List;

/**
 * DTO pour la création de nouveaux trajets Ne contient pas l'ID (généré
 * automatiquement) Le formateurId est passé dans l'URL, pas dans le JSON
 */
public class CreateTrajetDTO {
	private double distance;
	private String correspondances;
	private String villeDepart;
	private String villeArrivee;
	private List<String> badgesUtilises;

	// ====================
	// CONSTRUCTEURS
	// ====================

	public CreateTrajetDTO() {
	}

	public CreateTrajetDTO(double distance, String correspondances, String villeDepart, String villeArrivee) {
		this.distance = distance;
		this.correspondances = correspondances;
		this.villeDepart = villeDepart;
		this.villeArrivee = villeArrivee;
	}

	// ====================
	// GETTERS & SETTERS
	// ====================

	public double getDistance() {
		return distance;
	}

	public void setDistance(double distance) {
		this.distance = distance;
	}

	public String getCorrespondances() {
		return correspondances;
	}

	public void setCorrespondances(String correspondances) {
		this.correspondances = correspondances;
	}

	public String getVilleDepart() {
		return villeDepart;
	}

	public void setVilleDepart(String villeDepart) {
		this.villeDepart = villeDepart;
	}

	public String getVilleArrivee() {
		return villeArrivee;
	}

	public void setVilleArrivee(String villeArrivee) {
		this.villeArrivee = villeArrivee;
	}

	public List<String> getBadgesUtilises() {
		return badgesUtilises;
	}

	public void setBadgesUtilises(List<String> badgesUtilises) {
		this.badgesUtilises = badgesUtilises;
	}
}