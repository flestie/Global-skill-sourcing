package com.gestionformations.dto;

public class CompetenceDTO {
	private Long id;
	private String nom;

	// Constructeurs
	public CompetenceDTO() {
	}

	public CompetenceDTO(Long id, String nom) {
		this.id = id;
		this.nom = nom;
	}

	// Getters/Setters (sans setId)
	public Long getId() {
		return id;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}
}