package com.gestionformations.dto;

public class MfaSetupDTO {
    private String qrCodeUrl;
    private String secret;
    private boolean enabled;
    
    // Constructeurs
    public MfaSetupDTO() {}
    
    public MfaSetupDTO(String qrCodeUrl, String secret, boolean enabled) {
        this.qrCodeUrl = qrCodeUrl;
        this.secret = secret;
        this.enabled = enabled;
    }
    
    // Getters/Setters
    public String getQrCodeUrl() { return qrCodeUrl; }
    public void setQrCodeUrl(String qrCodeUrl) { this.qrCodeUrl = qrCodeUrl; }
    public String getSecret() { return secret; }
    public void setSecret(String secret) { this.secret = secret; }
    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean enabled) { this.enabled = enabled; }
}