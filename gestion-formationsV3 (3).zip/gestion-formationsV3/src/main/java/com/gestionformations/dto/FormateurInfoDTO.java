package com.gestionformations.dto;

import java.util.List;

public class FormateurInfoDTO {
    private Long id;
    private String nom;
    private String prenom;
    private String email;
    private List<CompetenceInfoDTO> competences; // ← AJOUT

    public FormateurInfoDTO() {}
    
    public FormateurInfoDTO(Long id, String nom, String prenom, String email, 
                           List<CompetenceInfoDTO> competences) {
        this.id = id;
        this.nom = nom;
        this.prenom = prenom;
        this.email = email;
        this.competences = competences;
    }
    
    // Getters/Setters
    public Long getId() { return id; }
    public String getNom() { return nom; }
    public void setNom(String nom) { this.nom = nom; }
    public String getPrenom() { return prenom; }
    public void setPrenom(String prenom) { this.prenom = prenom; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public List<CompetenceInfoDTO> getCompetences() { return competences; }
    public void setCompetences(List<CompetenceInfoDTO> competences) { this.competences = competences; }
}