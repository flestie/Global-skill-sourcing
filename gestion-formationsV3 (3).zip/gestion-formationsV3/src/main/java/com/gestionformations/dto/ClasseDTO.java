package com.gestionformations.dto;

public class ClasseDTO {
    private Long id;
    private String nom;
    private int nbParticipants;
    private String lieu;
    private Long ecoleId;
    private Long formationId;
    private Long formateurId;

    // Constructeurs + Getters/Setters
    public ClasseDTO() {}
    
    public ClasseDTO(Long id, String nom, int nbParticipants, String lieu,
                    Long ecoleId, Long formationId, Long formateurId) {
        this.id = id;
        this.nom = nom;
        this.nbParticipants = nbParticipants;
        this.lieu = lieu;
        this.ecoleId = ecoleId;
        this.formationId = formationId;
        this.formateurId = formateurId;
    }

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public int getNbParticipants() {
		return nbParticipants;
	}

	public void setNbParticipants(int nbParticipants) {
		this.nbParticipants = nbParticipants;
	}

	public String getLieu() {
		return lieu;
	}

	public void setLieu(String lieu) {
		this.lieu = lieu;
	}

	public Long getEcoleId() {
		return ecoleId;
	}

	public void setEcoleId(Long ecoleId) {
		this.ecoleId = ecoleId;
	}

	public Long getFormationId() {
		return formationId;
	}

	public void setFormationId(Long formationId) {
		this.formationId = formationId;
	}

	public Long getFormateurId() {
		return formateurId;
	}

	public void setFormateurId(Long formateurId) {
		this.formateurId = formateurId;
	}

	public Long getId() {
		return id;
	}
    
    
}