package com.gestionformations.dto;

import java.util.ArrayList;
import java.util.List;

public class PreuveInfoDTO {
    private Long id;
    private String fileName;

    public PreuveInfoDTO() {}

    public PreuveInfoDTO(Long id, String fileName) {
        this.id = id;
        this.fileName = fileName;
    }

    // Getters/Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getFileName() { return fileName; }
    public void setFileName(String fileName) { this.fileName = fileName; }
}