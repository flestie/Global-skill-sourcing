package com.gestionformations.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public class FormationDTO {
    private Long id; // Pas de validation pour l'ID (généré automatiquement)

    @NotBlank(message = "Le nom de la formation est obligatoire")
    @Size(min = 2, max = 200, message = "Le nom doit contenir entre 2 et 200 caractères")
    private String nom;

    @Min(value = 14, message = "La durée doit être d'au moins 14 heures")
    @Max(value = 1500, message = "La durée ne peut pas dépasser 1500 heures")
    private int duree;

    @NotBlank(message = "Les objectifs sont obligatoires")
    @Size(min = 10, message = "Les objectifs doivent contenir au moins 10 caractères")
    private String objectifs;

    @Min(value = 7, message = "Le nombre maximum de participants doit être d'au moins 7")
    @Max(value = 100, message = "Le nombre maximum de participants ne peut pas dépasser 100")
    private int nbParticipantsMax;

    @NotBlank(message = "Le format est obligatoire")
    @Pattern(regexp = "PRESENTIEL|DISTANCIEL", message = "Le format doit être PRESENTIEL ou DISTANCIEL")
    private String format;

    // Constructeurs + Getters/Setters
    public FormationDTO() {}
    
    public FormationDTO(Long id, String nom, int duree, String objectifs, 
                       int nbParticipantsMax, String format) {
        this.id = id;
        this.nom = nom;
        this.duree = duree;
        this.objectifs = objectifs;
        this.nbParticipantsMax = nbParticipantsMax;
        this.format = format;
    }

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public int getDuree() {
		return duree;
	}

	public void setDuree(int duree) {
		this.duree = duree;
	}

	public String getObjectifs() {
		return objectifs;
	}

	public void setObjectifs(String objectifs) {
		this.objectifs = objectifs;
	}

	public int getNbParticipantsMax() {
		return nbParticipantsMax;
	}

	public void setNbParticipantsMax(int nbParticipantsMax) {
		this.nbParticipantsMax = nbParticipantsMax;
	}

	public String getFormat() {
		return format;
	}

	public void setFormat(String format) {
		this.format = format;
	}

	public Long getId() {
		return id;
	}
    
    
}