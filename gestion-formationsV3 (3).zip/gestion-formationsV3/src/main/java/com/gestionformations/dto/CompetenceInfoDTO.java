package com.gestionformations.dto;

public class CompetenceInfoDTO {
    private Long id;
    private String nom;

    public CompetenceInfoDTO() {}
    public CompetenceInfoDTO(Long id, String nom) {
        this.id = id;
        this.nom = nom;
    }
    
    public Long getId() { return id; }
    public String getNom() { return nom; }
    public void setNom(String nom) { this.nom = nom; }
}