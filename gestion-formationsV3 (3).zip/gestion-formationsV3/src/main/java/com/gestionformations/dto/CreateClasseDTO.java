package com.gestionformations.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class CreateClasseDTO {
    @NotBlank(message = "Le nom de la classe est obligatoire")
    @Size(min = 2, max = 150, message = "Le nom doit contenir entre 2 et 150 caractères")
    private String nom;

    @Min(value = 7, message = "Le nombre de participants doit être d'au moins 7")
    @Max(value = 50, message = "Le nombre de participants ne peut pas dépasser 50")
    private int nbParticipants;

    @Size(max = 200, message = "Le lieu ne doit pas dépasser 200 caractères")
    private String lieu;

    @NotNull(message = "L'ID de l'école est obligatoire")
    private Long ecoleId;

    @NotNull(message = "L'ID de la formation est obligatoire")
    private Long formationId;

    @NotNull(message = "L'ID du formateur est obligatoire")
    private Long formateurId;

	// Constructeurs
	public CreateClasseDTO() {
	}

	public CreateClasseDTO(String nom, int nbParticipants, String lieu, Long ecoleId, Long formationId,
			Long formateurId) {
		this.nom = nom;
		this.nbParticipants = nbParticipants;
		this.lieu = lieu;
		this.ecoleId = ecoleId;
		this.formationId = formationId;
		this.formateurId = formateurId;
	}

	// Getters/Setters
	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public int getNbParticipants() {
		return nbParticipants;
	}

	public void setNbParticipants(int nbParticipants) {
		this.nbParticipants = nbParticipants;
	}

	public String getLieu() {
		return lieu;
	}

	public void setLieu(String lieu) {
		this.lieu = lieu;
	}

	public Long getEcoleId() {
		return ecoleId;
	}

	public void setEcoleId(Long ecoleId) {
		this.ecoleId = ecoleId;
	}

	public Long getFormationId() {
		return formationId;
	}

	public void setFormationId(Long formationId) {
		this.formationId = formationId;
	}

	public Long getFormateurId() {
		return formateurId;
	}

	public void setFormateurId(Long formateurId) {
		this.formateurId = formateurId;
	}
}