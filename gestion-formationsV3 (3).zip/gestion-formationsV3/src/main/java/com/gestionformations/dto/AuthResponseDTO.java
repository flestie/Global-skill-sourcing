package com.gestionformations.dto;

public class AuthResponseDTO {
    private String token;
    private String type = "Bearer";
    private boolean mfaRequired;
    private String message;
    private UserDTO user;
    // Indique si l'utilisateur doit changer son mot de passe
    private boolean mustChangePassword;

    
    // Constructeurs
    public AuthResponseDTO() {}
    
    public AuthResponseDTO(String token, boolean mfaRequired, String message) {
        this.token = token;
        this.mfaRequired = mfaRequired;
        this.message = message;
    }
    
    public AuthResponseDTO(String token, UserDTO user) {
        this.token = token;
        this.mfaRequired = false;
        this.user = user;
    }
    
    // Getters/Setters
    public String getToken() { return token; }
    public void setToken(String token) { this.token = token; }
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
    public boolean isMfaRequired() { return mfaRequired; }
    public void setMfaRequired(boolean mfaRequired) { this.mfaRequired = mfaRequired; }
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
    public UserDTO getUser() { return user; }
    public void setUser(UserDTO user) { this.user = user; }
    public boolean isMustChangePassword() {
        return mustChangePassword;
    }

    public void setMustChangePassword(boolean mustChangePassword) {
        this.mustChangePassword = mustChangePassword;
    }

}