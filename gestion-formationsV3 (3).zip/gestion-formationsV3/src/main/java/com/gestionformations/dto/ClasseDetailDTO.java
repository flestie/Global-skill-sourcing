package com.gestionformations.dto;

public class ClasseDetailDTO {
    private Long id;
    private String nom;
    private int nbParticipants;
    private String lieu;
    
    // Informations basiques de l'école (juste ID + nom)
    private EcoleInfoDTO ecole;
    
    // Informations basiques de la formation (ID + nom + durée)
    private FormationInfoDTO formation;
    
    // Informations basiques du formateur (ID + nom + prénom)
    private FormateurInfoDTO formateur;

    // Constructeurs
    public ClasseDetailDTO() {}
    
    public ClasseDetailDTO(Long id, String nom, int nbParticipants, String lieu,
                          EcoleInfoDTO ecole, FormationInfoDTO formation, FormateurInfoDTO formateur) {
        this.id = id;
        this.nom = nom;
        this.nbParticipants = nbParticipants;
        this.lieu = lieu;
        this.ecole = ecole;
        this.formation = formation;
        this.formateur = formateur;
    }

    // Getters/Setters
    public Long getId() { return id; }
    public String getNom() { return nom; }
    public void setNom(String nom) { this.nom = nom; }
    public int getNbParticipants() { return nbParticipants; }
    public void setNbParticipants(int nbParticipants) { this.nbParticipants = nbParticipants; }
    public String getLieu() { return lieu; }
    public void setLieu(String lieu) { this.lieu = lieu; }
    public EcoleInfoDTO getEcole() { return ecole; }
    public void setEcole(EcoleInfoDTO ecole) { this.ecole = ecole; }
    public FormationInfoDTO getFormation() { return formation; }
    public void setFormation(FormationInfoDTO formation) { this.formation = formation; }
    public FormateurInfoDTO getFormateur() { return formateur; }
    public void setFormateur(FormateurInfoDTO formateur) { this.formateur = formateur; }
}