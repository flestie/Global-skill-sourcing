package com.gestionformations.dto;

import java.time.LocalDate;

public class SessionDTO {
	private Long id;
	private String nom;
	private String horaire;
	private LocalDate dateDebutCours;
	private LocalDate dateFinCours;
	private LocalDate dateDebutStage;
	private LocalDate dateFinStage;
	private Long classeId;

	// Constructeurs
	public SessionDTO() {
	}

	public SessionDTO(Long id, String nom, String horaire, LocalDate dateDebutCours, LocalDate dateFinCours,
			LocalDate dateDebutStage, LocalDate dateFinStage, Long classeId) {
		this.id = id;
		this.nom = nom;
		this.horaire = horaire;
		this.dateDebutCours = dateDebutCours;
		this.dateFinCours = dateFinCours;
		this.dateDebutStage = dateDebutStage;
		this.dateFinStage = dateFinStage;
		this.classeId = classeId;
	}

	// Getters/Setters (sans setId)
	public Long getId() {
		return id;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getHoraire() {
		return horaire;
	}

	public void setHoraire(String horaire) {
		this.horaire = horaire;
	}

	public LocalDate getDateDebutCours() {
		return dateDebutCours;
	}

	public void setDateDebutCours(LocalDate dateDebutCours) {
		this.dateDebutCours = dateDebutCours;
	}

	public LocalDate getDateFinCours() {
		return dateFinCours;
	}

	public void setDateFinCours(LocalDate dateFinCours) {
		this.dateFinCours = dateFinCours;
	}

	public LocalDate getDateDebutStage() {
		return dateDebutStage;
	}

	public void setDateDebutStage(LocalDate dateDebutStage) {
		this.dateDebutStage = dateDebutStage;
	}

	public LocalDate getDateFinStage() {
		return dateFinStage;
	}

	public void setDateFinStage(LocalDate dateFinStage) {
		this.dateFinStage = dateFinStage;
	}

	public Long getClasseId() {
		return classeId;
	}

	public void setClasseId(Long classeId) {
		this.classeId = classeId;
	}
}