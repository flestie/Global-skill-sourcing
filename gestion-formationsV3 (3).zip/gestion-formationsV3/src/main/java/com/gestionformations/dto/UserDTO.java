package com.gestionformations.dto;

public class UserDTO {
    private Long id;
    private String email;
    private boolean mfaEnabled;
    private FormateurDTO formateur;
    private boolean admin;
    
    // Constructeurs
    public UserDTO() {}
    
    public UserDTO(Long id, String email, boolean mfaEnabled, FormateurDTO formateur, boolean admin) {
        this.id = id;
        this.email = email;
        this.mfaEnabled = mfaEnabled;
        this.formateur = formateur;
        this.admin = admin;
    }
    
    // Getters/Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public boolean isMfaEnabled() { return mfaEnabled; }
    public void setMfaEnabled(boolean mfaEnabled) { this.mfaEnabled = mfaEnabled; }
    public FormateurDTO getFormateur() { return formateur; }
    public void setFormateur(FormateurDTO formateur) { this.formateur = formateur; }
    public boolean isAdmin() { return admin; }
    public void setAdmin(boolean admin) { this.admin = admin; }
}