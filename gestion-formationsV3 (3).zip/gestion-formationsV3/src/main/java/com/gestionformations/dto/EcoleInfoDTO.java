package com.gestionformations.dto;

public class EcoleInfoDTO {
    private Long id;
    private String nom;

    public EcoleInfoDTO() {}
    public EcoleInfoDTO(Long id, String nom) {
        this.id = id;
        this.nom = nom;
    }
    
    public Long getId() { return id; }
    public String getNom() { return nom; }
    public void setNom(String nom) { this.nom = nom; }
}