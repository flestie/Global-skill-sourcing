package com.gestionformations.dto;

public class BadgeDTO {
    private Long id;
    private String nom;
    private String description;
    private String type;
    
    // Constructeurs
    public BadgeDTO() {}
    
    public BadgeDTO(Long id, String nom, String description, String type) {
        this.id = id;
        this.nom = nom;
        this.description = description;
        this.type = type;
    }
    
    // Getters/Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getNom() { return nom; }
    public void setNom(String nom) { this.nom = nom; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
}