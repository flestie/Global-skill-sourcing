package com.gestionformations.config;

import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import com.gestionformations.data.Badge;
import com.gestionformations.data.Formateur;
import com.gestionformations.data.User;
import com.gestionformations.repository.BadgeRepository;
import com.gestionformations.repository.FormateurRepository;
import com.gestionformations.repository.UserRepository;

@Component
public class DataInitializer implements CommandLineRunner {
    
    private final UserRepository userRepository;
    private final FormateurRepository formateurRepository;
    private final PasswordEncoder passwordEncoder;
    private final BadgeRepository badgeRepository;
    
    public DataInitializer(UserRepository userRepository, 
                          FormateurRepository formateurRepository,
                          PasswordEncoder passwordEncoder,
                          BadgeRepository badgeRepository) {
        this.userRepository = userRepository;
        this.formateurRepository = formateurRepository;
        this.passwordEncoder = passwordEncoder;
        this.badgeRepository = badgeRepository;
    }
    
    @Override
    public void run(String... args) throws Exception {
        // Creer un formateur de test
        if (!userRepository.existsByEmail("jean.dupont@example.com")) {
            Formateur formateur = new Formateur();
            formateur.setNom("Dupont");
            formateur.setPrenom("Jean");
            formateur.setEmail("jean.dupont@example.com");
            formateur.setTelephone("0601020304");
            formateur.setVille("Paris");
            formateur.setCode_postal("75000");
            
            formateurRepository.save(formateur);
            
            // Creer un utilisateur associe
            User user = new User();
            user.setEmail("jean.dupont@example.com");
            user.setPassword(passwordEncoder.encode("123456")); // Mot de passe crypte
            user.setFormateur(formateur);
            user.setEnabled(true);
            user.getRoles().add("ROLE_FORMATEUR");
            
            userRepository.save(user);
            
            System.out.println("=== DONNEES DE TEST CREEES ===");
            System.out.println("Email: jean.dupont@example.com");
            System.out.println("Mot de passe: password123");
            System.out.println("==============================");
        }
        
        // Creer l'admin (toujours le creer, meme si d'autres utilisateurs existent)
        if (!userRepository.existsByEmail("admin@formations.com")) {
            User admin = new User();
            admin.setEmail("admin@formations.com");
            admin.setPassword(passwordEncoder.encode("admin123"));
            admin.setEnabled(true);
            admin.setAdmin(true); // ← NOUVEAU: Flag admin
            admin.setMustChangePassword(false);
            admin.getRoles().add("ROLE_FORMATEUR");
            
            userRepository.save(admin);
            
            System.out.println("=== ADMIN CREE ===");
            System.out.println("Email: admin@formations.com");
            System.out.println("Mot de passe: admin123");
            System.out.println("==================");
        }
        
        // Creer un deuxieme formateur pour tester les restrictions
        // Vérifier par email dans UserRepository au lieu de FormateurRepository
        if (!userRepository.existsByEmail("marie.martin@example.com")) {
            Formateur formateur2 = new Formateur();
            formateur2.setNom("Martin");
            formateur2.setPrenom("Marie");
            formateur2.setEmail("marie.martin@example.com");
            formateur2.setTelephone("0605060708");
            formateur2.setVille("Lyon");
            formateur2.setCode_postal("69000");
            
            formateurRepository.save(formateur2);
            
            User user2 = new User();
            user2.setEmail("marie.martin@example.com");
            user2.setPassword(passwordEncoder.encode("password456"));
            user2.setFormateur(formateur2);
            user2.setEnabled(true);
            user2.getRoles().add("ROLE_FORMATEUR");
            
            userRepository.save(user2);
            
            System.out.println("=== DEUXIEME FORMATEUR CREE ===");
            System.out.println("Email: marie.martin@example.com");
            System.out.println("Mot de passe: password456");
            System.out.println("===============================");
        }
        
     // Après la création des utilisateurs, ajoute:
        if (badgeRepository.count() == 0) {
            Badge badge1 = new Badge("Badge Péage A13", "Péage autoroute A13", "peage");
            Badge badge2 = new Badge("Badge Métro", "Pass Navigo Métro", "transport");
            Badge badge3 = new Badge("Badge Bus", "Pass Bus RATP", "transport");
            
            badgeRepository.save(badge1);
            badgeRepository.save(badge2);
            badgeRepository.save(badge3);
            
            System.out.println("=== BADGES DE TEST CREES ===");
        }
    }
}