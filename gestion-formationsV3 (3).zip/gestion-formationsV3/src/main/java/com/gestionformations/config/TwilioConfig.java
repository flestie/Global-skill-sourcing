package com.gestionformations.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
// Déclare une classe de configuration Spring qui sera peuplée par les propriétés commençant par "twilio"
import org.springframework.context.annotation.Configuration;
// Permet d'appliquer des validations (@NotBlank) aux propriétés liées
import org.springframework.validation.annotation.Validated;

import jakarta.validation.constraints.NotBlank;

/**
 * TwilioConfig — bean de configuration regroupant les credentials Twilio.
 *
 * Utilise @ConfigurationProperties(prefix="twilio") pour lier automatiquement :
 *  - twilio.account-sid
 *  - twilio.auth-token
 *  - twilio.phone-number
 *
 * La validation empêche le démarrage si une propriété requise est manquante.
 */
@Configuration                       // enregistre ce bean comme configuration Spring
@ConfigurationProperties(prefix = "twilio") // lie les propriétés avec le préfixe "twilio"
@Validated                           // active la validation JSR-380 (NotBlank, etc.)
public class TwilioConfig {

    // SID du compte Twilio (ex: ACxxx...). Obligatoire.
    @NotBlank(message = "twilio.account-sid must be provided, doit etre fourni")
    private String accountSid;

    // Token d'authentification Twilio. Obligatoire.
    @NotBlank(message = "twilio.auth-token must be provided, doit etre fourni")
    private String authToken;

    // Numéro Twilio utilisé pour l'envoi (ex: +33...). Obligatoire.
    @NotBlank(message = "twilio.phone-number must be provided")
    private String phoneNumber;

    // -------- Getters & Setters nécessaires pour @ConfigurationProperties --------

    // Getter pour accountSid
    public String getAccountSid() {
        return accountSid;
    }

    // Setter pour accountSid (Spring appelle ce setter lors du binding)
    public void setAccountSid(String accountSid) {
        this.accountSid = accountSid;
    }

    // Getter pour authToken
    public String getAuthToken() {
        return authToken;
    }

    // Setter pour authToken (Spring appelle ce setter lors du binding)
    public void setAuthToken(String authToken) {
        this.authToken = authToken;
    }

    // Getter pour phoneNumber
    public String getPhoneNumber() {
        return phoneNumber;
    }

    // Setter pour phoneNumber (Spring appelle ce setter lors du binding)
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
}