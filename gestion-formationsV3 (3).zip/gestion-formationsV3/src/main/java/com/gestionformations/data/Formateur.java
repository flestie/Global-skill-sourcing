package com.gestionformations.data;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.OneToMany;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

@Entity
public class Formateur implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "idFormateur")
	private Long id;
	
	@NotBlank(message = "Le nom du formateur est obligatoire")
	@Column(name ="nomFormateur", nullable = false, length = 100)
	private String nom;
	
	@NotBlank(message = "Le prénom du formateur est obligatoire")
	@Column(name ="prenomFormateur", nullable = false, length = 100)
	private String prenom;
	
	
	@NotBlank(message = "L'email est obligatoire")
	@Email(message = "L'email doit être valide")
	@Column(unique = true, nullable = false, length=150)
	private String email;
	
	
	@NotBlank(message = "Le téléphone est obligatoire")
	@Size(max = 20, message = "Le téléphone ne doit pas dépasser 20 caractères")
	@Column(nullable = false, length = 20)
	private String telephone;
	
	@Size(max = 100, message = "La ville ne doit pas dépasser 100 caractères")
	@Column(length = 100)
	private String ville;
	
	@Size(max = 10, message = "Le code postal ne doit pas dépasser 10 caractères")
	@Column(length = 10)
	private String code_postal;

	
	@OneToMany(mappedBy = "formateur")
	private List<Classe> classes = new ArrayList<>();
	
	// Relation Formateur - competence
	//creation table de jointure +  association de cles etrangeres
	@ManyToMany
	@JsonManagedReference
	@JoinTable(name = "formateur_competence", // Nom de la table de jointure
	joinColumns = @JoinColumn(name = "idFormateur"), // clé étrangere vers Formation
	inverseJoinColumns = @JoinColumn(name = "idCompetence") // clé étrangère vers Formateur
		)
	
	
	
	
	private List<Competence> competences = new ArrayList<>();
	
	public Formateur() {
		super();
	}

	public Formateur(String nom, String prenom, String email, String telephone, String ville,
			String code_postal) {
		super();
		this.nom = nom;
		this.prenom = prenom;
		this.email = email;
		this.telephone = telephone;
		this.ville = ville;
		this.code_postal = code_postal;
	}

	public Long getId() {
		return id;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getTelephone() {
		return telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public String getVille() {
		return ville;
	}

	public void setVille(String ville) {
		this.ville = ville;
	}

	public String getCode_postal() {
		return code_postal;
	}

	public void setCode_postal(String code_postal) {
		this.code_postal = code_postal;
	}

	
	public List<Competence> getCompetences() {
		return competences;
	}

	public void setCompetences(List<Competence> competences) {
		this.competences = competences;
	}

	public List<Classe> getClasses() {
		return classes;
	}

	public void setClasses(List<Classe> classes) {
		this.classes = classes;
	}

	@Override
	public String toString() {
		return "Formateur [id=" + id + ", nom=" + nom + ", prenom=" + prenom + ", email=" + email + ", telephone="
				+ telephone + ", ville=" + ville + ", code_postal=" + code_postal + "]";
	}
	
	
}
