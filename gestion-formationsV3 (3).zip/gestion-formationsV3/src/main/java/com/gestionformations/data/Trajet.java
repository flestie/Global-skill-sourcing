package com.gestionformations.data;

import java.util.ArrayList;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;

/**
 * Entité JPA représentant un trajet dans la base de données
 * Un trajet appartient à un formateur et peut utiliser plusieurs badges
 */
@Entity
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Trajet {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private double distance; // en kilomètres

    @Column(length = 200)
    private String correspondances; // ex: "Bus 12, Métro ligne 3"

    @Column(nullable = false, length = 100)
    private String villeDepart;

    @Column(nullable = false, length = 100)
    private String villeArrivee;

    /**
     * Liste des badges utilisés pour ce trajet
     * Stockée dans une table séparée trajet_badges
     * Un trajet peut utiliser plusieurs badges (ex: badge aller, badge retour)
     */
    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(
        name = "trajet_badges", 
        joinColumns = @JoinColumn(name = "trajet_id")
    )
    @Column(name = "badge_numero")
    private List<String> badgesUtilises = new ArrayList<>();
    
    /**
     * Relation Many-to-One avec Formateur
     * Un trajet appartient à un formateur, un formateur peut avoir plusieurs trajets
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "formateur_id", nullable = false)
    private Formateur formateur;
    
    @OneToMany(mappedBy = "trajet", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Preuve> preuves = new ArrayList<>();
    

    // ====================
    // CONSTRUCTEURS
    // ====================

    public Trajet() {}

    public Trajet(double distance, String correspondances, String villeDepart, 
                 String villeArrivee, Formateur formateur) {
        this.distance = distance;
        this.correspondances = correspondances;
        this.villeDepart = villeDepart;
        this.villeArrivee = villeArrivee;
        this.formateur = formateur;
    }

    // ====================
    // GETTERS & SETTERS
    // ====================

    public Long getId() { return id; }
    
    public double getDistance() { return distance; }
    public void setDistance(double distance) { this.distance = distance; }
    
    public String getCorrespondances() { return correspondances; }
    public void setCorrespondances(String correspondances) { this.correspondances = correspondances; }
    
    public String getVilleDepart() { return villeDepart; }
    public void setVilleDepart(String villeDepart) { this.villeDepart = villeDepart; }
    
    public String getVilleArrivee() { return villeArrivee; }
    public void setVilleArrivee(String villeArrivee) { this.villeArrivee = villeArrivee; }
    
    public Formateur getFormateur() { return formateur; }
    public void setFormateur(Formateur formateur) { this.formateur = formateur; }
    
    public List<String> getBadgesUtilises() { return badgesUtilises; }
    public void setBadgesUtilises(List<String> badgesUtilises) { this.badgesUtilises = badgesUtilises; }
    
    public List<Preuve> getPreuves() { return preuves; }
    public void setPreuves(List<Preuve> preuves) { this.preuves = preuves; }

    @Override
    public String toString() {
        return "Trajet [id=" + id + ", distance=" + distance + "km, de " + villeDepart + " à " + villeArrivee + "]";
    }
}