package com.gestionformations.data;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.validation.constraints.NotBlank;


@Entity
public class Ecole implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "idEcole")
	private Long id;
	
	@NotBlank(message = "Nom de l'ecole est obligatoire")
	@Column(name ="nomEcole", nullable = false, length = 150)
	private String nom;

	// J'utilise List ici pour conserver l'ordre d'insertion
	// Avec un HashSet, les doublons seraient évités uniquement si equals et hashCode
	// sont correctement redéfinis dans l'entité
	@OneToMany(mappedBy = "ecole") 
	private List<Classe> classes = new ArrayList<>();
	
	public Ecole() {
		super();
	}

	public Ecole(@NotBlank(message = "Nom de l'ecole est obligatoire") String nom) {
		super();
		this.nom = nom;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public Long getId() {
		return id;
	}

	@Override
	public String toString() {
		return "Ecole [id=" + id + ", nom=" + nom + "]";
	}
	
	

}
