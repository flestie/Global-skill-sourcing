package com.gestionformations.data;

public enum Format {
    DISTANCIEL,
    PRESENTIEL
}
