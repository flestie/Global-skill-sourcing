package com.gestionformations.data;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.validation.constraints.NotBlank;


@Entity
public class Competence implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "idCompetence")
	private Long id;
	
	@NotBlank(message = "Libille du competence est obligatoire")
	@Column(name ="libelleCompetence", nullable = false, length = 100)
	private String nom;

	// relation Competence - Formateurs
	@ManyToMany(mappedBy = "competences")
	@JsonBackReference
	private Set<Formateur> formateurs = new HashSet<>();
	
	
	public Competence() {
		super();
	}

	public Competence(@NotBlank(message = "Libille du competence est obligatoire") String nom) {
		super();
		this.nom = nom;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public Long getId() {
		return id;
	}

	@Override
	public String toString() {
		return "Competence [id=" + id + ", libelle=" + nom + "]";
	}
	
	

}
