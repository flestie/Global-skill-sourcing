package com.gestionformations.data;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.OneToMany;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;



@Entity
public class Formation implements Serializable {

	private static final long serialVersionUID = 1L;
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "idFormation")
	private Long id;
	
	@NotBlank(message = "Le nom de la formation est obligatoire")
	@Column(name = "nomFormation", nullable = false, length = 200)
	private String nom;
	
	@Min(value = 35, message = "La durée doit être d'au moins 35 heures")
	@Column(nullable = false)
	private int duree;
	
	
	@NotBlank(message = "Les objectifs sont obligatoires")
	@Lob // transform en text dans mySQL
	@Column
	private String objectifs;
	
	@Min(value = 7, message = "Le nombre maximum de participants doit être au moins 7")
	@Column(nullable = false)
	private int nb_participants_max;
	
	// J'ai crée la classe "Format" de type "enum" pour autoriser que 2 valeurs
	// DISTANCIEL OU PRESENTIEL
	@Enumerated(EnumType.STRING)
	@Column(nullable = false)
	private Format format;

	
	@OneToMany(mappedBy = "formation")
	private List<Classe> classes = new ArrayList<>();

	
	
	public Formation() {
		super();
	}


	public Formation(String nom, int duree, String objectifs, int nb_participants_max, Format format) {
		super();
		this.nom = nom;
		this.duree = duree;
		this.objectifs = objectifs;
		this.nb_participants_max = nb_participants_max;
		this.format = format;
	}


	public Long getId() {
		return id;
	}


	public String getNom() {
		return nom;
	}


	public void setNom(String nom) {
		this.nom = nom;
	}


	public int getDuree() {
		return duree;
	}


	public void setDuree(int duree) {
		this.duree = duree;
	}


	public String getObjectifs() {
		return objectifs;
	}


	public void setObjectifs(String objectifs) {
		this.objectifs = objectifs;
	}


	public int getNb_participants_max() {
		return nb_participants_max;
	}


	public void setNb_participants_max(int nb_participants_max) {
		this.nb_participants_max = nb_participants_max;
	}


	public Format getFormat() {
		return format;
	}


	public void setFormat(Format format) {
		this.format = format;
	}


	@Override
	public String toString() {
		return "Formation [id=" + id + ", nom=" + nom + ", duree=" + duree + ", objectifs=" + objectifs
				+ ", nb_participants_max=" + nb_participants_max + ", format=" + format + "]";
	}
	
	
	
}
