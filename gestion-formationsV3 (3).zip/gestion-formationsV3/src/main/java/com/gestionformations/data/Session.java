package com.gestionformations.data;

import java.io.Serializable;
import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

@Entity
public class Session implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "idSession")
	private Long id;

	@NotBlank(message = "Le nom de la session est obligatoire")
	@Column(name = "nomSession", nullable = false, length = 150)
	private String nom;
	
	@Column(length = 50)
	private String horaire;
	
	//LocalDate c'est pour stocker une date sans heure (yyyy-mm-dd)
	//Ici j'utilise notnull a la place de notblank car c'est pas String
	//mais plutot la classe LocalDate un objet Java qui représente une date
	
	@NotNull(message = "La date de début du cours est obligatoire")
	@Column(nullable = false)
	private LocalDate date_debut_cours;

	@NotNull(message = "La date de fin du cours est obligatoire")
	@Column(nullable = false)
	private LocalDate date_fin_cours;

	@NotNull(message = "La date de début du stage est obligatoire")
	@Column(nullable = false)
	private LocalDate date_debut_stage;

	@NotNull(message = "La date de fin du stage est obligatoire")
	@Column(nullable = false)
	private LocalDate date_fin_stage;

	@ManyToOne
	@JoinColumn(name = "id_classe", nullable = false)
	private Classe classe;
	
	
	public Session() {
		super();
	}

	// Pour creation de l'instance de clas Session avec LocalDate - un ex:
	/*
	Session s = new Session(
    "Session Java Débutant",
    "09:00-12:00",
    LocalDate.of(2025, 9, 15),  // date_debut_cours
    LocalDate.of(2025, 9, 20),  // date_fin_cours
    LocalDate.of(2025, 9, 22),  // date_debut_stage
    LocalDate.of(2025, 9, 26)   // date_fin_stage
);
	 */
	public Session(String nom, String horaire, LocalDate date_debut_cours, LocalDate date_fin_cours,
			LocalDate date_debut_stage, LocalDate date_fin_stage) {
		super();
		this.nom = nom;
		this.horaire = horaire;
		this.date_debut_cours = date_debut_cours;
		this.date_fin_cours = date_fin_cours;
		this.date_debut_stage = date_debut_stage;
		this.date_fin_stage = date_fin_stage;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getHoraire() {
		return horaire;
	}

	public void setHoraire(String horaire) {
		this.horaire = horaire;
	}

	public LocalDate getDate_debut_cours() {
		return date_debut_cours;
	}

	public void setDate_debut_cours(LocalDate date_debut_cours) {
		this.date_debut_cours = date_debut_cours;
	}

	public LocalDate getDate_fin_cours() {
		return date_fin_cours;
	}

	public void setDate_fin_cours(LocalDate date_fin_cours) {
		this.date_fin_cours = date_fin_cours;
	}

	public LocalDate getDate_debut_stage() {
		return date_debut_stage;
	}

	public void setDate_debut_stage(LocalDate date_debut_stage) {
		this.date_debut_stage = date_debut_stage;
	}

	public LocalDate getDate_fin_stage() {
		return date_fin_stage;
	}

	public void setDate_fin_stage(LocalDate date_fin_stage) {
		this.date_fin_stage = date_fin_stage;
	}

	public Long getId() {
		return id;
	}

	public Classe getClasse() {
		return classe;
	}

	public void setClasse(Classe classe) {
		this.classe = classe;
	}
	
	

}
