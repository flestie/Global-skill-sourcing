package com.gestionformations.data;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import java.util.Collection;
import java.util.stream.Collectors;

@Entity
@Table(name = "utilisateurs")
public class User {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(unique = true, nullable = false)
    private String email;
    
    @Column(nullable = false)
    private String password;
    
    private boolean enabled = true;
    
    // Indique si l'utilisateur doit changer son mot de passe à la première connexion
    @Column(name = "must_change_password")
    private Boolean mustChangePassword = false; 

    
    // MFA fields
    private boolean mfaEnabled = false;
    private String mfaSecret; // For Google Authenticator
    
    // For email/SMS OTP
    private String otpCode;
    private LocalDateTime otpExpiry;
    
    // Relation avec Formateur (un user est lie a un formateur)
    @OneToOne
    @JoinColumn(name = "formateur_id")
    private Formateur formateur;
    
    // Roles de l'utilisateur
    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "user_roles", joinColumns = @JoinColumn(name = "user_id"))
    @Column(name = "role")
    private List<String> roles = new ArrayList<>();
    
    // Timestamps
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    
    
    private boolean isAdmin = false;
    
    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }
    
    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
    
    // Constructeurs
    public User() {}
    
    public User(String email, String password, Formateur formateur) {
        this.email = email;
        this.password = password;
        this.formateur = formateur;
        this.roles.add("ROLE_FORMATEUR");
    }
    
    // Getters/Setters
    public Long getId() { return id; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    public boolean isEnabled() { return enabled; }
    
    public boolean isMustChangePassword() {      
        return Boolean.TRUE.equals(mustChangePassword);
    }

    public void setMustChangePassword(boolean mustChangePassword) {    
        this.mustChangePassword = mustChangePassword;
    }



    public void setEnabled(boolean enabled) { this.enabled = enabled; }
    public boolean isMfaEnabled() { return mfaEnabled; }
    public void setMfaEnabled(boolean mfaEnabled) { this.mfaEnabled = mfaEnabled; }
    public String getMfaSecret() { return mfaSecret; }
    public void setMfaSecret(String mfaSecret) { this.mfaSecret = mfaSecret; }
    public String getOtpCode() { return otpCode; }
    public void setOtpCode(String otpCode) { this.otpCode = otpCode; }
    public LocalDateTime getOtpExpiry() { return otpExpiry; }
    public void setOtpExpiry(LocalDateTime otpExpiry) { this.otpExpiry = otpExpiry; }
    public Formateur getFormateur() { return formateur; }
    public void setFormateur(Formateur formateur) { this.formateur = formateur; }
    public List<String> getRoles() { return roles; }
    public void setRoles(List<String> roles) { this.roles = roles; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public boolean isAdmin() { return isAdmin; }
    public void setAdmin(boolean admin) { isAdmin = admin; }
    
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return roles.stream()
                   .map(SimpleGrantedAuthority::new)
                   .collect(Collectors.toList());
    }
}