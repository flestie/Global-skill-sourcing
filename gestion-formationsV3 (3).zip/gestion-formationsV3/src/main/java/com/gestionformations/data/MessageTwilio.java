package com.gestionformations.data;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

/**
 * MessageTwilio — entité JPA pour stocker les messages SMS dans la base de données.
 * 
 * Représente un message SMS reçu ou envoyé via Twilio avec :
 * - Numéro expéditeur (fromNumber)
 * - Numéro destinataire (toNumber) 
 * - Contenu du message (body)
 * - Horodatage de réception (receivedAt)
 *
 * Les annotations JPA permettent le mapping automatique vers la table 'message_twilio'.
 */
@Entity
public class MessageTwilio {
    
    // Identifiant unique généré automatiquement par la base de données
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    // Numéro de téléphone expéditeur (format international: +33...)
    private String fromNumber;
    
    // Numéro de téléphone destinataire (format international: +33...)
    private String toNumber;
    
    // Contenu textuel du message SMS (max 1600 caractères)
    private String body;
    
    // Date et heure de réception du message (rempli automatiquement à la création)
    private LocalDateTime receivedAt = LocalDateTime.now();

    // ------------ CONSTRUCTEURS ------------
    
    /**
     * Constructeur pour création rapide d'un message avec les champs essentiels.
     * Le timestamp receivedAt est initialisé automatiquement à maintenant.
     */
    public MessageTwilio(String fromNumber, String toNumber, String body) {
        super();
        this.fromNumber = fromNumber;
        this.toNumber = toNumber;
        this.body = body;
    }

    /**
     * Constructeur complet avec tous les champs, utilisé par JPA et pour les requêtes.
     */
    public MessageTwilio(Long id, String fromNumber, String toNumber, String body, LocalDateTime receivedAt) {
        super();
        this.id = id;
        this.fromNumber = fromNumber;
        this.toNumber = toNumber;
        this.body = body;
        this.receivedAt = receivedAt;
    }

    /**
     * Constructeur par défaut requis par JPA.
     * Ne pas utiliser directement, préférer les constructeurs avec paramètres.
     */
    public MessageTwilio() {
        super();
    }

    /**
     * Constructeur alternatif permettant de spécifier un timestamp personnalisé.
     * Utile pour l'import de données ou les tests.
     */
    public MessageTwilio(String fromNumber, String toNumber, String body, LocalDateTime receivedAt) {
        super();
        this.fromNumber = fromNumber;
        this.toNumber = toNumber;
        this.body = body;
        this.receivedAt = receivedAt;
    }

    // ------------ GETTERS & SETTERS ------------
    
    // Getter pour fromNumber
    public String getFromNumber() {
        return fromNumber;
    }

    // Setter pour fromNumber
    public void setFromNumber(String fromNumber) {
        this.fromNumber = fromNumber;
    }

    // Getter pour toNumber
    public String getToNumber() {
        return toNumber;
    }

    // Setter pour toNumber
    public void setToNumber(String toNumber) {
        this.toNumber = toNumber;
    }

    // Getter pour body
    public String getBody() {
        return body;
    }

    // Setter pour body
    public void setBody(String body) {
        this.body = body;
    }

    // Getter pour receivedAt
    public LocalDateTime getReceivedAt() {
        return receivedAt;
    }

    // Setter pour receivedAt
    public void setReceivedAt(LocalDateTime receivedAt) {
        this.receivedAt = receivedAt;
    }

    // Getter pour id (pas de setter pour prévenir les modifications accidentelles)
    public Long getId() {
        return id;
    }
    
    // Note: Pas de setter pour l'id car généré automatiquement par la base
}