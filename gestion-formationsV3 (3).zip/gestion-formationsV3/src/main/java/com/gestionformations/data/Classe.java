package com.gestionformations.data;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;

@Entity
public class Classe implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "idClasse")
	private Long id;
	
	@NotBlank(message = "Le nom de la classe est obligatoire")
	@Column(name = "nomClasse", nullable = false, length = 150)
	private String nom;

	@Min(value = 7, message = "Le nombre maximum de participants doit être au moins 7")
	@Column(nullable = false)
	private int nb_participants;
	
	@Column(length = 200)
	private String lieu;

	@ManyToOne
	@JoinColumn(name = "id_ecole", nullable = false) // clé étrangère obligatoire
	private Ecole ecole;
	
	
	@OneToMany(mappedBy = "classe")
	private List<Session> sessions = new ArrayList<>();
	
	@ManyToOne
	@JoinColumn(name = "id_formation", nullable = false)
	private Formation formation;
	
	@ManyToOne
	@JsonIgnoreProperties("classes")
	@JoinColumn(name = "id_formateur", nullable = false)
	private Formateur formateur;
	
	
	public Classe() {
		super();
	}

	public Classe(@NotBlank(message = "Le nom de la classe est obligatoire") String nom,
			@Min(value = 7, message = "Le nombre maximum de participants doit être au moins 7") int nb_participants,
			String lieu) {
		super();
		this.nom = nom;
		this.nb_participants = nb_participants;
		this.lieu = lieu;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public int getNb_participants() {
		return nb_participants;
	}

	public void setNb_participants(int nb_participants) {
		this.nb_participants = nb_participants;
	}

	public String getLieu() {
		return lieu;
	}

	public void setLieu(String lieu) {
		this.lieu = lieu;
	}

	public Long getId() {
		return id;
	}

	
	
	public Ecole getEcole() {
		return ecole;
	}

	public void setEcole(Ecole ecole) {
		this.ecole = ecole;
	}

	public Formation getFormation() {
		return formation;
	}

	public void setFormation(Formation formation) {
		this.formation = formation;
	}

	public Formateur getFormateur() {
		return formateur;
	}

	public void setFormateur(Formateur formateur) {
		this.formateur = formateur;
	}

	@Override
	public String toString() {
		return "Classe [id=" + id + ", nom=" + nom + ", nb_participants=" + nb_participants + ", lieu=" + lieu + "]";
	}
	
	
	
}
