package com.gestionformations.data;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;

@Entity
public class Badge {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @NotBlank(message = "Le nom du badge est obligatoire")
    @Column(unique = true, nullable = false, length = 100)
    private String nom;
    
    @Column(length = 200)
    private String description;
    
    private String type; // "peage", "transport", "autre"
    
    // Constructeurs
    public Badge() {}
    
    public Badge(String nom, String description, String type) {
        this.nom = nom;
        this.description = description;
        this.type = type;
    }
    
    // Getters/Setters
    public Long getId() { return id; }
    public String getNom() { return nom; }
    public void setNom(String nom) { this.nom = nom; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
    
    @Override
    public String toString() {
        return "Badge [id=" + id + ", nom=" + nom + ", type=" + type + "]";
    }
}