package com.gestionformations.data;

import java.io.Serializable;

import jakarta.persistence.*;

@Entity
public class Preuve implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String fileName;
    private String fileUrl; // can be path on disk or cloud storage

    @ManyToOne
    @JoinColumn(name = "trajet_id", nullable = false)
    private Trajet trajet;

    public Preuve() {}

    public Preuve(String fileName, String fileUrl, Trajet trajet) {
        this.fileName = fileName;
        this.fileUrl = fileUrl;
        this.trajet = trajet;
    }

    public Long getId() { return id; }
    public String getFileName() { return fileName; }
    public void setFileName(String fileName) { this.fileName = fileName; }
    public String getFileUrl() { return fileUrl; }
    public void setFileUrl(String fileUrl) { this.fileUrl = fileUrl; }
    public Trajet getTrajet() { return trajet; }
    public void setTrajet(Trajet trajet) { this.trajet = trajet; }
}
