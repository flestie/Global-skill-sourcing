package com.gestionformations.util;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Date;

@Component
public class JwtUtil {

    // کلید امضای JWT و مدت انقضا
    private final Key key;
    private final long expirationMs;

    /**
     * سازنده: مقادیر را از application.properties می‌خواند.
     *
     * app.jwt.secret        = رشته‌ی محرمانه برای امضای JWT (حداقل 32 کاراکتر)
     * app.jwt.expiration-ms = مدت انقضا بر حسب میلی‌ثانیه (پیش‌فرض: 86400000 = 24h)
     */
    public JwtUtil(
            @Value("${app.jwt.secret}") String secret,
            @Value("${app.jwt.expiration-ms:86400000}") long expirationMs
    ) {
        // کلید امضا باید حداقل 256 بیت باشد (32 بایت) برای HS256
        byte[] keyBytes = secret.getBytes(StandardCharsets.UTF_8);
        this.key = Keys.hmacShaKeyFor(keyBytes);
        this.expirationMs = expirationMs;
    }

    /**
     * تولید توکن JWT شامل:
     *  - subject = ایمیل
     *  - claim "userId"
     *  - claim "admin"
     */
    public String generateToken(String email, Long userId, boolean isAdmin) {
        Date now = new Date();
        Date expiry = new Date(now.getTime() + expirationMs);

        return Jwts.builder()
                .setSubject(email)
                .claim("userId", userId)
                .claim("admin", isAdmin)
                .setIssuedAt(now)
                .setExpiration(expiry)
                .signWith(key, SignatureAlgorithm.HS256)
                .compact();
    }

    /**
     * خواندن ایمیل (subject) از توکن
     */
    public String getEmailFromToken(String token) {
        return Jwts.parserBuilder()
                .setSigningKey(key)
                .build()
                .parseClaimsJws(token)
                .getBody()
                .getSubject();
    }

    /**
     * اعتبارسنجی توکن (امضا + تاریخ انقضا)
     */
    public boolean validateToken(String token) {
        try {
            Jwts.parserBuilder()
                    .setSigningKey(key)
                    .build()
                    .parseClaimsJws(token);
            return true;
        } catch (Exception e) {
            // می‌توانی اینجا log هم بگذاری
            return false;
        }
    }
}





//@Component
//public class JwtUtil {
//    private final Key key = Keys.secretKeyFor(SignatureAlgorithm.HS256);
//    private final long expiration = 86400000; // 24 heures
//
//    public String generateToken(String email, Long userId, boolean isAdmin) {
//        return Jwts.builder()
//                .setSubject(email)
//                .claim("userId", userId)
//                .claim("admin", isAdmin)
//                .setIssuedAt(new Date())
//                .setExpiration(new Date(System.currentTimeMillis() + expiration))
//                .signWith(key)
//                .compact();
//    }
//
//    public String getEmailFromToken(String token) {
//        return Jwts.parserBuilder()
//                .setSigningKey(key)
//                .build()
//                .parseClaimsJws(token)
//                .getBody()
//                .getSubject();
//    }
//
//    public boolean validateToken(String token) {
//        try {
//            Jwts.parserBuilder().setSigningKey(key).build().parseClaimsJws(token);
//            return true;
//        } catch (Exception e) {
//            return false;
//        }
//    }
//}