package com.gestionformations.controller;

import com.gestionformations.data.Activite;
import com.gestionformations.service.ActiviteService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/activites")
@CrossOrigin(origins = "*")
public class ActiviteControllerApi {

    private final ActiviteService activiteService;

    public ActiviteControllerApi(ActiviteService activiteService) {
        this.activiteService = activiteService;
    }

    @GetMapping
    public List<Activite> obtenirActivitesRecentes() {
        return activiteService.obtenirActivitesRecentes();
    }
}
