package com.gestionformations.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.gestionformations.data.Badge;
import com.gestionformations.dto.BadgeDTO;
import com.gestionformations.service.BadgeService;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/badges")
public class BadgeControllerApi {
    
    private final BadgeService badgeService;
    
    public BadgeControllerApi(BadgeService badgeService) {
        this.badgeService = badgeService;
    }
    
    @GetMapping
    public List<BadgeDTO> getAllBadges() {
        return badgeService.getAllBadges().stream()
            .map(this::convertToDTO)
            .collect(Collectors.toList());
    }
    
    @GetMapping("/type/{type}")
    public List<BadgeDTO> getBadgesByType(@PathVariable String type) {
        return badgeService.getBadgesByType(type).stream()
            .map(this::convertToDTO)
            .collect(Collectors.toList());
    }
    
    @PostMapping
    public ResponseEntity<?> createBadge(@RequestBody BadgeDTO badgeDTO) {
        try {
            Badge badge = new Badge();
            badge.setNom(badgeDTO.getNom());
            badge.setDescription(badgeDTO.getDescription());
            badge.setType(badgeDTO.getType());
            
            Badge savedBadge = badgeService.createBadge(badge);
            return ResponseEntity.ok(convertToDTO(savedBadge));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<?> updateBadge(@PathVariable Long id, @RequestBody BadgeDTO badgeDTO) {
        try {
            Badge badgeDetails = new Badge();
            badgeDetails.setNom(badgeDTO.getNom());
            badgeDetails.setDescription(badgeDTO.getDescription());
            badgeDetails.setType(badgeDTO.getType());
            
            Badge updatedBadge = badgeService.updateBadge(id, badgeDetails);
            return ResponseEntity.ok(convertToDTO(updatedBadge));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBadge(@PathVariable Long id) {
        try {
            badgeService.deleteBadge(id);
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }
    
    private BadgeDTO convertToDTO(Badge badge) {
        return new BadgeDTO(
            badge.getId(),
            badge.getNom(),
            badge.getDescription(),
            badge.getType()
        );
    }
}