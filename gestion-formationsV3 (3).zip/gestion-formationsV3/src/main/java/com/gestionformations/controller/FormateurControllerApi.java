package com.gestionformations.controller;

import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gestionformations.data.Formateur;
import com.gestionformations.data.User;
import com.gestionformations.dto.ClasseDTO;
import com.gestionformations.dto.CompetenceDTO;
import com.gestionformations.dto.CreateFormateurDTO;
import com.gestionformations.dto.FormateurDTO;
import com.gestionformations.service.FormateurService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/formateurs") // Toutes les routes commenceront par /api/formateurs
public class FormateurControllerApi {

    // Injection du service Formateur
    private final FormateurService formateurService;

    // Constructeur : Spring injecte automatiquement FormateurService
    public FormateurControllerApi(FormateurService formateurService) {
        this.formateurService = formateurService;
    }

    // -------------------------
    // LIRE TOUS LES FORMATEURS
    // -------------------------
    @GetMapping
    public List<FormateurDTO> getAllFormateurs() {
        /*
         * Ici, le service appelle le repository → findAll()
         * Retourne la liste de tous les formateurs en BDD.
         */
        return formateurService.getAllFormateursDTO();
    }

    // -------------------------
    // LIRE UN FORMATEUR PAR ID
    // -------------------------
    @GetMapping("/{id}")
    public ResponseEntity<FormateurDTO> getFormateurById(@PathVariable Long id, 
            @AuthenticationPrincipal User currentUser) {
        /*
         * @PathVariable Long id → récupère l’ID passé dans l’URL.
         * Exemple : GET /api/formateurs/5 → id = 5
         */
        FormateurDTO formateur = formateurService.getFormateurByIdDTO(id, currentUser);

        /*
         * - Si trouvé : HTTP 200 + JSON du formateur
         * - Sinon : HTTP 404 (Not Found)
         */
        return formateur != null ? ResponseEntity.ok(formateur) : ResponseEntity.notFound().build();
    }

    // -------------------------
    // CRÉER UN FORMATEUR
    // -------------------------
    @PostMapping
    public ResponseEntity<?> createFormateur(@Valid @RequestBody CreateFormateurDTO formateurDTO) {
        /*
         * POST /api/formateurs
         * Crée un nouveau formateur avec validation des données.
         * 
         * @Valid → Active la validation automatique du DTO
         * ResponseEntity<?> → Permet de retourner soit un succès soit une erreur
         * 
         * Exemple JSON attendu :
         * {
         *   "nom": "Dupont",
         *   "prenom": "Jean", 
         *   "email": "jean.dupont@mail.com",
         *   "telephone": "0601020304",
         *   "ville": "Paris",
         *   "codePostal": "75000"
         * }
         * 
         * - 200 OK + DTO si création réussie
         * - 400 Bad Request si données invalides
         */
        try {
            FormateurDTO savedFormateur = formateurService.createFormateurDTO(formateurDTO);
            return ResponseEntity.ok(savedFormateur);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Erreur lors de la création: " + e.getMessage());
        }
    }

    // -------------------------
    // MODIFIER UN FORMATEUR
    // -------------------------
    @PutMapping("/{id}")
    public ResponseEntity<?> updateFormateur(
            @PathVariable Long id, 
            @Valid @RequestBody CreateFormateurDTO formateurDTO) {
        /*
         * PUT /api/formateurs/1
         * Modifie un formateur existant avec validation des données.
         * 
         * - 200 OK + DTO si modification réussie  
         * - 400 Bad Request si données invalides
         * - 404 Not Found si formateur non trouvé
         */
        try {
            FormateurDTO updatedFormateur = formateurService.updateFormateurDTO(id, formateurDTO);
            return updatedFormateur != null ? 
                ResponseEntity.ok(updatedFormateur) : 
                ResponseEntity.notFound().build();
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Erreur lors de la modification: " + e.getMessage());
        }
    }
    
    

    // -------------------------
    // SUPPRIMER UN FORMATEUR
    // -------------------------
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteFormateur(@PathVariable Long id) {
        formateurService.deleteFormateur(id);

        /*
         * On renvoie HTTP 204 (No Content) car suppression réussie,
         * mais rien à renvoyer dans le corps de la réponse.
         */
        return ResponseEntity.noContent().build();
    }
    
 // Test ajout de compétence au formateur
    @PostMapping("/competence")
    public Formateur ajoutCompetence() {
        // ajoute la compétence avec id = 1 au formateur avec id = 2
        Formateur formateur = formateurService.ajouterCompetence(2L, 1L);
        return formateur;
    }

    
 // ==================== NOUVEAUX ENDPOINTS SPÉCIFIQUES ====================

    /**
     * Récupère les classes d'un formateur
     */
    @GetMapping("/{id}/classes")
    public ResponseEntity<List<ClasseDTO>> getFormateurClasses(
    		@PathVariable Long id,
            @AuthenticationPrincipal User currentUser) {
        List<ClasseDTO> classes = formateurService.getClassesByFormateur(id, currentUser);
        return ResponseEntity.ok(classes);
    }

    /**
     * Récupère les compétences d'un formateur
     */
    @GetMapping("/{id}/competences")
    public ResponseEntity<List<CompetenceDTO>> getFormateurCompetences(
            @PathVariable Long id,
            @AuthenticationPrincipal User currentUser) {
        
        List<CompetenceDTO> competences = formateurService.getCompetencesByFormateur(id, currentUser);
        return ResponseEntity.ok(competences);
    }

    /**
     * Ajoute une compétence à un formateur
     */
    @PostMapping("/{formateurId}/competences/{competenceId}")
    public ResponseEntity<String> addCompetenceToFormateur(
            @PathVariable Long formateurId,
            @PathVariable Long competenceId) {
        Formateur formateur = formateurService.ajouterCompetence(formateurId, competenceId);
        if (formateur != null) {
            return ResponseEntity.ok("Compétence ajoutée avec succès au formateur");
        } else {
            return ResponseEntity.notFound().build();
        }
    }
    /** Supprime une competence d'un formateur
     */
    @DeleteMapping("/{formateurId}/competences/{competenceId}")
    public ResponseEntity<?> retirerCompetenceDeFormateur(
            @PathVariable Long formateurId,
            @PathVariable Long competenceId) {
        Formateur updated = formateurService.retirerCompetence(formateurId, competenceId);

        if (updated == null) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.noContent().build();
    }

    /**
     * Récupère les statistiques d'un formateur
     */
    @GetMapping("/{id}/stats")
    public ResponseEntity<Map<String, Object>> getFormateurStats(
            @PathVariable Long id,
            @AuthenticationPrincipal User currentUser) {
        
        Map<String, Object> stats = formateurService.getStatsFormateur(id, currentUser);
        return ResponseEntity.ok(stats);
    }
}
