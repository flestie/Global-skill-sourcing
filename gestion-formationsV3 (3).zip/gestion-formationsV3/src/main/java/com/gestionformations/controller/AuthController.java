package com.gestionformations.controller;

import com.gestionformations.data.User;
import com.gestionformations.dto.AuthResponseDTO;
import com.gestionformations.dto.ChangePasswordRequestDTO;
import com.gestionformations.dto.LoginRequestDTO;
import com.gestionformations.dto.MfaSetupDTO;
import com.gestionformations.dto.UserDTO;
import com.gestionformations.service.AuthService;
import com.gestionformations.service.UserService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthService authService;
    private final UserService userService;

    public AuthController(AuthService authService,
                          UserService userService) {
        this.authService = authService;
        this.userService = userService;
    }

    /**
     * POST /api/auth/login
     * User login with optional MFA and "must change password on first login" flag.
     */
    @PostMapping("/login")
    public ResponseEntity<?> login(@Valid @RequestBody LoginRequestDTO loginRequest) {
        Optional<User> userOpt = authService.authenticate(loginRequest.getEmail(), loginRequest.getPassword());

        if (userOpt.isEmpty()) {
            return ResponseEntity.badRequest().body("Identifiants incorrects");
        }

        User user = userOpt.get();

        // If MFA is enabled but no OTP code is provided → send code and ask for MFA verification
        if (user.isMfaEnabled() && (loginRequest.getOtpCode() == null || loginRequest.getOtpCode().isEmpty())) {
            authService.sendOtpEmail(user);

            AuthResponseDTO response = new AuthResponseDTO();
            response.setToken(null);
            response.setUser(null);
            response.setMfaRequired(true);
            response.setMessage("Code MFA requis. Vérifiez votre email.");
            // Even at this stage, we can already inform the frontend that the user must change password
            response.setMustChangePassword(user.isMustChangePassword());

            return ResponseEntity.ok(response);
        }

        // If MFA is enabled and a code is provided → verify the code
        if (user.isMfaEnabled() && loginRequest.getOtpCode() != null) {
            if (!authService.verifyOtp(user, loginRequest.getOtpCode())) {
                return ResponseEntity.badRequest().body("Code MFA invalide ou expiré");
            }
        }

        // Successful login → generate JWT token
        String token = userService.generateToken(user);
        UserDTO userDTO = userService.convertToDTO(user);

        AuthResponseDTO response = new AuthResponseDTO();
        response.setToken(token);
        response.setUser(userDTO);
        response.setMfaRequired(false);
        response.setMessage("Connexion réussie");
        // This flag tells the frontend that the user must change the temporary password
        response.setMustChangePassword(user.isMustChangePassword());

        return ResponseEntity.ok(response);
    }

    /**
     * POST /api/auth/change-password
     * Change le mot de passe après une première connexion avec mot de passe temporaire.
     * L'utilisateur authentifié est récupéré depuis le contexte de sécurité (JWT).
     */
    @PostMapping("/change-password")
    public ResponseEntity<?> changePasswordFirstLogin(
            @Valid @RequestBody ChangePasswordRequestDTO request,
            @AuthenticationPrincipal com.gestionformations.data.User currentUser) {

        // 🔐 Si aucun utilisateur dans le contexte de sécurité → non authentifié
        if (currentUser == null) {
            return ResponseEntity
                    .status(HttpStatus.UNAUTHORIZED)
                    .body("Utilisateur non authentifié");
        }

        String email = currentUser.getEmail();

        try {
            authService.changePasswordFirstLogin(
                    email,
                    request.getOldPassword(),
                    request.getNewPassword()
            );
            return ResponseEntity.ok("Mot de passe modifié avec succès");
        } catch (IllegalArgumentException ex) {
            // Mauvais ancien mot de passe, utilisateur introuvable, etc.
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }


    /**
     * POST /api/auth/mfa/setup
     * Start MFA setup for a given user (by email).
     */
    @PostMapping("/mfa/setup")
    public ResponseEntity<?> setupMfa(@RequestParam String email) {
        Optional<User> userOpt = userService.findByEmail(email);

        if (userOpt.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        MfaSetupDTO mfaSetup = userService.setupMfa(userOpt.get());
        return ResponseEntity.ok(mfaSetup);
    }

    /**
     * POST /api/auth/mfa/verify
     * Verify and activate MFA with a code.
     */
    @PostMapping("/mfa/verify")
    public ResponseEntity<?> verifyMfa(@RequestParam String email, @RequestParam String code) {
        boolean isValid = userService.verifyMfaCode(email, code);

        if (isValid) {
            return ResponseEntity.ok("MFA activée avec succès");
        } else {
            return ResponseEntity.badRequest().body("Code MFA invalide");
        }
    }

    /**
     * POST /api/auth/mfa/disable
     * Disable MFA for a given user (by email).
     */
    @PostMapping("/mfa/disable")
    public ResponseEntity<?> disableMfa(@RequestParam String email) {
        Optional<User> userOpt = userService.findByEmail(email);

        if (userOpt.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        userService.disableMfa(userOpt.get());
        return ResponseEntity.ok("MFA désactivée");
    }
}
