package com.gestionformations.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gestionformations.dto.CreateSessionDTO;
import com.gestionformations.dto.SessionDTO;
import com.gestionformations.service.SessionService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/sessions")  // toutes les routes commencent par /api/sessions
public class SessionControllerApi {

    // Injection du service qui gère la logique métier pour Session
    private final SessionService sessionService;

    // Spring injecte automatiquement le service dans le constructeur
    public SessionControllerApi(SessionService sessionService) {
        this.sessionService = sessionService;
    }

    // -------------------------
    // LIRE TOUTES LES SESSIONS
    // -------------------------
    @GetMapping
    public List<SessionDTO> getAllSessions() {
        /*
         * GET /api/sessions
         * Retourne toutes les sessions disponibles en DTO.
         * 
         * Exemple de réponse :
         * [
         *   {
         *     "id": 1,
         *     "nom": "Session Automne",
         *     "horaire": "Matin",
         *     "dateDebutCours": "2025-09-15",
         *     "dateFinCours": "2025-12-15",
         *     "dateDebutStage": "2026-01-10",
         *     "dateFinStage": "2026-03-20",
         *     "classeId": 2
         *   }
         * ]
         */
        return sessionService.getAllSessionsDTO();
    }

    // -------------------------
    // LIRE UNE SESSION PAR ID
    // -------------------------
    @GetMapping("/{id}")
    public ResponseEntity<SessionDTO> getSessionById(@PathVariable Long id) {
        /*
         * GET /api/sessions/5
         * Retourne une session spécifique en DTO.
         * 
         * @PathVariable → extrait l'ID depuis l'URL.
         * 
         * - 200 OK + DTO si session trouvée
         * - 404 Not Found si session non trouvée
         */
        SessionDTO session = sessionService.getSessionByIdDTO(id);
        return session != null ? ResponseEntity.ok(session) : ResponseEntity.notFound().build();
    }

    // -------------------------
    // CRÉER UNE NOUVELLE SESSION
    // -------------------------
    @PostMapping
    public ResponseEntity<?> createSession(@Valid @RequestBody CreateSessionDTO sessionDTO) {
        /*
         * POST /api/sessions
         * Crée une nouvelle session avec validation des données.
         *
         * Exemple JSON attendu :
         * {
         *   "nom": "Session Automne",
         *   "horaire": "Matin",
         *   "dateDebutCours": "2025-09-15",
         *   "dateFinCours": "2025-12-15", 
         *   "dateDebutStage": "2026-01-10",
         *   "dateFinStage": "2026-03-20",
         *   "classeId": 2
         * }
         *
         * - 200 OK + DTO si création réussie
         * - 400 Bad Request si données invalides
         */
        try {
            SessionDTO savedSession = sessionService.createSessionDTO(sessionDTO);
            return ResponseEntity.ok(savedSession);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Erreur lors de la création: " + e.getMessage());
        }
    }

    // -------------------------
    // MODIFIER UNE SESSION
    // -------------------------
    @PutMapping("/{id}")
    public ResponseEntity<?> updateSession(
            @PathVariable Long id, 
            @RequestBody CreateSessionDTO sessionDTO) {
        /*
         * PUT /api/sessions/5
         * Modifie une session existante à partir d'un DTO.
         * 
         * Exemple JSON attendu :
         * {
         *   "nom": "Session Hiver",
         *   "horaire": "Après-midi",
         *   "dateDebutCours": "2025-01-15",
         *   "dateFinCours": "2025-04-15",
         *   "dateDebutStage": "2025-05-01",
         *   "dateFinStage": "2025-07-01",
         *   "classeId": 3
         * }
         * 
         * - 200 OK + DTO si modification réussie
         * - 400 Bad Request si données invalides
         * - 404 Not Found si session non trouvée
         */
        try {
            SessionDTO updatedSession = sessionService.updateSessionDTO(id, sessionDTO);
            return updatedSession != null ? 
                ResponseEntity.ok(updatedSession) : 
                ResponseEntity.notFound().build();
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Erreur lors de la modification: " + e.getMessage());
        }
    }

    // -------------------------
    // SUPPRIMER UNE SESSION
    // -------------------------
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteSession(@PathVariable Long id) {
        /*
         * DELETE /api/sessions/5
         * Supprime une session par son ID.
         * 
         * HTTP 204 → Suppression réussie (aucun contenu renvoyé).
         */
        sessionService.deleteSession(id);
        return ResponseEntity.noContent().build();
    }
}