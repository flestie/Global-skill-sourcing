package com.gestionformations.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gestionformations.data.User;
import com.gestionformations.dto.CreateTrajetDTO;
import com.gestionformations.dto.TrajetDTO;
import com.gestionformations.service.TrajetService;

/**
 * Contrôleur REST pour la gestion des trajets
 * Toutes les routes commencent par /api/trajets
 */
@RestController
@RequestMapping("/api/trajets")
public class TrajetControllerApi {

    private final TrajetService trajetService;

    public TrajetControllerApi(TrajetService trajetService) {
        this.trajetService = trajetService;
    }

    // ====================
    // GET - RÉCUPÉRATION
    // ====================

    /**
     * GET /api/trajets
     * Récupère tous les trajets sous forme de DTOs
     */
    @GetMapping
    public List<TrajetDTO> getAllTrajets() {
        return trajetService.getAllTrajets();
    }

    /**
     * GET /api/trajets/formateur/{id}
     * Récupère tous les trajets d'un formateur spécifique
     */
    @GetMapping("/formateur/{id}")
    public ResponseEntity<List<TrajetDTO>> getTrajetsByFormateur(
            @PathVariable Long id,
            @AuthenticationPrincipal User currentUser) {
        
        List<TrajetDTO> trajets = trajetService.getTrajetsByFormateurDTO(id, currentUser);
        return ResponseEntity.ok(trajets);
    }

    /**
     * GET /api/trajets/{id}
     * Récupère un trajet spécifique par son ID
     */
    @GetMapping("/{id}")
    public ResponseEntity<TrajetDTO> getTrajetById(@PathVariable Long id) {
        TrajetDTO trajet = trajetService.getTrajetByIdDTO(id);
        return trajet != null ? ResponseEntity.ok(trajet) : ResponseEntity.notFound().build();
    }

    /**
     * GET /api/trajets/formateur/{id}/distance
     * Calcule la distance totale parcourue par un formateur
     */
    @GetMapping("/formateur/{id}/distance")
    public ResponseEntity<Double> getDistanceTotale(
            @PathVariable Long id,
            @AuthenticationPrincipal User currentUser) {
        
        double distance = trajetService.getDistanceTotaleByFormateur(id, currentUser);
        return ResponseEntity.ok(distance);
    }

    // ====================
    // POST - CRÉATION
    // ====================

    /**
     * POST /api/trajets/formateur/{formateurId}
     * Crée un nouveau trajet pour un formateur
     * Body JSON attendu: { "distance": 25.5, "correspondances": "Bus 12", ... }
     */
    @PostMapping("/formateur/{formateurId}")
    public ResponseEntity<TrajetDTO> createTrajet(
            @PathVariable Long formateurId,
            @RequestBody CreateTrajetDTO trajetDTO,
            @AuthenticationPrincipal User currentUser) {
        
        TrajetDTO savedTrajet = trajetService.createTrajet(formateurId, trajetDTO, currentUser);
        
        if (savedTrajet == null) {
            return ResponseEntity.notFound().build(); // Formateur non trouvé
        }
        
        return ResponseEntity.ok(savedTrajet);
    }

    // ====================
    // PUT - MODIFICATION
    // ====================

    /**
     * PUT /api/trajets/{id}
     * Met à jour un trajet existant
     */
    @PutMapping("/{id}")
    public ResponseEntity<TrajetDTO> updateTrajet(
            @PathVariable Long id,
            @RequestBody CreateTrajetDTO trajetDetails) {
        
        TrajetDTO updatedTrajet = trajetService.updateTrajetDTO(id, trajetDetails);
        
        if (updatedTrajet == null) {
            return ResponseEntity.notFound().build(); // Trajet non trouvé
        }
        
        return ResponseEntity.ok(updatedTrajet);
    }

    // ====================
    // DELETE - SUPPRESSION
    // ====================

    /**
     * DELETE /api/trajets/{id}
     * Supprime un trajet par son ID
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteTrajet(@PathVariable Long id) {
        boolean deleted = trajetService.deleteTrajet(id);
        
        if (deleted) {
            return ResponseEntity.noContent().build(); // Suppression réussie (204)
        } else {
            return ResponseEntity.notFound().build(); // Trajet non trouvé (404)
        }
    }
}