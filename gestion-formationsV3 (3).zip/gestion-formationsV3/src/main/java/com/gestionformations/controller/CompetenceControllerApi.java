package com.gestionformations.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gestionformations.dto.CompetenceDTO;
import com.gestionformations.service.CompetenceService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/competences")
public class CompetenceControllerApi {
    
    // Injection du service Competence
    private final CompetenceService competenceService;

    // Constructeur avec injection de dépendance
    public CompetenceControllerApi(CompetenceService competenceService) {
        this.competenceService = competenceService;
    }

    // -------------------------
    // LIRE TOUTES LES COMPÉTENCES
    // -------------------------
    @GetMapping
    public List<CompetenceDTO> getAllCompetences() {
        /*
         * GET /api/competences
         * Retourne la liste de toutes les compétences en DTO.
         * 
         * Exemple de réponse :
         * [
         *   {
         *     "id": 1,
         *     "nom": "Java"
         *   },
         *   {
         *     "id": 2,
         *     "nom": "Spring Boot"
         *   },
         *   {
         *     "id": 3, 
         *     "nom": "Hibernate"
         *   }
         * ]
         */
        return competenceService.getAllCompetencesDTO();
    }

    // -------------------------
    // LIRE UNE COMPÉTENCE PAR ID
    // -------------------------
    @GetMapping("/{id}")
    public ResponseEntity<CompetenceDTO> getCompetenceById(@PathVariable Long id) {
        /*
         * GET /api/competences/1
         * Retourne une compétence spécifique en DTO.
         * 
         * @PathVariable Long id → récupère l'ID depuis l'URL
         * 
         * - 200 OK + DTO si compétence trouvée
         * - 404 Not Found si compétence non trouvée
         */
        CompetenceDTO competence = competenceService.getCompetenceByIdDTO(id);
        return competence != null ? ResponseEntity.ok(competence) : ResponseEntity.notFound().build();
    }

    // -------------------------
    // CRÉER UNE NOUVELLE COMPÉTENCE
    // -------------------------
    @PostMapping
    public ResponseEntity<?> createCompetence(@Valid @RequestBody CompetenceDTO competenceDTO) {
        /*
         * POST /api/competences
         * Crée une nouvelle compétence avec validation des données.
         * 
         * Exemple JSON attendu :
         * {
         *   "nom": "Docker"
         * }
         * 
         * - 200 OK + DTO si création réussie
         * - 400 Bad Request si données invalides
         */
        try {
            CompetenceDTO savedCompetence = competenceService.createCompetenceDTO(competenceDTO);
            return ResponseEntity.ok(savedCompetence);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Erreur lors de la création: " + e.getMessage());
        }
    }

    // -------------------------
    // MODIFIER UNE COMPÉTENCE
    // -------------------------
    @PutMapping("/{id}")
    public ResponseEntity<?> updateCompetence(
            @PathVariable Long id, 
            @RequestBody CompetenceDTO competenceDTO) {
        /*
         * PUT /api/competences/1
         * Modifie une compétence existante à partir d'un DTO.
         * 
         * Exemple JSON attendu :
         * {
         *   "nom": "Docker & Kubernetes"
         * }
         * 
         * - 200 OK + DTO si modification réussie
         * - 404 Not Found si compétence non trouvée
         */
        try {
            CompetenceDTO updatedCompetence = competenceService.updateCompetenceDTO(id, competenceDTO);
            return updatedCompetence != null ? 
                ResponseEntity.ok(updatedCompetence) : 
                ResponseEntity.notFound().build();
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Erreur lors de la modification: " + e.getMessage());
        }
    }

    // -------------------------
    // SUPPRIMER UNE COMPÉTENCE
    // -------------------------
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCompetence(@PathVariable Long id) {
        /*
         * DELETE /api/competences/1
         * Supprime une compétence par son ID.
         * 
         * HTTP 204 → Suppression réussie, pas de contenu à renvoyer.
         */
        competenceService.deleteCompetence(id);
        return ResponseEntity.noContent().build();
    }
}