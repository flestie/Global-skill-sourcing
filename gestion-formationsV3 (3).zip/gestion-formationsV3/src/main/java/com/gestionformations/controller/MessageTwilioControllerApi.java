package com.gestionformations.controller;

import java.util.Map;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gestionformations.service.MessageTwilioService;

/**
 * MessageTwilioControllerApi — contrôleur REST pour gérer les webhooks Twilio.
 * 
 * Points d'entrée :
 * - /sms/api/receive : Webhook principal pour messages entrants (form-data)
 * - /sms/api/receive1 : Alternative JSON pour messages entrants
 * - /sms/api/all : Endpoint de test pour retraiter l'historique
 * 
 * Ce contrôleur est appelé par Twilio quand un SMS est reçu sur votre numéro.
 */
@RestController  // ✅ Indique à Spring que c'est un contrôleur REST
@RequestMapping("/sms/api") // Préfixe commun pour tous les endpoints SMS
public class MessageTwilioControllerApi {
    
    // Service métier injecté pour le traitement des messages
    private final MessageTwilioService smsService;

    /**
     * Constructeur avec injection de dépendance.
     * Spring injecte automatiquement le MessageTwilioService.
     */
    public MessageTwilioControllerApi(MessageTwilioService smsService) {
        this.smsService = smsService;
    }

    /**
     * Endpoint principal pour recevoir les SMS entrants via webhook Twilio.
     * 
     * Twilio envoie les données en format application/x-www-form-urlencoded.
     * Utilise @RequestParam pour binder automatiquement les paramètres du formulaire.
     * 
     * @param params Map contenant tous les paramètres de la requête Twilio
     * @return Réponse XML TwiML que Twilio utilisera pour répondre au SMS
     */
    @PostMapping("/receive")
    public String receiveSms(@RequestParam Map<String, String> params) {
        // Extraction des paramètres essentiels de la requête Twilio
        String from = params.get("From"); // Numéro expéditeur (client)
        String to = params.get("To");     // Numéro destinataire (votre Twilio)
        String body = params.get("Body"); // Contenu du message SMS
        
        // Log pour le débogage
        System.out.println("Webhook appelé - From: " + from + ", To: " + to + ", Body: " + body);
        
        // Traitement du message par le service métier
        String responseText = smsService.traitementMessageEntrant(from, to, body);

        // Retourne une réponse TwiML que Twilio interprétera comme instruction
        return "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
             + "<Response>"
             + "<Message>" + responseText + "</Message>"
             + "</Response>";
    }
    
    /**
     * Endpoint alternatif pour recevoir les SMS en format JSON.
     * 
     * Utile pour les tests ou intégrations personnalisées.
     * Consomme du JSON au lieu des form-data classiques.
     *
     * @param payload Map contenant les données JSON de la requête
     * @return Réponse XML TwiML standard
     */
    @PostMapping(value = "/receive1", consumes = "application/json")
    public String receiveSmsJson(@RequestBody Map<String, String> payload) {
        // Extraction depuis le payload JSON
        String from = payload.get("From");
        String to = payload.get("To"); 
        String body = payload.get("Body");

        // Traitement identique au endpoint principal
        smsService.traitementMessageEntrant(from, to, body);

        // Réponse standard
        return "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
             + "<Response><Message>Message JSON reçu et traité !</Message></Response>";
    }

    /**
     * Endpoint de test et d'administration pour retraiter tous les messages existants.
     * 
     * Appelable via GET pour déclencher le retraitement de l'historique.
     * Utile pour le débogage ou après une mise à jour de la logique métier.
     *
     * @return Message de confirmation
     */
    @GetMapping("/all")
    public String processAllMessages() {
        // Déclenche le retraitement de tous les messages en base
        smsService.processAllExistingMessages();
        return "✅ Tous les messages existants ont été retraités (voir les logs console).";
    }
}