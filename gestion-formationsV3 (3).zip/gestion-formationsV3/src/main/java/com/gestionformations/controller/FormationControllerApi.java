package com.gestionformations.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gestionformations.dto.FormationDTO;
import com.gestionformations.service.FormationService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/formations") // Toutes les routes commencent par /api/formations
public class FormationControllerApi {

    // Injection du service Formation
    private final FormationService formationService;

    // Constructeur : Spring injecte automatiquement FormationService
    public FormationControllerApi(FormationService formationService) {
        this.formationService = formationService;
    }

    // -------------------------
    // LIRE TOUTES LES FORMATIONS
    // -------------------------
    @GetMapping
    public List<FormationDTO> getAllFormations() {
        /*
         * GET /api/formations
         * Retourne la liste de toutes les formations en DTO (JSON léger).
         * 
         * Exemple de réponse :
         * [
         *   {
         *     "id": 1,
         *     "nom": "Spring Boot",
         *     "duree": 35,
         *     "objectifs": "Apprendre à développer une API",
         *     "nbParticipantsMax": 15,
         *     "format": "PRESENTIEL"
         *   }
         * ]
         */
        return formationService.getAllFormationsDTO();
    }

    // -------------------------
    // LIRE UNE FORMATION PAR ID
    // -------------------------
    @GetMapping("/{id}")
    public ResponseEntity<FormationDTO> getFormationById(@PathVariable Long id) {
        /*
         * GET /api/formations/3
         * Retourne une formation spécifique en DTO.
         * 
         * @PathVariable Long id → récupère l'ID de l'URL
         * 
         * - Si la formation existe : HTTP 200 + DTO
         * - Sinon : HTTP 404 (Not Found)
         */
        FormationDTO formation = formationService.getFormationByIdDTO(id);
        return formation != null ? ResponseEntity.ok(formation) : ResponseEntity.notFound().build();
    }

    // -------------------------
    // CRÉER UNE FORMATION
    // -------------------------
    @PostMapping
    public ResponseEntity<?> createFormation(@Valid @RequestBody FormationDTO formationDTO) {
        /*
         * POST /api/formations
         * Crée une nouvelle formation avec validation des données.
         * 
         * @Valid → Active la validation automatique
         * 
         * Exemple JSON attendu :
         * {
         *   "nom": "Spring Boot",
         *   "duree": 35,
         *   "objectifs": "Apprendre à développer une API",
         *   "nbParticipantsMax": 15,
         *   "format": "PRESENTIEL"
         * }
         *
         * format → ENUM (PRESENTIEL ou DISTANCIEL uniquement)
         * 
         * - 200 OK + DTO si création réussie
         * - 400 Bad Request si données invalides
         */
        try {
            FormationDTO savedFormation = formationService.createFormationDTO(formationDTO);
            return ResponseEntity.ok(savedFormation);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Erreur lors de la création: " + e.getMessage());
        }
    }

    // -------------------------
    // MODIFIER UNE FORMATION
    // -------------------------
    @PutMapping("/{id}")
    public ResponseEntity<?> updateFormation(
            @PathVariable Long id, 
            @RequestBody FormationDTO formationDTO) {
        /*
         * PUT /api/formations/3
         * Modifie une formation existante à partir d'un DTO.
         * 
         * Exemple JSON attendu :
         * {
         *   "nom": "Spring Boot Avancé",
         *   "duree": 40,
         *   "objectifs": "Développer des applications complexes",
         *   "nbParticipantsMax": 12,
         *   "format": "DISTANCIEL"
         * }
         * 
         * - Si la formation existe : HTTP 200 + DTO mis à jour
         * - Sinon : HTTP 404 (Not Found)
         */
        try {
            FormationDTO updatedFormation = formationService.updateFormationDTO(id, formationDTO);
            return updatedFormation != null ? 
                ResponseEntity.ok(updatedFormation) : 
                ResponseEntity.notFound().build();
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Erreur lors de la modification: " + e.getMessage());
        }
    }
    
    // -------------------------
    // SUPPRIMER UNE FORMATION
    // -------------------------
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteFormation(@PathVariable Long id) {
        /*
         * DELETE /api/formations/3
         * Supprime une formation par son ID.
         * 
         * HTTP 204 (No Content) → suppression réussie
         * Aucun contenu renvoyé dans le corps de la réponse.
         */
        formationService.deleteFormation(id);
        return ResponseEntity.noContent().build();
    }
}