package com.gestionformations.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gestionformations.dto.EcoleDTO;
import com.gestionformations.service.EcoleService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/ecoles")  // toutes les routes commencent par /api/ecoles
public class EcoleControllerApi {

    // On injecte le service (logique métier pour Ecole)
    private final EcoleService ecoleService;

    // Constructeur → Spring va automatiquement fournir une instance d'EcoleService
    public EcoleControllerApi(EcoleService ecoleService) {
        this.ecoleService = ecoleService;
    }

    // -------------------------
    // LIRE TOUTES LES ECOLES
    // -------------------------
    @GetMapping
    public List<EcoleDTO> getAllEcoles() {
        /*
         * GET /api/ecoles
         * Retourne la liste de toutes les écoles sous format DTO (JSON léger).
         * 
         * Exemple de réponse :
         * [
         *   {
         *     "id": 1,
         *     "nom": "École Centrale"
         *   },
         *   {
         *     "id": 2, 
         *     "nom": "École Supérieure d'Informatique"
         *   }
         * ]
         */
        return ecoleService.getAllEcolesDTO();
    }

    // -------------------------
    // LIRE UNE ECOLE PAR ID
    // -------------------------
    @GetMapping("/{id}")
    public ResponseEntity<EcoleDTO> getEcoleById(@PathVariable Long id) {
        /*
         * GET /api/ecoles/3
         * Retourne une école spécifique en DTO.
         * 
         * @PathVariable Long id → prend la valeur {id} de l'URL
         * 
         * - 200 OK + DTO si l'école existe
         * - 404 Not Found si aucune école trouvée
         */
        EcoleDTO ecole = ecoleService.getEcoleByIdDTO(id);
        return ecole != null ? ResponseEntity.ok(ecole) : ResponseEntity.notFound().build();
    }

    // -------------------------
    // CRÉER UNE NOUVELLE ECOLE
    // -------------------------
    @PostMapping
    public ResponseEntity<?> createEcole(@Valid @RequestBody EcoleDTO ecoleDTO) {
        /*
         * POST /api/ecoles
         * Crée une nouvelle école avec validation des données.
         * 
         * Exemple de JSON attendu :
         * {
         *   "nom": "Université de Lyon"
         * }
         *
         * - 200 OK + DTO si création réussie
         * - 400 Bad Request si données invalides
         */
        try {
            EcoleDTO savedEcole = ecoleService.createEcoleDTO(ecoleDTO);
            return ResponseEntity.ok(savedEcole);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Erreur lors de la création: " + e.getMessage());
        }
    }

    // -------------------------
    // MODIFIER UNE ECOLE EXISTANTE
    // -------------------------
    @PutMapping("/{id}")
    public ResponseEntity<?> updateEcole(@PathVariable Long id, @Valid @RequestBody EcoleDTO ecoleDTO) {
        /*
         * PUT /api/ecoles/5
         * Modifie une école existante à partir d'un DTO.
         * 
         * @RequestBody EcoleDTO ecoleDTO → JSON avec les nouvelles valeurs
         * 
         * Exemple JSON attendu :
         * {
         *   "nom": "Université de Lyon Modifiée"
         * }
         * 
         * - 200 OK + DTO si modification réussie
         * - 400 Bad Request si données invalides
         * - 404 Not Found si école non trouvée
         */
        try {
            EcoleDTO updatedEcole = ecoleService.updateEcoleDTO(id, ecoleDTO);
            return updatedEcole != null ? 
                ResponseEntity.ok(updatedEcole) : 
                ResponseEntity.notFound().build();
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Erreur lors de la modification: " + e.getMessage());
        }
    }

    // -------------------------
    // SUPPRIMER UNE ECOLE
    // -------------------------
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteEcole(@PathVariable Long id) {
        /*
         * DELETE /api/ecoles/10
         * Supprime l'école avec cet id.
         * 
         * HTTP 204 (No Content) → suppression réussie,
         * pas besoin de corps dans la réponse.
         */
        ecoleService.deleteEcole(id);
        return ResponseEntity.noContent().build();
    }
}