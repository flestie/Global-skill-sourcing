package com.gestionformations.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gestionformations.data.User;
import com.gestionformations.dto.ClasseDTO;
import com.gestionformations.dto.ClasseDetailDTO;
import com.gestionformations.dto.CreateClasseDTO;
import com.gestionformations.service.ClasseService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/classes")  // toutes les routes commencent par /api/classes
public class ClasseControllerApi {

    // On injecte le service qui contient la logique métier pour Classe
    private final ClasseService classeService;

    // Constructeur → Spring va automatiquement injecter ClasseService
    public ClasseControllerApi(ClasseService classeService) {
        this.classeService = classeService;
    }

    // -------------------------
    // LIRE TOUTES LES CLASSES
    // -------------------------
    @GetMapping
    public List<ClasseDTO> getAllClasses(@AuthenticationPrincipal User currentUser) {
        /*
         * GET /api/classes
         * Retourne la liste de toutes les classes en DTO (JSON léger).
         * 
         * Exemple de réponse :
         * [
         *   {
         *     "id": 1,
         *     "nom": "Classe Java A",
         *     "nbParticipants": 15,
         *     "lieu": "Salle 101",
         *     "ecoleId": 1,
         *     "formationId": 1,
         *     "formateurId": 1
         *   }
         * ]
         */
    	return classeService.getAllClassesDTO(currentUser);
    }

    // -------------------------
    // LIRE UNE CLASSE PAR ID
    // -------------------------
    @GetMapping("/{id}")
    public ResponseEntity<ClasseDTO> getClasseById(
            @PathVariable Long id, 
            @AuthenticationPrincipal User currentUser) {
        /*
         * GET /api/classes/4
         * Retourne une classe spécifique en DTO.
         * 
         * @PathVariable → récupère {id} depuis l'URL.
         * 
         * - Si la classe existe → HTTP 200 OK + DTO
         * - Sinon → HTTP 404 Not Found
         */
        ClasseDTO classe = classeService.getClasseByIdDTO(id, currentUser);
        return classe != null ? ResponseEntity.ok(classe) : ResponseEntity.notFound().build();
    }

    // -------------------------
    // CRÉER UNE NOUVELLE CLASSE
    // -------------------------
    @PostMapping
    public ResponseEntity<?> createClasse(@Valid @RequestBody CreateClasseDTO classeDTO) {
        /*
         * POST /api/classes
         * Crée une nouvelle classe à partir d'un DTO.
         * 
         * @RequestBody → transforme le JSON reçu en CreateClasseDTO.
         *
         * Exemple JSON attendu :
         * {
         *   "nom": "Classe Python",
         *   "nbParticipants": 30,
         *   "lieu": "Salle 505",
         *   "ecoleId": 1,
         *   "formationId": 2,
         *   "formateurId": 1
         * }
         * 
         * Les relations sont passées par leurs IDs seulement.
         * C'est plus simple et évite les problèmes de sérialisation.
         */
        try {
            ClasseDTO savedClasse = classeService.createClasseDTO(classeDTO);
            return ResponseEntity.ok(savedClasse);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Erreur lors de la création: " + e.getMessage());
        }
    }

    // -------------------------
    // MODIFIER UNE CLASSE
    // -------------------------
    @PutMapping("/{id}")
    public ResponseEntity<?> updateClasse(
            @PathVariable Long id, 
            @RequestBody CreateClasseDTO classeDTO) {
        /*
         * PUT /api/classes/4
         * Modifie une classe existante à partir d'un DTO.
         * 
         * Exemple JSON attendu :
         * {
         *   "nom": "Classe Spring Boot C",
         *   "nbParticipants": 18,
         *   "lieu": "Salle 404",
         *   "ecoleId": 1,
         *   "formationId": 2,
         *   "formateurId": 1
         * }
         * 
         * - 200 OK + DTO si modification réussie
         * - 404 Not Found si classe non trouvée
         */
        try {
            ClasseDTO updatedClasse = classeService.updateClasseDTO(id, classeDTO);
            return updatedClasse != null ? 
                ResponseEntity.ok(updatedClasse) : 
                ResponseEntity.notFound().build();
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Erreur lors de la modification: " + e.getMessage());
        }
    }

    // -------------------------
    // SUPPRIMER UNE CLASSE
    // -------------------------
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteClasse(@PathVariable Long id) {
        /*
         * DELETE /api/classes/4
         * Supprime une classe par son ID.
         * 
         * HTTP 204 → suppression réussie, pas de contenu à renvoyer.
         */
        classeService.deleteClasse(id);
        return ResponseEntity.noContent().build();
    }
    
 // ==================== ENDPOINTS AVEC DÉTAILS ====================

    /**
     * Récupère toutes les classes avec détails des relations
     */
    @GetMapping("/with-details")
    public List<ClasseDetailDTO> getAllClassesWithDetails() {
        /*
         * GET /api/classes/with-details
         * Retourne la liste de toutes les classes avec informations des relations.
         * 
         * Exemple de réponse :
         * [
         *   {
         *     "id": 1,
         *     "nom": "Classe Java A",
         *     "nbParticipants": 15,
         *     "lieu": "Salle 101",
         *     "ecole": {
         *       "id": 1,
         *       "nom": "École Centrale"
         *     },
         *     "formation": {
         *       "id": 1,
         *       "nom": "Java Débutant",
         *       "duree": 40,
         *       "format": "PRESENTIEL"
         *     },
         *     "formateur": {
         *       "id": 1,
         *       "nom": "Dupont",
         *       "prenom": "Jean",
         *       "email": "jean.dupont@mail.com"
         *     }
         *   }
         * ]
         */
        return classeService.getAllClassesWithDetails();
    }

    /**
     * Récupère une classe spécifique avec détails des relations
     */
    @GetMapping("/{id}/with-details")
    public ResponseEntity<ClasseDetailDTO> getClasseWithDetails(@PathVariable Long id) {
        /*
         * GET /api/classes/1/with-details
         * Retourne une classe spécifique avec informations détaillées des relations.
         */
        ClasseDetailDTO classe = classeService.getClasseWithDetails(id);
        return classe != null ? ResponseEntity.ok(classe) : ResponseEntity.notFound().build();
    }
}