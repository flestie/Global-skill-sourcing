package com.gestionformations.controller;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Optional;

import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.gestionformations.data.Preuve;
import com.gestionformations.repository.PreuveRepository;
import com.gestionformations.service.PreuveService;

@RestController
@RequestMapping("/api/preuves")
public class PreuveControllerApi {

    private final PreuveService preuveService;
    private final PreuveRepository preuveRepository;

    public PreuveControllerApi(PreuveService preuveService, PreuveRepository preuveRepository) {
        this.preuveService = preuveService;
        this.preuveRepository = preuveRepository;
    }

    @PostMapping("/trajet/{trajetId}")
    public ResponseEntity<?> uploadPreuve(
            @PathVariable Long trajetId,
            @RequestParam("file") MultipartFile file) {
        
        try {
            if (file.isEmpty()) {
                return ResponseEntity.badRequest().body("Fichier vide");
            }

            var preuve = preuveService.savePreuve(trajetId, file);
            return ResponseEntity.ok("Preuve uploadée avec succès: " + preuve.getFileName());
            
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Erreur upload: " + e.getMessage());
        }
    }

    @DeleteMapping("/{preuveId}")
    public ResponseEntity<Void> deletePreuve(@PathVariable Long preuveId) {
        try {
            preuveService.deletePreuve(preuveId);
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }
    
    @GetMapping("/download/{preuveId}")
    public ResponseEntity<Resource> downloadPreuve(@PathVariable Long preuveId) {
        try {
            Optional<Preuve> preuveOpt = preuveRepository.findById(preuveId);
            
            if (preuveOpt.isEmpty()) {
                return ResponseEntity.notFound().build();
            }
            
            Preuve preuve = preuveOpt.get();
            Path filePath = Paths.get(preuve.getFileUrl());
            Resource resource = new UrlResource(filePath.toUri());
            
            if (!resource.exists() || !resource.isReadable()) {
                return ResponseEntity.notFound().build();
            }
            
            // Détection du type MIME
            String contentType = "application/octet-stream";
            if (preuve.getFileName().toLowerCase().endsWith(".pdf")) {
                contentType = "application/pdf";
            } else if (preuve.getFileName().toLowerCase().endsWith(".jpg") || 
                       preuve.getFileName().toLowerCase().endsWith(".jpeg")) {
                contentType = "image/jpeg";
            } else if (preuve.getFileName().toLowerCase().endsWith(".png")) {
                contentType = "image/png";
            }
            
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=\"" + preuve.getFileName() + "\"")
                    .contentType(MediaType.parseMediaType(contentType))
                    .body(resource);
                    
        } catch (Exception e) {
            return ResponseEntity.internalServerError().build();
        }
    }
}