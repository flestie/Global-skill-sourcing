package com.gestionformations.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.gestionformations.data.Classe;


@Repository
public interface ClasseRepository extends JpaRepository<Classe, Long>{

}
