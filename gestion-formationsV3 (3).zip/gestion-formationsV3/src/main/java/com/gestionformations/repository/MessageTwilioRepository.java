package com.gestionformations.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.gestionformations.data.MessageTwilio;

/**
 * MessageTwilioRepository — interface de repository Spring Data JPA pour l'entité MessageTwilio.
 * 
 * Étend JpaRepository pour bénéficier automatiquement des opérations CRUD standards :
 * - save(), findById(), findAll(), delete(), etc.
 * 
 * Spring Data implémente automatiquement cette interface au démarrage.
 * Aucune implémentation manuelle requise.
 */
@Repository
public interface MessageTwilioRepository extends JpaRepository<MessageTwilio, Long> {
    // Méthodes de requête personnalisées peuvent être ajoutées ici si nécessaire
    // Exemple: List<MessageTwilio> findByFromNumber(String fromNumber);
}