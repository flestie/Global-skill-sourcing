package com.gestionformations.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.gestionformations.data.Competence;

@Repository
public interface CompetenceRepository extends JpaRepository<Competence, Long> {

}
