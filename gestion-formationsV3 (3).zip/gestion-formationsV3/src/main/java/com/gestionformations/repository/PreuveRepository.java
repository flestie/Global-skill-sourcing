package com.gestionformations.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.gestionformations.data.Preuve;

@Repository
public interface PreuveRepository extends JpaRepository<Preuve, Long> {

}
