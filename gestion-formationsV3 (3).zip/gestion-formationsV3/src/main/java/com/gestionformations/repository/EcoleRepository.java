package com.gestionformations.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.gestionformations.data.Ecole;


@Repository
public interface EcoleRepository extends JpaRepository<Ecole, Long> {

}