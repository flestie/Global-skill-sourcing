package com.gestionformations.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.gestionformations.data.Trajet;

@Repository
public interface TrajetRepository extends JpaRepository<Trajet, Long> {
    
    /**
     * Trouve tous les trajets d'un formateur par son ID
     * @param formateurId ID du formateur
     * @return Liste des trajets du formateur
     */
    List<Trajet> findByFormateurId(Long formateurId);
    
    /**
     * Trouve les trajets par ville de départ
     * @param villeDepart Nom de la ville de départ
     * @return Liste des trajets partant de cette ville
     */
    List<Trajet> findByVilleDepart(String villeDepart);
    
    /**
     * Trouve les trajets par ville d'arrivée
     * @param villeArrivee Nom de la ville d'arrivée
     * @return Liste des trajets arrivant dans cette ville
     */
    List<Trajet> findByVilleArrivee(String villeArrivee);
    
    /**
     * Requête personnalisée pour trouver les trajets avec une distance supérieure à une valeur
     * @param distanceMin Distance minimale en kilomètres
     * @return Liste des trajets plus longs que la distance spécifiée
     */
    @Query("SELECT t FROM Trajet t WHERE t.distance > :distanceMin")
    List<Trajet> findTrajetsLongs(@Param("distanceMin") double distanceMin);
    
    /**
     * Compte le nombre de trajets par formateur
     * @param formateurId ID du formateur
     * @return Nombre de trajets pour ce formateur
     */
    long countByFormateurId(Long formateurId);
}