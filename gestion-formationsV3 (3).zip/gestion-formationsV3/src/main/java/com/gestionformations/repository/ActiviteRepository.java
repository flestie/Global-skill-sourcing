package com.gestionformations.repository;

import com.gestionformations.data.Activite;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ActiviteRepository extends JpaRepository<Activite, Long> {
    List<Activite> findTop10ByOrderByDateCreationDesc();
}
