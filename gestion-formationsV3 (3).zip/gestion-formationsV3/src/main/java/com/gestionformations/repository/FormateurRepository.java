package com.gestionformations.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.gestionformations.data.Formateur;

@Repository
public interface FormateurRepository extends JpaRepository<Formateur, Long>{

}
