package com.gestionformations.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.gestionformations.data.Formation;

@Repository
public interface FormationRepository extends JpaRepository<Formation, Long> {

}