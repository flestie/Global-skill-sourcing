package com.gestionformations.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.gestionformations.data.User;
import com.gestionformations.repository.UserRepository;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.Random;

import org.springframework.security.crypto.password.PasswordEncoder;

@Service
@Transactional
public class AuthService {

    private final UserRepository userRepository;
    private final EmailService emailService;
    private final PasswordEncoder passwordEncoder;

    public AuthService(UserRepository userRepository,
                       EmailService emailService,
                       PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.emailService = emailService;
        this.passwordEncoder = passwordEncoder;
    }

    /**
     * Check login credentials (email + password).
     */
    public Optional<User> authenticate(String email, String password) {
        Optional<User> userOpt = userRepository.findByEmail(email);

        if (userOpt.isPresent()) {
            User user = userOpt.get();
            // Verify password with BCrypt and make sure the account is enabled
            if (passwordEncoder.matches(password, user.getPassword()) && user.isEnabled()) {
                return Optional.of(user);
            }
        }

        return Optional.empty();
    }

    /**
     * Generate and send an OTP code by email.
     */
    public boolean sendOtpEmail(User user) {
        String otp = generateOtp();
        user.setOtpCode(otp);
        user.setOtpExpiry(LocalDateTime.now().plusMinutes(10)); // Expires in 10 minutes

        userRepository.save(user);

        // Send email (simulated by EmailService)
        String subject = "Code de vérification MFA";
        String message = "Votre code de vérification est: " + otp + "\nIl expire dans 10 minutes.";

        return emailService.sendEmail(user.getEmail(), subject, message);
    }

    /**
     * Verify an OTP code.
     */
    public boolean verifyOtp(User user, String otpCode) {
        if (user.getOtpCode() == null || user.getOtpExpiry() == null) {
            return false;
        }

        if (LocalDateTime.now().isAfter(user.getOtpExpiry())) {
            return false; // Code expired
        }

        return user.getOtpCode().equals(otpCode);
    }

    /**
     * Change password for a user who logged in with a temporary password.
     * - Verifies the old password
     * - Encodes and saves the new password
     * - Clears the "mustChangePassword" flag
     * - Clears any OTP information
     */
    public void changePasswordFirstLogin(String email, String oldPassword, String newPassword) {
        Optional<User> userOpt = userRepository.findByEmail(email);

        if (userOpt.isEmpty()) {
            throw new IllegalArgumentException("Utilisateur introuvable");
        }

        User user = userOpt.get();

        // Check the old (temporary) password
        if (!passwordEncoder.matches(oldPassword, user.getPassword())) {
            throw new IllegalArgumentException("Ancien mot de passe incorrect");
        }

        // Set new encoded password
        user.setPassword(passwordEncoder.encode(newPassword));

        // IMPORTANT: clear the "must change password" flag
        user.setMustChangePassword(false);

        // Optional: clear OTP fields
        user.setOtpCode(null);
        user.setOtpExpiry(null);

        // Because of @Transactional, flush will happen automatically,
        // but calling save() makes the intent explicit.
        userRepository.save(user);
    }

    /**
     * Generate a 6-digit OTP code.
     */
    private String generateOtp() {
        Random random = new Random();
        int otp = 100000 + random.nextInt(900000);
        return String.valueOf(otp);
    }

    /**
     * Enable MFA for a user.
     */
    public void enableMfa(User user, String secret) {
        user.setMfaEnabled(true);
        user.setMfaSecret(secret);
        userRepository.save(user);
    }

    /**
     * Disable MFA for a user.
     */
    public void disableMfa(User user) {
        user.setMfaEnabled(false);
        user.setMfaSecret(null);
        userRepository.save(user);
    }
}
