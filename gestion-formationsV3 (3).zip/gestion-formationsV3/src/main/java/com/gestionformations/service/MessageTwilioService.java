package com.gestionformations.service;

// Import des classes JPA / repository / entité
import com.gestionformations.config.TwilioConfig;
import com.gestionformations.data.MessageTwilio;
import com.gestionformations.repository.MessageTwilioRepository;

// Twilio SDK - dépendance qui fait le lien avec l'API Twilio
import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;

// Annotations Spring
import org.springframework.stereotype.Service;

// Permet d'exécuter une méthode après l'injection des dépendances
import jakarta.annotation.PostConstruct;

import java.util.List;

/**
 * MessageTwilioService — service métier pour la gestion des messages Twilio.
 * 
 * Responsabilités :
 * - Initialiser Twilio après injection des configurations
 * - Traiter les messages entrants (reçus via webhook)
 * - Retraiter l'historique des messages
 * - Envoyer des SMS via l'API Twilio
 * 
 * Toute la logique métier SMS est centralisée ici.
 */
@Service // Marque la classe comme bean de service géré par Spring
public class MessageTwilioService {

    // Bean de configuration Twilio injecté (regroupe SID, token, numéro)
    private final TwilioConfig config;

    // Repository JPA pour persister les messages (injection via constructeur)
    private final MessageTwilioRepository messageTwilioRepository;

    /**
     * Constructeur avec injection de dépendances.
     * Spring injecte automatiquement TwilioConfig et le repository.
     * 
     * IMPORTANT : Ne pas appeler Twilio.init() dans le constructeur,
     * car les propriétés peuvent ne pas être entièrement bindées à ce moment.
     */
    public MessageTwilioService(TwilioConfig config, MessageTwilioRepository messageTwilioRepository) {
        this.config = config; // Initialisation de la config Twilio
        this.messageTwilioRepository = messageTwilioRepository;
    }

    /**
     * Méthode exécutée après que Spring a fini d'injecter toutes les dépendances.
     * C'est le bon moment pour initialiser Twilio de façon sécurisée.
     * 
     * Si la configuration est manquante, une exception claire est levée
     * pour éviter des NullPointerException plus tard.
     */
    @PostConstruct
    public void initTwilio() {
        // Vérification défensive : s'assure que les propriétés ont bien été chargées
        if (config.getAccountSid() == null || config.getAccountSid().isBlank()
                || config.getAuthToken() == null || config.getAuthToken().isBlank()) {
            // Si l'une des valeurs est manquante, meilleure erreur que NullPointerException
            throw new IllegalStateException("Configuration Twilio manquante! " +
                    "Définissez TWILIO_ACCOUNT_SID et TWILIO_AUTH_TOKEN (variables d'environnement ou properties).");
        }

        // Initialisation du client Twilio avec SID et token
        Twilio.init(config.getAccountSid(), config.getAuthToken());

        // Log utile au démarrage pour vérifier la configuration (ne pas logger le token)
        System.out.println("Twilio initialisé avec Account SID: " + config.getAccountSid());
        System.out.println("Numéro Twilio: " + config.getPhoneNumber());
    }

    /**
     * Traite un message entrant reçu via webhook Twilio.
     * 
     * Étapes :
     * 1. Persiste le message dans la BDD via le repository
     * 2. Exécute une logique métier basée sur le contenu
     * 3. Retourne une réponse appropriée
     *
     * @param from Numéro expéditeur (format international)
     * @param to Numéro destinataire (votre numéro Twilio) 
     * @param body Contenu textuel du SMS
     * @return Texte de la réponse à envoyer au client (format TwiML)
     */
    public String traitementMessageEntrant(String from, String to, String body) {
        // Création d'une entité MessageTwilio et sauvegarde en base
        MessageTwilio sms = new MessageTwilio(from, to, body);
        messageTwilioRepository.save(sms);

        // Log pour le débogage
        System.out.println("Message reçu de " + from + ": " + body);

        // Traitement métier simple basé sur le contenu du message
        if (body == null) {
            return "Message vide reçu.";
        }

        String trimmed = body.trim().toUpperCase();

        // Logique de commandes simples (exemple)
        if (trimmed.equals("PING")) {
            return "PONG 🏓";
        } else if (trimmed.equals("HELLO") || trimmed.equals("BONJOUR")) {
            return "Salut ! 👋 Bienvenue dans le système de gestion des formations.";
        } else if (trimmed.equals("HELP") || trimmed.equals("AIDE")) {
            return "Commandes disponibles: PING, HELLO, HELP, STATUT";
        } else if (trimmed.equals("STATUT")) {
            return "Système opérationnel ✅";
        } else {
            return "Commande non reconnue. Tapez HELP pour voir les options disponibles.";
        }
    }

    /**
     * Parcourt tous les messages déjà enregistrés en base et applique un traitement.
     * 
     * Cas d'usage :
     * - Retraitement des messages après une mise à jour de la logique métier
     * - Génération de statistiques
     * - Actions batch sur l'historique
     * 
     * Attention : Peut envoyer des SMS (coûts Twilio) selon la logique implémentée.
     */
    public void processAllExistingMessages() {
        // Récupère tous les messages depuis la base de données
        List<MessageTwilio> messages = messageTwilioRepository.findAll();

        System.out.println("Traitement de " + messages.size() + " messages stockés...");

        // Parcours et traitement de chaque message
        for (MessageTwilio msg : messages) {
            System.out.println("De: " + msg.getFromNumber() + " | Message: " + msg.getBody());
            
            // Exemple : renvoyer un message de suivi pour les messages "HELLO"
            if (msg.getBody() != null && msg.getBody().toUpperCase().equals("HELLO")) {
                // Envoi d'un SMS de suivi (attention aux coûts Twilio)
                sendSms(msg.getFromNumber(), "Bonjour à nouveau ! Votre message a été bien reçu. 👋");
            }
        }

        System.out.println("Traitement terminé.");
    }

    /**
     * Envoie un SMS via l'API Twilio.
     * 
     * Utilise le numéro Twilio défini dans la configuration comme expéditeur.
     * Gère automatiquement les erreurs d'API (levées comme exceptions Runtime).
     *
     * @param to Numéro destinataire (format international: +33...)
     * @param body Texte du message à envoyer
     */
    public void sendSms(String to, String body) {
        try {
            // Création et envoi du message via l'API Twilio
            Message message = Message.creator(
                    new PhoneNumber(to),                    // Destinataire
                    new PhoneNumber(config.getPhoneNumber()), // Expéditeur (votre numéro Twilio)
                    body                                   // Contenu
            ).create();

            // Log du SID du message pour le suivi
            System.out.println("SMS envoyé avec SID: " + message.getSid());
            
            // Persistence du message envoyé en base (optionnel)
            MessageTwilio smsSent = new MessageTwilio(config.getPhoneNumber(), to, body);
            messageTwilioRepository.save(smsSent);
            
        } catch (Exception e) {
            System.err.println("Erreur lors de l'envoi du SMS à " + to + ": " + e.getMessage());
            throw new RuntimeException("Échec de l'envoi du SMS", e);
        }
    }
}