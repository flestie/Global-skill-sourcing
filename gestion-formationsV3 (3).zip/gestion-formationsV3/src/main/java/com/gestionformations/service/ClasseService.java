package com.gestionformations.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gestionformations.data.Classe;
import com.gestionformations.data.Ecole;
import com.gestionformations.data.Formateur;
import com.gestionformations.data.Formation;
import com.gestionformations.data.User;
import com.gestionformations.dto.ClasseDTO;
import com.gestionformations.dto.ClasseDetailDTO;
import com.gestionformations.dto.CompetenceInfoDTO;
import com.gestionformations.dto.CreateClasseDTO;
import com.gestionformations.dto.EcoleInfoDTO;
import com.gestionformations.dto.FormateurInfoDTO;
import com.gestionformations.dto.FormationInfoDTO;
import com.gestionformations.repository.ClasseRepository;
import com.gestionformations.repository.EcoleRepository;
import com.gestionformations.repository.FormateurRepository;
import com.gestionformations.repository.FormationRepository;

@Service
@Transactional
public class ClasseService {

    private final ClasseRepository classeRepository;
    private final EcoleRepository ecoleRepository;
    private final FormationRepository formationRepository;
    private final FormateurRepository formateurRepository;

    public ClasseService(ClasseRepository classeRepository, 
                        EcoleRepository ecoleRepository,
                        FormationRepository formationRepository,
                        FormateurRepository formateurRepository) {
        this.classeRepository = classeRepository;
        this.ecoleRepository = ecoleRepository;
        this.formationRepository = formationRepository;
        this.formateurRepository = formateurRepository;
    }

    // ==================== MÉTHODES DTO (NOUVELLES) ====================

    /**
     * Retourne la liste de toutes les classes en DTO
     * @return Liste de ClasseDTO
     */
    public List<ClasseDTO> getAllClassesDTO() {
        return classeRepository.findAll().stream()
            .map(this::convertToDTO)
            .collect(Collectors.toList());
    }
    
    
    public List<ClasseDTO> getAllClassesDTO(User currentUser) {
        if (currentUser.isAdmin()) {
            // Admin voit toutes les classes
            return classeRepository.findAll().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
        } else {
            // Formateur voit seulement ses classes
            return classeRepository.findAll().stream()
                .filter(classe -> classe.getFormateur().getId().equals(currentUser.getFormateur().getId()))
                .map(this::convertToDTO)
                .collect(Collectors.toList());
        }
    }

    /**
     * Retourne une classe par son ID en DTO
     * @param id ID de la classe
     * @return ClasseDTO ou null si non trouvée
     */
    public ClasseDTO getClasseByIdDTO(Long id) {
        return classeRepository.findById(id)
            .map(this::convertToDTO)
            .orElse(null);
    }
    
    public ClasseDTO getClasseByIdDTO(Long id, User currentUser) {
        Classe classe = classeRepository.findById(id).orElse(null);
        if (classe == null) return null;
        
        // L'admin peut tout voir, les autres seulement leurs classes
        if (!currentUser.isAdmin() && 
            !classe.getFormateur().getId().equals(currentUser.getFormateur().getId())) {
            throw new AccessDeniedException("Accès non autorisé à cette classe");
        }
        
        return convertToDTO(classe);
    }

    /**
     * Crée une nouvelle classe à partir d'un DTO
     * @param classeDTO Données de la classe à créer
     * @return ClasseDTO de la classe créée
     */
    public ClasseDTO createClasseDTO(CreateClasseDTO classeDTO) {
        Classe classe = new Classe();
        classe.setNom(classeDTO.getNom());
        classe.setNb_participants(classeDTO.getNbParticipants());
        classe.setLieu(classeDTO.getLieu());
        
        // ⚠️ IMPORTANT : Gérer les relations avec les IDs
        Optional<Ecole> ecoleOpt = ecoleRepository.findById(classeDTO.getEcoleId());
        Optional<Formation> formationOpt = formationRepository.findById(classeDTO.getFormationId());
        Optional<Formateur> formateurOpt = formateurRepository.findById(classeDTO.getFormateurId());
        
        if (ecoleOpt.isEmpty()) {
            throw new RuntimeException("École non trouvée avec l'ID: " + classeDTO.getEcoleId());
        }
        if (formationOpt.isEmpty()) {
            throw new RuntimeException("Formation non trouvée avec l'ID: " + classeDTO.getFormationId());
        }
        if (formateurOpt.isEmpty()) {
            throw new RuntimeException("Formateur non trouvé avec l'ID: " + classeDTO.getFormateurId());
        }
        
        classe.setEcole(ecoleOpt.get());
        classe.setFormation(formationOpt.get());
        classe.setFormateur(formateurOpt.get());
        
        Classe savedClasse = classeRepository.save(classe);
        return convertToDTO(savedClasse);
    }

    /**
     * Met à jour une classe existante à partir d'un DTO
     * @param id ID de la classe à mettre à jour
     * @param classeDTO Nouvelles données
     * @return ClasseDTO mise à jour ou null si non trouvée
     */
    public ClasseDTO updateClasseDTO(Long id, CreateClasseDTO classeDTO) {
        Optional<Classe> classeOpt = classeRepository.findById(id);
        
        if (classeOpt.isEmpty()) {
            return null;
        }
        
        Classe classe = classeOpt.get();
        classe.setNom(classeDTO.getNom());
        classe.setNb_participants(classeDTO.getNbParticipants());
        classe.setLieu(classeDTO.getLieu());
        
        // Mettre à jour les relations si fournies
        if (classeDTO.getEcoleId() != null) {
            Optional<Ecole> ecoleOpt = ecoleRepository.findById(classeDTO.getEcoleId());
            ecoleOpt.ifPresent(classe::setEcole);
        }
        
        if (classeDTO.getFormationId() != null) {
            Optional<Formation> formationOpt = formationRepository.findById(classeDTO.getFormationId());
            formationOpt.ifPresent(classe::setFormation);
        }
        
        if (classeDTO.getFormateurId() != null) {
            Optional<Formateur> formateurOpt = formateurRepository.findById(classeDTO.getFormateurId());
            formateurOpt.ifPresent(classe::setFormateur);
        }
        
        Classe updatedClasse = classeRepository.save(classe);
        return convertToDTO(updatedClasse);
    }

    // ==================== MÉTHODES EXISTANTES (GARDÉES) ====================

    /**
     * Retourne la liste de toutes les classes (entités)
     */
    public List<Classe> getAllClasses() {
        return classeRepository.findAll();
    }

    /**
     * Retourne une classe par son ID (entité)
     */
    public Classe getClasseById(Long id) {
        return classeRepository.findById(id).orElse(null);
    }

    /**
     * Sauvegarde une classe (entité)
     */
    public Classe saveClasse(Classe classe) {
        return classeRepository.save(classe);
    }

    /**
     * Supprime une classe par son ID
     */
    public void deleteClasse(Long id) {
        classeRepository.deleteById(id);
    }

    // ==================== MÉTHODE DE CONVERSION ====================

    /**
     * Convertit une entité Classe en ClasseDTO
     * @param classe Entité Classe à convertir
     * @return ClasseDTO correspondant
     */
    private ClasseDTO convertToDTO(Classe classe) {
        return new ClasseDTO(
            classe.getId(),
            classe.getNom(),
            classe.getNb_participants(),
            classe.getLieu(),
            classe.getEcole() != null ? classe.getEcole().getId() : null,
            classe.getFormation() != null ? classe.getFormation().getId() : null,
            classe.getFormateur() != null ? classe.getFormateur().getId() : null
        );
    }
    
 // ==================== MÉTHODES POUR DÉTAILS ====================

    /**
     * Retourne toutes les classes avec détails des relations
     */
    public List<ClasseDetailDTO> getAllClassesWithDetails() {
        return classeRepository.findAll().stream()
            .map(this::convertToDetailDTO)
            .collect(Collectors.toList());
    }

    /**
     * Retourne une classe avec détails des relations
     */
    public ClasseDetailDTO getClasseWithDetails(Long id) {
        return classeRepository.findById(id)
            .map(this::convertToDetailDTO)
            .orElse(null);
    }

    // ==================== MÉTHODE DE CONVERSION DÉTAILLÉE ====================

    private ClasseDetailDTO convertToDetailDTO(Classe classe) {
        EcoleInfoDTO ecoleInfo = null;
        if (classe.getEcole() != null) {
            ecoleInfo = new EcoleInfoDTO(classe.getEcole().getId(), classe.getEcole().getNom());
        }
        
        FormationInfoDTO formationInfo = null;
        if (classe.getFormation() != null) {
            formationInfo = new FormationInfoDTO(
                classe.getFormation().getId(),
                classe.getFormation().getNom(),
                classe.getFormation().getDuree(),
                classe.getFormation().getFormat().toString()
            );
        }
        
        FormateurInfoDTO formateurInfo = null;
        if (classe.getFormateur() != null) {
            // Convertir les compétences du formateur
            List<CompetenceInfoDTO> competences = classe.getFormateur().getCompetences().stream()
                .map(competence -> new CompetenceInfoDTO(competence.getId(), competence.getNom()))
                .collect(Collectors.toList());
                
            formateurInfo = new FormateurInfoDTO(
                classe.getFormateur().getId(),
                classe.getFormateur().getNom(),
                classe.getFormateur().getPrenom(),
                classe.getFormateur().getEmail(),
                competences  // ← AJOUT des compétences
            );
        }
        
        return new ClasseDetailDTO(
            classe.getId(),
            classe.getNom(),
            classe.getNb_participants(),
            classe.getLieu(),
            ecoleInfo,
            formationInfo,
            formateurInfo
        );
    }
    
 // Récupérer les classes d'un formateur
    public List<ClasseDTO> getClassesByFormateur(Long formateurId, User currentUser) {
        if (!currentUser.getFormateur().getId().equals(formateurId)) {
            throw new AccessDeniedException("Accès non autorisé aux classes d'un autre formateur");
        }
        
        return classeRepository.findAll().stream()
            .filter(classe -> classe.getFormateur().getId().equals(formateurId))
            .map(this::convertToDTO)
            .collect(Collectors.toList());
    }
}
