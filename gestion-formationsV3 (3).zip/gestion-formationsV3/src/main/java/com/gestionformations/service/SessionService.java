package com.gestionformations.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gestionformations.data.Session;
import com.gestionformations.dto.SessionDTO;
import com.gestionformations.dto.CreateSessionDTO;
import com.gestionformations.repository.SessionRepository;

@Service
@Transactional
public class SessionService {

    private final SessionRepository sessionRepository;

    public SessionService(SessionRepository sessionRepository) {
        this.sessionRepository = sessionRepository;
    }

    // ==================== MÉTHODES DTO (NOUVELLES) ====================

    /**
     * Retourne toutes les sessions en DTO
     */
    public List<SessionDTO> getAllSessionsDTO() {
        return sessionRepository.findAll().stream()
            .map(this::convertToDTO)
            .collect(Collectors.toList());
    }

    /**
     * Retourne une session par son ID en DTO
     */
    public SessionDTO getSessionByIdDTO(Long id) {
        return sessionRepository.findById(id)
            .map(this::convertToDTO)
            .orElse(null);
    }

    /**
     * Crée une nouvelle session à partir d'un DTO
     */
    public SessionDTO createSessionDTO(CreateSessionDTO sessionDTO) {
        Session session = new Session();
        session.setNom(sessionDTO.getNom());
        session.setHoraire(sessionDTO.getHoraire());
        session.setDate_debut_cours(sessionDTO.getDateDebutCours());
        session.setDate_fin_cours(sessionDTO.getDateFinCours());
        session.setDate_debut_stage(sessionDTO.getDateDebutStage());
        session.setDate_fin_stage(sessionDTO.getDateFinStage());
        
        // ⚠️ La relation avec Classe doit être gérée séparément
        // session.setClasse(classeService.getClasseById(sessionDTO.getClasseId()));
        
        Session savedSession = sessionRepository.save(session);
        return convertToDTO(savedSession);
    }

    /**
     * Met à jour une session existante à partir d'un DTO
     */
    public SessionDTO updateSessionDTO(Long id, CreateSessionDTO sessionDTO) {
        Optional<Session> sessionOpt = sessionRepository.findById(id);
        
        if (sessionOpt.isEmpty()) {
            return null;
        }
        
        Session session = sessionOpt.get();
        session.setNom(sessionDTO.getNom());
        session.setHoraire(sessionDTO.getHoraire());
        session.setDate_debut_cours(sessionDTO.getDateDebutCours());
        session.setDate_fin_cours(sessionDTO.getDateFinCours());
        session.setDate_debut_stage(sessionDTO.getDateDebutStage());
        session.setDate_fin_stage(sessionDTO.getDateFinStage());
        
        Session updatedSession = sessionRepository.save(session);
        return convertToDTO(updatedSession);
    }

    // ==================== MÉTHODES EXISTANTES (GARDÉES) ====================

    public List<Session> getAllSessions() {
        return sessionRepository.findAll();
    }

    public Session getSessionById(Long id) {
        return sessionRepository.findById(id).orElse(null);
    }

    public Session saveSession(Session session) {
        return sessionRepository.save(session);
    }

    public void deleteSession(Long id) {
        sessionRepository.deleteById(id);
    }

    // ==================== MÉTHODE DE CONVERSION ====================

    private SessionDTO convertToDTO(Session session) {
        return new SessionDTO(
            session.getId(),
            session.getNom(),
            session.getHoraire(),
            session.getDate_debut_cours(),
            session.getDate_fin_cours(),
            session.getDate_debut_stage(),
            session.getDate_fin_stage(),
            session.getClasse() != null ? session.getClasse().getId() : null
        );
    }
}