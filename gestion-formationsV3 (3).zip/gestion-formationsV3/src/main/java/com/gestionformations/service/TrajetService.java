package com.gestionformations.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.security.access.AccessDeniedException;
import com.gestionformations.data.Formateur;
import com.gestionformations.data.Trajet;
import com.gestionformations.data.User;
import com.gestionformations.dto.CreateTrajetDTO;
import com.gestionformations.dto.PreuveInfoDTO;
import com.gestionformations.dto.TrajetDTO;
import com.gestionformations.repository.FormateurRepository;
import com.gestionformations.repository.TrajetRepository;
import java.util.ArrayList;
import java.util.stream.Collectors;

/**
 * Service pour la gestion de la logique métier des trajets
 */
@Service
@Transactional
public class TrajetService {

    private final TrajetRepository trajetRepository;
    private final FormateurRepository formateurRepository;

    // Injection des dépendances via le constructeur
    public TrajetService(TrajetRepository trajetRepository, FormateurRepository formateurRepository) {
        this.trajetRepository = trajetRepository;
        this.formateurRepository = formateurRepository;
    }

    // ====================
    // CONVERSION DTO
    // ====================

    /**
     * Convertit une entité Trajet en TrajetDTO
     * Évite les problèmes de sérialisation JSON avec les relations JPA
     */
    private TrajetDTO convertToDTO(Trajet trajet) {
        List<PreuveInfoDTO> preuvesDTO = trajet.getPreuves() != null ? 
            trajet.getPreuves().stream()
                .map(preuve -> new PreuveInfoDTO(preuve.getId(), preuve.getFileName()))
                .collect(Collectors.toList()) :
            new ArrayList<>();

        return new TrajetDTO(
            trajet.getId(),
            trajet.getDistance(),
            trajet.getCorrespondances(),
            trajet.getVilleDepart(),
            trajet.getVilleArrivee(),
            trajet.getFormateur() != null ? trajet.getFormateur().getId() : null,
            trajet.getBadgesUtilises(),
            preuvesDTO  // ←  LES PREUVES
        );
    }

    // ====================
    // MÉTHODES DE RÉCUPÉRATION (DTO)
    // ====================

    /**
     * Récupère tous les trajets sous forme de DTOs
     */
    public List<TrajetDTO> getAllTrajets() {
        return trajetRepository.findAll().stream()
            .map(this::convertToDTO)
            .toList();
    }

    /**
     * Récupère un trajet par son ID sous forme de DTO
     */
    public TrajetDTO getTrajetByIdDTO(Long id) {
        Optional<Trajet> trajet = trajetRepository.findById(id);
        return trajet.map(this::convertToDTO).orElse(null);
    }

    
    /**
     * Récupère tous les trajets d'un formateur (entités JPA - usage interne uniquement)
     */
    public List<Trajet> getTrajetsByFormateur(Long formateurId) {
        return trajetRepository.findByFormateurId(formateurId);
    }

    /**
     * Récupère tous les trajets d'un formateur sous forme de DTOs
     */
    public List<TrajetDTO> getTrajetsByFormateurDTO(Long formateurId, User currentUser) {
        System.out.println("DEBUG: formateurId demandé: " + formateurId);
        System.out.println("DEBUG: currentUser formateur ID: " + (currentUser.getFormateur() != null ? currentUser.getFormateur().getId() : "null"));
        System.out.println("DEBUG: currentUser est admin: " + currentUser.isAdmin());
        if (!currentUser.isAdmin() && !currentUser.getFormateur().getId().equals(formateurId)) {
            throw new AccessDeniedException("Accès non autorisé aux trajets d'un autre formateur");
        }
        
        return getTrajetsByFormateur(formateurId).stream()
            .map(trajet -> {
                TrajetDTO dto = convertToDTO(trajet);
                // Charger les preuves
                if (trajet.getPreuves() != null) {
                    dto.setPreuves(trajet.getPreuves().stream()
                        .map(preuve -> new PreuveInfoDTO(preuve.getId(), preuve.getFileName()))
                        .collect(Collectors.toList()));
                } else {
                    dto.setPreuves(new ArrayList<>());
                }
                return dto;
            })
            .toList();
    }

    // ====================
    // MÉTHODES DE RÉCUPÉRATION (Entités - pour usage interne)
    // ====================

    /**
     * Récupère un trajet par son ID (entité JPA - usage interne uniquement)
     */
    public Trajet getTrajetById(Long id) {
        Optional<Trajet> trajet = trajetRepository.findById(id);
        return trajet.orElse(null);
    }


    // ====================
    // CRÉATION
    // ====================

    /**
     * Crée un nouveau trajet pour un formateur
     * @param formateurId ID du formateur propriétaire du trajet
     * @param trajetDTO Données du trajet à créer
     * @return Le trajet créé sous forme de DTO, ou null si le formateur n'existe pas
     */
    public TrajetDTO createTrajet(Long formateurId, CreateTrajetDTO trajetDTO, User currentUser) {
        if (!currentUser.isAdmin() && !currentUser.getFormateur().getId().equals(formateurId)) {
            throw new AccessDeniedException("Impossible de créer un trajet pour un autre formateur");
        }
    	
        // Vérifie que le formateur existe
        Optional<Formateur> formateurOpt = formateurRepository.findById(formateurId);
        if (formateurOpt.isEmpty()) {
            return null; // Formateur non trouvé
        }
        
        Formateur formateur = formateurOpt.get();
        
        // Convertit le DTO en Entité JPA
        Trajet trajet = new Trajet();
        trajet.setDistance(trajetDTO.getDistance());
        trajet.setCorrespondances(trajetDTO.getCorrespondances());
        trajet.setVilleDepart(trajetDTO.getVilleDepart());
        trajet.setVilleArrivee(trajetDTO.getVilleArrivee());
        trajet.setBadgesUtilises(trajetDTO.getBadgesUtilises());
        trajet.setFormateur(formateur);
        
        // Sauvegarde en base de données
        Trajet savedTrajet = trajetRepository.save(trajet);
        
        // Retourne le DTO (évite les problèmes de sérialisation)
        return convertToDTO(savedTrajet);
    }

    // ====================
    // MODIFICATION
    // ====================

    /**
     * Met à jour un trajet existant (version DTO)
     */
    public TrajetDTO updateTrajetDTO(Long id, CreateTrajetDTO trajetDetails) {
        Optional<Trajet> trajetOpt = trajetRepository.findById(id);
        
        if (trajetOpt.isEmpty()) {
            return null; // Trajet non trouvé
        }
        
        Trajet trajet = trajetOpt.get();
        
        // Met à jour les champs modifiables
        trajet.setDistance(trajetDetails.getDistance());
        trajet.setCorrespondances(trajetDetails.getCorrespondances());
        trajet.setVilleDepart(trajetDetails.getVilleDepart());
        trajet.setVilleArrivee(trajetDetails.getVilleArrivee());
        trajet.setBadgesUtilises(trajetDetails.getBadgesUtilises());
        
        // Note: on ne change pas le formateur lors de la mise à jour
        
        Trajet updatedTrajet = trajetRepository.save(trajet);
        return convertToDTO(updatedTrajet);
    }

    /**
     * Met à jour un trajet existant (version entité - pour usage interne)
     */
    public Trajet updateTrajet(Long id, Trajet trajetDetails) {
        Optional<Trajet> trajetOpt = trajetRepository.findById(id);
        
        if (trajetOpt.isEmpty()) {
            return null; // Trajet non trouvé
        }
        
        Trajet trajet = trajetOpt.get();
        
        // Met à jour les champs modifiables
        trajet.setDistance(trajetDetails.getDistance());
        trajet.setCorrespondances(trajetDetails.getCorrespondances());
        trajet.setVilleDepart(trajetDetails.getVilleDepart());
        trajet.setVilleArrivee(trajetDetails.getVilleArrivee());
        trajet.setBadgesUtilises(trajetDetails.getBadgesUtilises());
        
        return trajetRepository.save(trajet);
    }

    // ====================
    // SUPPRESSION
    // ====================

    /**
     * Supprime un trajet par son ID
     * @return true si suppression réussie, false si trajet non trouvé
     */
    public boolean deleteTrajet(Long id) {
        Optional<Trajet> trajetOpt = trajetRepository.findById(id);
        if (trajetOpt.isPresent()) {
            // Hibernate supprimera AUTOMATIQUEMENT les preuves grâce au cascade delete
            trajetRepository.delete(trajetOpt.get());
            return true;
        }
        return false;
    }

    // ====================
    // CALCULS ET STATISTIQUES
    // ====================

    /**
     * Calcule la distance totale parcourue par un formateur
     * @param formateurId ID du formateur
     * @return Distance totale en kilomètres
     */
 // Méthode INTERNE (sans sécurité - pour usage par d'autres services)
    public double getDistanceTotaleByFormateur(Long formateurId) {
        List<Trajet> trajets = trajetRepository.findByFormateurId(formateurId);
        return trajets.stream()
                     .mapToDouble(Trajet::getDistance)
                     .sum();
    }

    // Méthode EXTERNE (avec sécurité - pour les controllers)  
    public double getDistanceTotaleByFormateur(Long formateurId, User currentUser) {
        if (!currentUser.isAdmin() && !currentUser.getFormateur().getId().equals(formateurId)) {
            throw new AccessDeniedException("Accès non autorisé aux statistiques d'un autre formateur");
        }
        
        return getDistanceTotaleByFormateur(formateurId);
    }

    /**
     * Trouve les trajets entre deux villes spécifiques
     */
    public List<Trajet> getTrajetsByVilles(String villeDepart, String villeArrivee) {
        List<Trajet> trajetsDepart = trajetRepository.findByVilleDepart(villeDepart);
        
        // Filtre pour garder seulement ceux qui arrivent à la bonne ville
        return trajetsDepart.stream()
                           .filter(t -> t.getVilleArrivee().equalsIgnoreCase(villeArrivee))
                           .toList();
    }
}