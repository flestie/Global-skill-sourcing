package com.gestionformations.service;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.gestionformations.data.Classe;
import com.gestionformations.data.Competence;
import com.gestionformations.data.Formateur;
import com.gestionformations.data.User;
import com.gestionformations.dto.ClasseDTO;
import com.gestionformations.dto.CompetenceDTO;
import com.gestionformations.dto.CreateFormateurDTO;
import com.gestionformations.dto.FormateurDTO;
import com.gestionformations.repository.CompetenceRepository;
import com.gestionformations.repository.FormateurRepository;
import com.gestionformations.repository.FormationRepository;
import com.gestionformations.repository.UserRepository;

import jakarta.transaction.Transactional;


@Service
public class FormateurService {

    private final FormateurRepository formateurRepository;
    private final CompetenceRepository competenceRepository;
    private final FormationRepository formationRepository;
    private final TrajetService trajetService;
    
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;


    // Constructeur avec injection des repositories
    public FormateurService(FormateurRepository formateurRepository,
	            CompetenceRepository competenceRepository,
	            FormationRepository formationRepository,
	            TrajetService trajetService,
	            UserRepository userRepository,
	            PasswordEncoder passwordEncoder) {
	this.formateurRepository = formateurRepository;
	this.competenceRepository = competenceRepository;
	this.formationRepository = formationRepository;
	this.trajetService = trajetService;
	this.userRepository = userRepository;
	this.passwordEncoder = passwordEncoder;
	}


    // ----------------------------
    // Méthodes CRUD simples
    // ----------------------------

    /**
     * Retourne la liste de tous les formateurs
     */
    public List<Formateur> getAllFormateurs() {
        return formateurRepository.findAll();
    }

    /**
     * Retourne un formateur par son ID, ou null s'il n'existe pas
     */
    public Formateur getFormateurById(Long id) {
        return formateurRepository.findById(id).orElse(null);
    }

    /**
     * Sauvegarde un formateur dans la base de données
     */
    public Formateur saveFormateur(Formateur formateur) {
        return formateurRepository.save(formateur);
    }

    /**
     * Supprime un formateur par son ID
     */
    public void deleteFormateur(Long id) {
        formateurRepository.deleteById(id);
    }

    // ----------------------------
    // Méthodes pour gérer les relations
    // ----------------------------

    /**
     * Ajoute une compétence à un formateur
     *
     * @param formateurId  ID du formateur
     * @param competenceId ID de la compétence
     * @return le formateur mis à jour ou null si formateur ou compétence introuvable
     */
    public Formateur ajouterCompetence(Long formateurId, Long competenceId) {
        Optional<Formateur> formateurOpt = formateurRepository.findById(formateurId);
        Optional<Competence> competenceOpt = competenceRepository.findById(competenceId);

        if (formateurOpt.isPresent() && competenceOpt.isPresent()) {
            Formateur formateur = formateurOpt.get();
            Competence competence = competenceOpt.get();

            // Ajoute la compétence si elle n'existe pas déjà
            if (!formateur.getCompetences().contains(competence)) {
                formateur.getCompetences().add(competence);
            }

            return formateurRepository.save(formateur);
        }

        return null; // retourne null si formateur ou compétence non trouvés
    }

    /**
     * Ajoute une formation à un formateur
     *
     * Comme Formateur n'a pas de relation directe avec Formation, on crée une Classe
     * pour relier le formateur à la formation.
     *
     * @param formateurId ID du formateur
     * @param formationId ID de la formation
     * @return le formateur mis à jour ou null si formateur ou formation introuvable
     */
    /**
     * Supprime une compétence d’un formateur
     *
     * @param formateurId  ID du formateur
     * @param competenceId ID de la compétence
     * @return le formateur mis à jour ou null si formateur ou compétence introuvable
     */
    public Formateur retirerCompetence(Long formateurId, Long competenceId) {
        Optional<Formateur> formateurOpt = formateurRepository.findById(formateurId);
        Optional<Competence> competenceOpt = competenceRepository.findById(competenceId);

        if (formateurOpt.isPresent() && competenceOpt.isPresent()) {
            Formateur formateur = formateurOpt.get();
            Competence competence = competenceOpt.get();

            // Supprime la compétence si elle est présente
            if (formateur.getCompetences().contains(competence)) {
                formateur.getCompetences().remove(competence);
            }

            return formateurRepository.save(formateur);
        }

        return null; // retourne null si formateur ou compétence non trouvés
    }

    // statistique de formateur
    public Map<String, Object> getStatsFormateur(Long formateurId, User currentUser) {
        if (!currentUser.isAdmin() && !currentUser.getFormateur().getId().equals(formateurId)) {
            throw new AccessDeniedException("Accès non autorisé aux statistiques d'un autre formateur");
        }
        
        double distanceTotale = trajetService.getDistanceTotaleByFormateur(formateurId);
        int nbTrajets = trajetService.getTrajetsByFormateur(formateurId).size();
        
        return Map.of(
            "distanceTotale", distanceTotale,
            "nbTrajets", nbTrajets,
            "formateurId", formateurId
        );
    }
    
    /**
     * Retourne la liste de tous les formateurs en DTO
     */
    public List<FormateurDTO> getAllFormateursDTO() {
        return formateurRepository.findAll().stream()
            .map(this::convertToDTO)
            .collect(Collectors.toList());
    }
    
    /**
     * Retourne un formateur par son ID en DTO
     */
    public FormateurDTO getFormateurByIdDTO(Long id, User currentUser) {
        // L'admin peut tout voir, les autres seulement leurs données
        if (!currentUser.isAdmin() && !currentUser.getFormateur().getId().equals(id)) {
            throw new AccessDeniedException("Accès non autorisé aux données d'un autre formateur");
        }
        
        return formateurRepository.findById(id)
            .map(this::convertToDTO)
            .orElse(null);
    }

 

 @Transactional
 public FormateurDTO createFormateurDTO(CreateFormateurDTO formateurDTO) {

     // 1) Vérifier que l'email n'est pas déjà utilisé par un autre utilisateur
     if (userRepository.existsByEmail(formateurDTO.getEmail())) {
         throw new IllegalArgumentException("Cet email est déjà utilisé par un utilisateur.");
     }

     // 2) Vérifier que le mot de passe temporaire est fourni (admin le saisit dans le formulaire)
     if (formateurDTO.getTemporaryPassword() == null 
             || formateurDTO.getTemporaryPassword().trim().isEmpty()) {
         throw new IllegalArgumentException("Le mot de passe temporaire est obligatoire.");
     }

     // 3) Créer et sauvegarder le Formateur
     Formateur formateur = new Formateur();
     formateur.setNom(formateurDTO.getNom());
     formateur.setPrenom(formateurDTO.getPrenom());
     formateur.setEmail(formateurDTO.getEmail());
     formateur.setTelephone(formateurDTO.getTelephone());
     formateur.setVille(formateurDTO.getVille());
     formateur.setCode_postal(formateurDTO.getCodePostal());

     Formateur savedFormateur = formateurRepository.save(formateur);

     // 4) Créer l'utilisateur lié au formateur avec ROLE_FORMATEUR
     User user = new User();
     user.setEmail(formateurDTO.getEmail());
     user.setPassword(passwordEncoder.encode(formateurDTO.getTemporaryPassword()));
     user.setEnabled(true);
     user.setFormateur(savedFormateur);

     // très important : ajouter le rôle → va créer une ligne dans user_roles
     user.getRoles().add("ROLE_FORMATEUR");

     // forcer le changement de mot de passe à la première connexion
     user.setMustChangePassword(true);

     userRepository.save(user);

     // 5) Retourner le DTO
     return convertToDTO(savedFormateur);
 }



    /**
     * Met à jour un formateur à partir d'un DTO
     */
    public FormateurDTO updateFormateurDTO(Long id, CreateFormateurDTO formateurDTO) {
        Optional<Formateur> formateurOpt = formateurRepository.findById(id);
        
        if (formateurOpt.isEmpty()) {
            return null;
        }
        
        Formateur formateur = formateurOpt.get();
        formateur.setNom(formateurDTO.getNom());
        formateur.setPrenom(formateurDTO.getPrenom());
        formateur.setEmail(formateurDTO.getEmail());
        formateur.setTelephone(formateurDTO.getTelephone());
        formateur.setVille(formateurDTO.getVille());
        formateur.setCode_postal(formateurDTO.getCodePostal());
        
        Formateur updatedFormateur = formateurRepository.save(formateur);
        return convertToDTO(updatedFormateur);
    }
    
    private FormateurDTO convertToDTO(Formateur formateur) {
        return new FormateurDTO(
            formateur.getId(),
            formateur.getNom(),
            formateur.getPrenom(),
            formateur.getEmail(),
            formateur.getTelephone(),
            formateur.getVille(),
            formateur.getCode_postal()
        );
    }
    
 // ==================== MÉTHODES SPÉCIFIQUES ====================

    /**
     * Retourne les classes d'un formateur en DTO
     */
    public List<ClasseDTO> getClassesByFormateur(Long formateurId, User currentUser) {
        if (!currentUser.isAdmin() && !currentUser.getFormateur().getId().equals(formateurId)) {
            throw new AccessDeniedException("Accès non autorisé aux classes d'un autre formateur");
        }
        
        Optional<Formateur> formateurOpt = formateurRepository.findById(formateurId);
        if (formateurOpt.isEmpty()) {
            return List.of();
        }
        
        return formateurOpt.get().getClasses().stream()
            .map(this::convertClasseToDTO)
            .collect(Collectors.toList());
    }

    /**
     * Retourne les compétences d'un formateur en DTO
     */
    public List<CompetenceDTO> getCompetencesByFormateur(Long formateurId, User currentUser) {
        if (!currentUser.isAdmin() && !currentUser.getFormateur().getId().equals(formateurId)) {
            throw new AccessDeniedException("Accès non autorisé aux compétences d'un autre formateur");
        }
        
        Optional<Formateur> formateurOpt = formateurRepository.findById(formateurId);
        if (formateurOpt.isEmpty()) {
            return List.of();
        }
        
        return formateurOpt.get().getCompetences().stream()
            .map(this::convertCompetenceToDTO)
            .collect(Collectors.toList());
    }

    // ==================== MÉTHODES DE CONVERSION (À AJOUTER) ====================

    private ClasseDTO convertClasseToDTO(Classe classe) {
        return new ClasseDTO(
            classe.getId(),
            classe.getNom(),
            classe.getNb_participants(),
            classe.getLieu(),
            classe.getEcole() != null ? classe.getEcole().getId() : null,
            classe.getFormation() != null ? classe.getFormation().getId() : null,
            classe.getFormateur() != null ? classe.getFormateur().getId() : null
        );
    }

    private CompetenceDTO convertCompetenceToDTO(Competence competence) {
        return new CompetenceDTO(
            competence.getId(),
            competence.getNom()
        );
    }
    
}
