package com.gestionformations.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gestionformations.data.Formateur;
import com.gestionformations.data.User;
import com.gestionformations.dto.FormateurDTO;
import com.gestionformations.dto.MfaSetupDTO;
import com.gestionformations.dto.UserDTO;
import com.gestionformations.repository.FormateurRepository;
import com.gestionformations.repository.UserRepository;
import com.gestionformations.util.JwtUtil;

@Service
@Transactional
public class UserService {
    
    private final UserRepository userRepository;
    private final FormateurRepository formateurRepository;
    private final AuthService authService;
    private final JwtUtil jwtUtil;
    
    public UserService(UserRepository userRepository, FormateurRepository formateurRepository, AuthService authService, JwtUtil jwtUtil) {
        this.userRepository = userRepository;
        this.formateurRepository = formateurRepository;
        this.authService = authService;
        this.jwtUtil = jwtUtil;
    }
    
    
    
    public Optional<User> findUserById(Long id) {
        return userRepository.findById(id);
    }
    
    
    /**
     * Trouve un utilisateur par email
     */
    public Optional<User> findByEmail(String email) {
        return userRepository.findByEmail(email);
    }
    
    /**
     * Cree un nouvel utilisateur (formateur)
     */
    public UserDTO createUser(String email, String password, Long formateurId) {
        Optional<Formateur> formateurOpt = formateurRepository.findById(formateurId);
        
        if (formateurOpt.isEmpty()) {
            throw new RuntimeException("Formateur non trouve");
        }
        
        if (userRepository.existsByEmail(email)) {
            throw new RuntimeException("Email deja utilise");
        }
        
        User user = new User(email, password, formateurOpt.get());
        User savedUser = userRepository.save(user);
        
        return convertToDTO(savedUser);
    }
    
    /**
     * Genere un token JWT (simulation)
     * En production, utiliser une bibliotheque comme jjwt
     */
    public String generateToken(User user) {
        return jwtUtil.generateToken(user.getEmail(), user.getId(), user.isAdmin());
    }
    
    /**
     * Configure MFA pour un utilisateur
     */
    public MfaSetupDTO setupMfa(User user) {
        // Generer un secret pour Google Authenticator
        String secret = generateMfaSecret();
        
        // Generer l'URL QR Code pour Google Authenticator
        String qrCodeUrl = generateQrCodeUrl(user.getEmail(), secret);
        
        // Sauvegarder le secret (sans activer MFA pour l'instant)
        user.setMfaSecret(secret);
        userRepository.save(user);
        
        return new MfaSetupDTO(qrCodeUrl, secret, false);
    }
    
    /**
     * Verifie un code MFA et active MFA si valide
     */
    public boolean verifyMfaCode(String email, String code) {
        Optional<User> userOpt = userRepository.findByEmail(email);
        
        if (userOpt.isEmpty()) {
            return false;
        }
        
        User user = userOpt.get();
        
        // Verifier le code avec le secret (simulation)
        // En production, utiliser TOTP
        if (isValidMfaCode(user.getMfaSecret(), code)) {
            authService.enableMfa(user, user.getMfaSecret());
            return true;
        }
        
        return false;
    }
    
    /**
     * Desactive MFA pour un utilisateur
     */
    public void disableMfa(User user) {
        authService.disableMfa(user);
    }
    
    /**
     * Convertit User en UserDTO
     */
    public UserDTO convertToDTO(User user) {
        FormateurDTO formateurDTO = null;
        if (user.getFormateur() != null) {
            Formateur f = user.getFormateur();
            formateurDTO = new FormateurDTO(
                f.getId(), f.getNom(), f.getPrenom(), f.getEmail(),
                f.getTelephone(), f.getVille(), f.getCode_postal()
            );
        }
        
        return new UserDTO(user.getId(), user.getEmail(), user.isMfaEnabled(), formateurDTO, user.isAdmin());
    }
    
    /**
     * Liste tous les utilisateurs
     */
    public List<UserDTO> getAllUsers() {
        return userRepository.findAll().stream()
            .map(this::convertToDTO)
            .collect(Collectors.toList());
    }
    
    // Methodes privees pour MFA
    
    private String generateMfaSecret() {
        // Simulation - en production, utiliser une vraie generation de secret
        return "MFA-SECRET-" + System.currentTimeMillis() + "-" + (int)(Math.random() * 1000);
    }
    
    private String generateQrCodeUrl(String email, String secret) {
        // Simulation - en production, generer un vrai QR Code
        return "https://chart.googleapis.com/chart?chs=200x200&chld=M|0&cht=qr&chl=otpauth://totp/GestionFormations:" + email + "?secret=" + secret + "&issuer=GestionFormations";
    }
    
    private boolean isValidMfaCode(String secret, String code) {
        // Simulation - en production, verifier avec TOTP
        // Pour l'instant, accepter n'importe quel code a 6 chiffres
        return code != null && code.matches("\\d{6}");
    }
}