package com.gestionformations.service;

import org.springframework.stereotype.Service;
import com.gestionformations.data.Badge;
import com.gestionformations.repository.BadgeRepository;
import java.util.List;

@Service
public class BadgeService {
    
    private final BadgeRepository badgeRepository;
    
    public BadgeService(BadgeRepository badgeRepository) {
        this.badgeRepository = badgeRepository;
    }
    
    public List<Badge> getAllBadges() {
        return badgeRepository.findAll();
    }
    
    public List<Badge> getBadgesByType(String type) {
        return badgeRepository.findByType(type);
    }
    
    public Badge createBadge(Badge badge) {
        if (badgeRepository.existsByNom(badge.getNom())) {
            throw new RuntimeException("Un badge avec ce nom existe déjà");
        }
        return badgeRepository.save(badge);
    }
    
    public Badge updateBadge(Long id, Badge badgeDetails) {
        Badge badge = badgeRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Badge non trouvé"));
        
        badge.setNom(badgeDetails.getNom());
        badge.setDescription(badgeDetails.getDescription());
        badge.setType(badgeDetails.getType());
        
        return badgeRepository.save(badge);
    }
    
    public void deleteBadge(Long id) {
        badgeRepository.deleteById(id);
    }
}