package com.gestionformations.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gestionformations.data.Formation;
import com.gestionformations.data.Format; // ← IMPORT AJOUTÉ
import com.gestionformations.dto.FormationDTO;
import com.gestionformations.repository.FormationRepository;

@Service
@Transactional
public class FormationService {

    private final FormationRepository formationRepository;

    public FormationService(FormationRepository formationRepository) {
        this.formationRepository = formationRepository;
    }

    // ==================== MÉTHODES DTO (PRINCIPALES) ====================

    /**
     * Retourne toutes les formations en DTO
     */
    public List<FormationDTO> getAllFormationsDTO() {
        return formationRepository.findAll().stream()
            .map(this::convertToDTO)
            .collect(Collectors.toList());
    }

    /**
     * Retourne une formation par son ID en DTO
     */
    public FormationDTO getFormationByIdDTO(Long id) {
        return formationRepository.findById(id)
            .map(this::convertToDTO)
            .orElse(null);
    }

    /**
     * Crée une nouvelle formation à partir d'un DTO
     * Prend FormationDTO au lieu de Formation
     */
    public FormationDTO createFormationDTO(FormationDTO formationDTO) {
        Formation formation = new Formation();
        formation.setNom(formationDTO.getNom());
        formation.setDuree(formationDTO.getDuree());
        formation.setObjectifs(formationDTO.getObjectifs());
        formation.setNb_participants_max(formationDTO.getNbParticipantsMax());
        
        // ⚠️ CONVERSION : String → Enum Format
        formation.setFormat(Format.valueOf(formationDTO.getFormat()));
        
        Formation savedFormation = formationRepository.save(formation);
        return convertToDTO(savedFormation);
    }

    /**
     * Met à jour une formation existante à partir d'un DTO
     * ⚠️ MODIFICATION : Prend FormationDTO au lieu de Formation
     */
    public FormationDTO updateFormationDTO(Long id, FormationDTO formationDTO) {
        Optional<Formation> formationOpt = formationRepository.findById(id);
        
        if (formationOpt.isEmpty()) {
            return null;
        }
        
        Formation formation = formationOpt.get();
        formation.setNom(formationDTO.getNom());
        formation.setDuree(formationDTO.getDuree());
        formation.setObjectifs(formationDTO.getObjectifs());
        formation.setNb_participants_max(formationDTO.getNbParticipantsMax());
        
        // ⚠️ CONVERSION : String → Enum Format
        formation.setFormat(Format.valueOf(formationDTO.getFormat()));
        
        Formation updatedFormation = formationRepository.save(formation);
        return convertToDTO(updatedFormation);
    }

    // ==================== MÉTHODES EXISTANTES (GARDÉES) ====================

    public List<Formation> getAllFormations() {
        return formationRepository.findAll();
    }

    public Formation getFormationById(Long id) {
        return formationRepository.findById(id).orElse(null);
    }

    public Formation saveFormation(Formation formation) {
        return formationRepository.save(formation);
    }

    public void deleteFormation(Long id) {
        formationRepository.deleteById(id);
    }

    // ==================== MÉTHODE DE CONVERSION ====================

    private FormationDTO convertToDTO(Formation formation) {
        return new FormationDTO(
            formation.getId(),
            formation.getNom(),
            formation.getDuree(),
            formation.getObjectifs(),
            formation.getNb_participants_max(),
            formation.getFormat().toString() // ← Enum → String
        );
    }
}