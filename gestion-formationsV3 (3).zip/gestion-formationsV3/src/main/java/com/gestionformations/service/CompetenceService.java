package com.gestionformations.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gestionformations.data.Competence;
import com.gestionformations.dto.CompetenceDTO;
import com.gestionformations.repository.CompetenceRepository;

@Service
@Transactional
public class CompetenceService {

    private final CompetenceRepository competenceRepository;

    public CompetenceService(CompetenceRepository competenceRepository) {
        this.competenceRepository = competenceRepository;
    }

    // ==================== MÉTHODES DTO (NOUVELLES) ====================

    /**
     * Retourne toutes les compétences en DTO
     */
    public List<CompetenceDTO> getAllCompetencesDTO() {
        return competenceRepository.findAll().stream()
            .map(this::convertToDTO)
            .collect(Collectors.toList());
    }

    /**
     * Retourne une compétence par son ID en DTO
     */
    public CompetenceDTO getCompetenceByIdDTO(Long id) {
        return competenceRepository.findById(id)
            .map(this::convertToDTO)
            .orElse(null);
    }

    /**
     * Crée une nouvelle compétence à partir d'un DTO
     */
    public CompetenceDTO createCompetenceDTO(CompetenceDTO competenceDTO) {
        Competence competence = new Competence();
        competence.setNom(competenceDTO.getNom());
        
        Competence savedCompetence = competenceRepository.save(competence);
        return convertToDTO(savedCompetence);
    }

    /**
     * Met à jour une compétence existante à partir d'un DTO
     */
    public CompetenceDTO updateCompetenceDTO(Long id, CompetenceDTO competenceDTO) {
        Optional<Competence> competenceOpt = competenceRepository.findById(id);
        
        if (competenceOpt.isEmpty()) {
            return null;
        }
        
        Competence competence = competenceOpt.get();
        competence.setNom(competenceDTO.getNom());
        
        Competence updatedCompetence = competenceRepository.save(competence);
        return convertToDTO(updatedCompetence);
    }

    // ==================== MÉTHODES EXISTANTES (GARDÉES) ====================

    public List<Competence> getAllCompetences() {
        return competenceRepository.findAll();
    }

    public Competence getCompetenceById(Long id) {
        return competenceRepository.findById(id).orElse(null);
    }

    public Competence saveCompetence(Competence competence) {
        return competenceRepository.save(competence);
    }

    public void deleteCompetence(Long id) {
        competenceRepository.deleteById(id);
    }

    // ==================== MÉTHODE DE CONVERSION ====================

    private CompetenceDTO convertToDTO(Competence competence) {
        return new CompetenceDTO(
            competence.getId(),
            competence.getNom()
        );
    }
}