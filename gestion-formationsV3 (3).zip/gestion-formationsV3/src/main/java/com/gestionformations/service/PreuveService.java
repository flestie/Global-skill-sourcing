package com.gestionformations.service;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import com.gestionformations.data.Preuve;
import com.gestionformations.data.Trajet;
import com.gestionformations.repository.PreuveRepository;
import com.gestionformations.repository.TrajetRepository;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Optional;

@Service
public class PreuveService {

    private final PreuveRepository preuveRepository;
    private final TrajetRepository trajetRepository;
    private final Path rootLocation = Paths.get("uploads");

    public PreuveService(PreuveRepository preuveRepository, TrajetRepository trajetRepository) {
        this.preuveRepository = preuveRepository;
        this.trajetRepository = trajetRepository;
        
        // Créer le dossier uploads s'il n'existe pas
        try {
            Files.createDirectories(rootLocation);
        } catch (IOException e) {
            throw new RuntimeException("Could not initialize storage", e);
        }
    }

    public Preuve savePreuve(Long trajetId, MultipartFile file) {
        try {
            Optional<Trajet> trajetOpt = trajetRepository.findById(trajetId);
            if (trajetOpt.isEmpty()) {
                throw new RuntimeException("Trajet non trouvé");
            }

            String fileName = System.currentTimeMillis() + "_" + file.getOriginalFilename();
            Path destinationFile = rootLocation.resolve(Paths.get(fileName)).normalize().toAbsolutePath();
            
            // Sauvegarder le fichier
            Files.copy(file.getInputStream(), destinationFile);

            // Créer l'entité Preuve
            Preuve preuve = new Preuve();
            preuve.setFileName(file.getOriginalFilename());
            preuve.setFileUrl(destinationFile.toString());
            preuve.setTrajet(trajetOpt.get());

            return preuveRepository.save(preuve);
            
        } catch (Exception e) {
            throw new RuntimeException("Erreur sauvegarde preuve: " + e.getMessage());
        }
    }

    public void deletePreuve(Long preuveId) {
        Optional<Preuve> preuveOpt = preuveRepository.findById(preuveId);
        if (preuveOpt.isPresent()) {
            Preuve preuve = preuveOpt.get();
            try {
                // Supprimer le fichier physique
                Files.deleteIfExists(Paths.get(preuve.getFileUrl()));
                // Supprimer de la base
                preuveRepository.delete(preuve);
            } catch (IOException e) {
                throw new RuntimeException("Erreur suppression fichier", e);
            }
        }
    }
}