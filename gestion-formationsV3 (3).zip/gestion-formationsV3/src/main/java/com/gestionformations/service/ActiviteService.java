package com.gestionformations.service;

import com.gestionformations.data.Activite;
import com.gestionformations.data.User;
import com.gestionformations.repository.ActiviteRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ActiviteService {

    private final ActiviteRepository activiteRepository;

    public ActiviteService(ActiviteRepository activiteRepository) {
        this.activiteRepository = activiteRepository;
    }

    public void enregistrer(String type, String message, User utilisateur) {
        Activite activite = new Activite();
        activite.setType(type);
        activite.setMessage(message);
        activite.setUtilisateur(utilisateur);
        activiteRepository.save(activite);
    }

    public List<Activite> obtenirActivitesRecentes() {
        return activiteRepository.findTop10ByOrderByDateCreationDesc();
    }
}
