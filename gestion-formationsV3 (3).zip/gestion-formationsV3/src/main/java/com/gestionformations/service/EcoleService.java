package com.gestionformations.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.gestionformations.data.Ecole;
import com.gestionformations.dto.EcoleDTO;
import com.gestionformations.repository.EcoleRepository;

@Service
public class EcoleService {

    private final EcoleRepository ecoleRepository;

    public EcoleService(EcoleRepository ecoleRepository) {
        this.ecoleRepository = ecoleRepository;
    }

    public List<Ecole> getAllEcoles() {
        return ecoleRepository.findAll();
    }

    public Ecole getEcoleById(Long id) {
        return ecoleRepository.findById(id).orElse(null);
    }

    public Ecole saveEcole(Ecole ecole) {
        return ecoleRepository.save(ecole);
    }

    public void deleteEcole(Long id) {
        ecoleRepository.deleteById(id);
    }
    
 // ==================== MÉTHODES DTO ====================

    public List<EcoleDTO> getAllEcolesDTO() {
        return ecoleRepository.findAll().stream()
            .map(this::convertToDTO)
            .collect(Collectors.toList());
    }

    public EcoleDTO getEcoleByIdDTO(Long id) {
        return ecoleRepository.findById(id)
            .map(this::convertToDTO)
            .orElse(null);
    }

    /**
     * Crée une école à partir d'un DTO
     */
    public EcoleDTO createEcoleDTO(EcoleDTO ecoleDTO) {
        Ecole ecole = new Ecole();
        ecole.setNom(ecoleDTO.getNom());
        Ecole savedEcole = ecoleRepository.save(ecole);
        return convertToDTO(savedEcole);
    }

    /**
     * Met à jour une école à partir d'un DTO  
     */
    public EcoleDTO updateEcoleDTO(Long id, EcoleDTO ecoleDTO) {
        Optional<Ecole> ecoleOpt = ecoleRepository.findById(id);
        if (ecoleOpt.isEmpty()) {
            return null;
        }
        Ecole ecole = ecoleOpt.get();
        ecole.setNom(ecoleDTO.getNom());
        Ecole updatedEcole = ecoleRepository.save(ecole);
        return convertToDTO(updatedEcole);
    }

    // ==================== MÉTHODE DE CONVERSION ====================

    private EcoleDTO convertToDTO(Ecole ecole) {
        return new EcoleDTO(
            ecole.getId(),
            ecole.getNom()
        );
    }
}
