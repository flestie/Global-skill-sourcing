package com.gestionformations.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gestionformations.dto.FormateurDTO;
import com.gestionformations.dto.CreateFormateurDTO;
import com.gestionformations.service.FormateurService;

@WebMvcTest(FormateurControllerApi.class)
class FormateurControllerApiTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private FormateurService formateurService;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void shouldReturnAllFormateurs() throws Exception {
        // Given
        FormateurDTO formateur = new FormateurDTO(null, "Dupont", "Jean", 
                                                 "jean@test.com", "0601020304", "Paris", "75001");
        when(formateurService.getAllFormateursDTO()).thenReturn(List.of(formateur));

        // When & Then
        mockMvc.perform(get("/api/formateurs"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].nom").value("Dupont"))
                .andExpect(jsonPath("$[0].prenom").value("Jean"))
                .andExpect(jsonPath("$[0].email").value("jean@test.com"));
    }

    @Test
    void shouldReturnFormateurById() throws Exception {
        // Given
        FormateurDTO formateur = new FormateurDTO(null, "Dupont", "Jean", 
                                                 "jean@test.com", "0601020304", "Paris", "75001");
        when(formateurService.getFormateurByIdDTO(1L)).thenReturn(formateur);

        // When & Then
        mockMvc.perform(get("/api/formateurs/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.nom").value("Dupont"))
                .andExpect(jsonPath("$.prenom").value("Jean"));
    }

    @Test
    void shouldReturn404WhenFormateurNotFound() throws Exception {
        // Given
        when(formateurService.getFormateurByIdDTO(999L)).thenReturn(null);

        // When & Then
        mockMvc.perform(get("/api/formateurs/999"))
                .andExpect(status().isNotFound());
    }

    @Test
    void shouldCreateFormateur() throws Exception {
        // Given
        CreateFormateurDTO inputDTO = new CreateFormateurDTO("Martin", "Sophie", 
                                                            "sophie@test.com", "0605060708", 
                                                            "Lyon", "69000");
        
        FormateurDTO outputDTO = new FormateurDTO(null, "Martin", "Sophie", 
                                                 "sophie@test.com", "0605060708", "Lyon", "69000");
        
        when(formateurService.createFormateurDTO(any())).thenReturn(outputDTO);

        // When & Then
        mockMvc.perform(post("/api/formateurs")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(inputDTO)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.nom").value("Martin"))
                .andExpect(jsonPath("$.prenom").value("Sophie"))
                .andExpect(jsonPath("$.email").value("sophie@test.com"));
    }
}