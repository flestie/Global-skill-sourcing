package com.gestionformations.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gestionformations.dto.ClasseDTO;
import com.gestionformations.dto.ClasseDetailDTO;
import com.gestionformations.dto.CreateClasseDTO;
import com.gestionformations.service.ClasseService;

@WebMvcTest(ClasseControllerApi.class)
class ClasseControllerApiTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ClasseService classeService;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void shouldReturnAllClasses() throws Exception {
        // Given
        ClasseDTO classe = new ClasseDTO(null, "Classe Java", 15, "Salle 101", 1L, 1L, 1L);
        when(classeService.getAllClassesDTO()).thenReturn(List.of(classe));

        // When & Then
        mockMvc.perform(get("/api/classes"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].nom").value("Classe Java"))
                .andExpect(jsonPath("$[0].nbParticipants").value(15))
                .andExpect(jsonPath("$[0].lieu").value("Salle 101"))
                .andExpect(jsonPath("$[0].ecoleId").value(1L))
                .andExpect(jsonPath("$[0].formationId").value(1L))
                .andExpect(jsonPath("$[0].formateurId").value(1L));
    }

    @Test
    void shouldReturnClassById() throws Exception {
        // Given
        ClasseDTO classe = new ClasseDTO(null, "Classe Python", 20, "Salle 202", 2L, 2L, 2L);
        when(classeService.getClasseByIdDTO(1L)).thenReturn(classe);

        // When & Then
        mockMvc.perform(get("/api/classes/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.nom").value("Classe Python"))
                .andExpect(jsonPath("$.nbParticipants").value(20))
                .andExpect(jsonPath("$.lieu").value("Salle 202"));
    }

    @Test
    void shouldReturn404WhenClassNotFound() throws Exception {
        // Given
        when(classeService.getClasseByIdDTO(999L)).thenReturn(null);

        // When & Then
        mockMvc.perform(get("/api/classes/999"))
                .andExpect(status().isNotFound());
    }

    @Test
    void shouldReturnClassesWithDetails() throws Exception {
        // Given
        ClasseDetailDTO classeDetail = new ClasseDetailDTO();
        classeDetail.setNom("Classe Java Avancé");
        classeDetail.setNbParticipants(12);
        classeDetail.setLieu("Salle 301");
        
        when(classeService.getAllClassesWithDetails()).thenReturn(List.of(classeDetail));

        // When & Then
        mockMvc.perform(get("/api/classes/with-details"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].nom").value("Classe Java Avancé"))
                .andExpect(jsonPath("$[0].nbParticipants").value(12))
                .andExpect(jsonPath("$[0].lieu").value("Salle 301"));
    }

    @Test
    void shouldReturnClassWithDetailsById() throws Exception {
        // Given
        ClasseDetailDTO classeDetail = new ClasseDetailDTO();
        classeDetail.setNom("Classe Spring Boot");
        classeDetail.setNbParticipants(18);
        classeDetail.setLieu("Salle 405");
        
        when(classeService.getClasseWithDetails(1L)).thenReturn(classeDetail);

        // When & Then
        mockMvc.perform(get("/api/classes/1/with-details"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.nom").value("Classe Spring Boot"))
                .andExpect(jsonPath("$.nbParticipants").value(18))
                .andExpect(jsonPath("$.lieu").value("Salle 405"));
    }

    @Test
    void shouldCreateClasse() throws Exception {
        // Given
        CreateClasseDTO inputDTO = new CreateClasseDTO("Classe React", 25, "Salle 505", 1L, 1L, 1L);
        ClasseDTO outputDTO = new ClasseDTO(null, "Classe React", 25, "Salle 505", 1L, 1L, 1L);
        
        when(classeService.createClasseDTO(any())).thenReturn(outputDTO);

        // When & Then
        mockMvc.perform(post("/api/classes")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(inputDTO)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.nom").value("Classe React"))
                .andExpect(jsonPath("$.nbParticipants").value(25))
                .andExpect(jsonPath("$.lieu").value("Salle 505"));
    }

    @Test
    void shouldUpdateClasse() throws Exception {
        // Given
        CreateClasseDTO inputDTO = new CreateClasseDTO("Classe React Modifiée", 30, "Salle 606", 1L, 1L, 1L);
        ClasseDTO outputDTO = new ClasseDTO(null, "Classe React Modifiée", 30, "Salle 606", 1L, 1L, 1L);
        
        when(classeService.updateClasseDTO(any(), any())).thenReturn(outputDTO);

        // When & Then
        mockMvc.perform(put("/api/classes/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(inputDTO)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.nom").value("Classe React Modifiée"))
                .andExpect(jsonPath("$.nbParticipants").value(30))
                .andExpect(jsonPath("$.lieu").value("Salle 606"));
    }

    @Test
    void shouldReturn404WhenUpdatingNonExistentClasse() throws Exception {
        // Given
        CreateClasseDTO inputDTO = new CreateClasseDTO("Classe React", 25, "Salle 505", 1L, 1L, 1L);
        when(classeService.updateClasseDTO(any(), any())).thenReturn(null);

        // When & Then
        mockMvc.perform(put("/api/classes/999")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(inputDTO)))
                .andExpect(status().isNotFound());
    }

    @Test
    void shouldDeleteClasse() throws Exception {
        // When & Then
        mockMvc.perform(delete("/api/classes/1"))
                .andExpect(status().isNoContent());
    }
}