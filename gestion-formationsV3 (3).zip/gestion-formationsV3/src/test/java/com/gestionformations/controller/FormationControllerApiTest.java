package com.gestionformations.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gestionformations.dto.FormationDTO;
import com.gestionformations.service.FormationService;

@WebMvcTest(FormationControllerApi.class)
class FormationControllerApiTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private FormationService formationService;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void shouldReturnAllFormations() throws Exception {
        // Given
        FormationDTO formation = new FormationDTO(null, "Spring Boot", 50, 
                                                 "Apprendre Spring Boot", 25, "PRESENTIEL");
        when(formationService.getAllFormationsDTO()).thenReturn(List.of(formation));

        // When & Then
        mockMvc.perform(get("/api/formations"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].nom").value("Spring Boot"))
                .andExpect(jsonPath("$[0].duree").value(50))
                .andExpect(jsonPath("$[0].objectifs").value("Apprendre Spring Boot"))
                .andExpect(jsonPath("$[0].nbParticipantsMax").value(25))
                .andExpect(jsonPath("$[0].format").value("PRESENTIEL"));
    }

    @Test
    void shouldReturnFormationById() throws Exception {
        // Given
        FormationDTO formation = new FormationDTO(null, "Java", 40, 
                                                 "Apprendre Java", 20, "DISTANCIEL");
        when(formationService.getFormationByIdDTO(1L)).thenReturn(formation);

        // When & Then
        mockMvc.perform(get("/api/formations/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.nom").value("Java"))
                .andExpect(jsonPath("$.duree").value(40))
                .andExpect(jsonPath("$.format").value("DISTANCIEL"));
    }

    @Test
    void shouldReturn404WhenFormationNotFound() throws Exception {
        // Given
        when(formationService.getFormationByIdDTO(999L)).thenReturn(null);

        // When & Then
        mockMvc.perform(get("/api/formations/999"))
                .andExpect(status().isNotFound());
    }

    @Test
    void shouldCreateFormation() throws Exception {
        // Given
        FormationDTO inputDTO = new FormationDTO(null, "Java", 40, "Apprendre Java", 20, "DISTANCIEL");
        FormationDTO outputDTO = new FormationDTO(null, "Java", 40, "Apprendre Java", 20, "DISTANCIEL");
        
        when(formationService.createFormationDTO(any())).thenReturn(outputDTO);

        // When & Then
        mockMvc.perform(post("/api/formations")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(inputDTO)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.nom").value("Java"))
                .andExpect(jsonPath("$.duree").value(40))
                .andExpect(jsonPath("$.objectifs").value("Apprendre Java"))
                .andExpect(jsonPath("$.nbParticipantsMax").value(20))
                .andExpect(jsonPath("$.format").value("DISTANCIEL"));
    }

    @Test
    void shouldUpdateFormation() throws Exception {
        // Given
        FormationDTO inputDTO = new FormationDTO(null, "Java Avancé", 50, 
                                                "Java avancé et Spring", 15, "PRESENTIEL");
        FormationDTO outputDTO = new FormationDTO(null, "Java Avancé", 50, 
                                                 "Java avancé et Spring", 15, "PRESENTIEL");
        
        when(formationService.updateFormationDTO(any(), any())).thenReturn(outputDTO);

        // When & Then
        mockMvc.perform(put("/api/formations/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(inputDTO)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.nom").value("Java Avancé"))
                .andExpect(jsonPath("$.duree").value(50));
    }

    @Test
    void shouldReturn404WhenUpdatingNonExistentFormation() throws Exception {
        // Given
        FormationDTO inputDTO = new FormationDTO(null, "Java", 40, "Apprendre Java", 20, "DISTANCIEL");
        when(formationService.updateFormationDTO(any(), any())).thenReturn(null);

        // When & Then
        mockMvc.perform(put("/api/formations/999")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(inputDTO)))
                .andExpect(status().isNotFound());
    }

    @Test
    void shouldDeleteFormation() throws Exception {
        // When & Then - DELETE devrait toujours retourner 204
        mockMvc.perform(delete("/api/formations/1"))
                .andExpect(status().isNoContent());
    }
}