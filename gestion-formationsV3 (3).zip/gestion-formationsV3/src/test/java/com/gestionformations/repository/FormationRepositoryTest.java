package com.gestionformations.repository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.gestionformations.data.Format;
import com.gestionformations.data.Formation;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
class FormationRepositoryTest {

    @Autowired
    private FormationRepository formationRepository;

    @Test
    void testCreateFormation() {
        // ---------- Préparation -----------------
        Formation formation = new Formation(
                "Spring Boot",
                50,
                "Apprendre Spring Boot de A à Z",
                25,
                Format.PRESENTIEL
        );

        // ---------- Action ----------------------
        Formation nouvelleFormation = formationRepository.save(formation);

        // ---------- Vérifications ---------------
        assertNotNull(nouvelleFormation.getId(), "L'ID doit être généré automatiquement");
        assertEquals("Spring Boot", nouvelleFormation.getNom(), "Le nom doit correspondre");
    }
}
