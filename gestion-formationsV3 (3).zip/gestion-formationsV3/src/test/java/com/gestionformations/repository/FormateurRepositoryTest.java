package com.gestionformations.repository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.gestionformations.data.Formateur;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
class FormateurRepositoryTest {

    @Autowired
    private FormateurRepository formateurRepository;

    @Test
    void testCreateFormateur() {
        // ---------- Préparation -----------------
        Formateur formateur = new Formateur(
                "Durand",
                "Paul",
                "paul.durand@test.com",
                "0601020304",
                "Lyon",
                "69000"
        );

        // ---------- Action ----------------------
        Formateur nouveauFormateur = formateurRepository.save(formateur);

        // ---------- Vérifications ---------------
        assertNotNull(nouveauFormateur.getId(), "L'ID doit être généré automatiquement");
        assertEquals("Durand", nouveauFormateur.getNom(), "Le nom doit correspondre");
        assertEquals("Paul", nouveauFormateur.getPrenom(), "Le prénom doit correspondre");
    }
}
