package com.gestionformations.repository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.gestionformations.data.Competence;

/**
 * Classe de test unitaire pour la table COMPETENCE.
 * 
 * Ce test permet de vérifier que l'entité {@link Competence} est correctement
 * persistée dans la base de données via le repository {@link CompetenceRepository}.
 * 
 * Nous utilisons ici une base de données MySQL réelle (pas une base H2 en mémoire),
 * afin de valider le fonctionnement dans des conditions proches de la production.
 * 
 * @author Edgar
 * @since 12 sept. 2025
 * @see com.gestionformations.data.Competence
 */
@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE) 
class CompetenceRepositoryTest {

    // Injection du repository qui nous permet d’interagir avec la table COMPETENCE
    @Autowired
    private CompetenceRepository competenceRepository;

    /**
     * Test de création et d’insertion d’une compétence en base de données.
     * 
     * Étapes :
     * 1. Préparer un objet Competence (sans ID car il est généré automatiquement).
     * 2. Sauvegarder cet objet avec la méthode save() du repository.
     * 3. Vérifier que l’ID a bien été généré (preuve que l’insertion a réussi).
     * 4. Vérifier que le libellé (nom) sauvegardé est identique à celui attendu.
     */
    @Test
    void testCreateCompetence() {
        // ---------- Préparation des données -----------------------
        String nom = "Java"; // Exemple de compétence
        Competence competence = new Competence(nom);

        // ---------- Action : sauvegarde dans la base --------------
        Competence nouvelleCompetence = competenceRepository.save(competence);

        // ---------- Vérifications (Assertions) --------------------
        // Vérifie que l’objet a maintenant un ID généré automatiquement par MySQL
        assertNotNull(nouvelleCompetence.getId(), "L'ID doit être généré automatiquement");

        // Vérifie que le nom sauvegardé correspond à la valeur donnée
        assertEquals(nom, nouvelleCompetence.getNom(), 
                     "Le nom de la compétence doit correspondre après insertion");
    }
}
