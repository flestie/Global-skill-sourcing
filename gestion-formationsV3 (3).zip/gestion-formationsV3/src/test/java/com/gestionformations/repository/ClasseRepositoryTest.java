package com.gestionformations.repository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.gestionformations.data.Classe;
import com.gestionformations.data.Ecole;
import com.gestionformations.data.Format;
import com.gestionformations.data.Formateur;
import com.gestionformations.data.Formation;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
class ClasseRepositoryTest {

    @Autowired
    private ClasseRepository classeRepository;

    @Autowired
    private EcoleRepository ecoleRepository;

    @Autowired
    private FormationRepository formationRepository;

    @Autowired
    private FormateurRepository formateurRepository;

    @Test
    void testCreateClasse() {
        // ---------- Préparation -----------------
        Ecole ecole = ecoleRepository.save(new Ecole("Université de Paris"));
        Formation formation = formationRepository.save(new Formation("Java Avancé", 40, "Apprendre Java", 20, Format.DISTANCIEL));
        Formateur formateur = formateurRepository.save(new Formateur("Martin", "Thierry", "martin@test.com", "0612345678", "Paris", "75000"));

        Classe classe = new Classe("Classe A", 15, "Salle 101");
        classe.setEcole(ecole);
        classe.setFormation(formation);
        classe.setFormateur(formateur);

        // ---------- Action ----------------------
        Classe nouvelleClasse = classeRepository.save(classe);

        // ---------- Vérifications ---------------
        assertNotNull(nouvelleClasse.getId(), "L'ID doit être généré automatiquement");
        assertEquals("Classe A", nouvelleClasse.getNom(), "Le nom doit correspondre");
        assertEquals(ecole.getId(), nouvelleClasse.getEcole().getId(), "L'école doit être reliée");
    }
}
