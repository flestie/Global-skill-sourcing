package com.gestionformations.repository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.gestionformations.data.Ecole;

/**
 * Classe de test JUnit pour vérifier les opérations CRUD sur l’entité Ecole.
 * On utilise @DataJpaTest pour charger uniquement la couche JPA (pas toute l’application Spring Boot).
 * @AutoConfigureTestDatabase(replace = NONE) permet d’utiliser la vraie base MySQL et pas H2 en mémoire.
 */
@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
class EcoleRepositoryTest {

    @Autowired
    private EcoleRepository ecoleRepository;

    @Test
    void testCreateEcole() {
        // ---------- Préparation -----------------
        String nom = "École Polytechnique";
        Ecole ecole = new Ecole(nom);

        // ---------- Action ----------------------
        Ecole nouvelleEcole = ecoleRepository.save(ecole);

        // ---------- Vérifications ---------------
        assertNotNull(nouvelleEcole.getId(), "L'ID doit être généré automatiquement");
        assertEquals(nom, nouvelleEcole.getNom(), "Le nom doit correspondre");
    }
}
