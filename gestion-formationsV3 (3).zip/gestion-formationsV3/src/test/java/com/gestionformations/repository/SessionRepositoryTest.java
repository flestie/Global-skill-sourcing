package com.gestionformations.repository;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.gestionformations.data.Classe;
import com.gestionformations.data.Ecole;
import com.gestionformations.data.Format;
import com.gestionformations.data.Formateur;
import com.gestionformations.data.Formation;
import com.gestionformations.data.Session;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
class SessionRepositoryTest {

    @Autowired
    private SessionRepository sessionRepository;

    @Autowired
    private ClasseRepository classeRepository;

    @Autowired
    private EcoleRepository ecoleRepository;

    @Autowired
    private FormationRepository formationRepository;

    @Autowired
    private FormateurRepository formateurRepository;

    @Test
    void testCreateSession() {
        // ---------- Préparation : créer les dépendances -----------------
        Ecole ecole = ecoleRepository.save(new Ecole("Université de Paris"));

        Formation formation = formationRepository.save(
            new Formation("Python Avancé", 45, "Apprentissage complet de Python", 20, Format.DISTANCIEL)
        );

        Formateur formateur = formateurRepository.save(
            new Formateur("Durand", "Paul", "paul.durand@test.com", "0601020304", "Paris", "75000")
        );

        Classe classe = new Classe("Classe A", 20, "Salle 101");
        classe.setEcole(ecole);
        classe.setFormation(formation);
        classe.setFormateur(formateur);
        classe = classeRepository.save(classe);

        // ---------- Création de la Session -----------------
        Session session = new Session(
            "Session Python Débutant",
            "09:00-12:00, 13:00-17:00",
            LocalDate.of(2025, 9, 15),  // date début cours
            LocalDate.of(2025, 9, 20),  // date fin cours
            LocalDate.of(2025, 9, 22),  // date début stage
            LocalDate.of(2025, 9, 26)   // date fin stage
        );
        session.setClasse(classe); // 🔴 obligatoire !

        // ---------- Action ----------------------
        Session newSession = sessionRepository.save(session);

        // ---------- Vérifications ---------------
        assertNotNull(newSession.getId(), "L'ID doit être généré");
        assertEquals("Session Python Débutant", newSession.getNom(), "Le nom doit correspondre");
        assertEquals(classe.getId(), newSession.getClasse().getId(), "La session doit être rattachée à la classe");
    }
}
