package com.gestionformations.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.gestionformations.data.Classe;
import com.gestionformations.dto.ClasseDTO;
import com.gestionformations.dto.CreateClasseDTO;
import com.gestionformations.repository.ClasseRepository;

@ExtendWith(MockitoExtension.class)
class ClasseServiceTest {

    @Mock
    private ClasseRepository classeRepository;

    @InjectMocks
    private ClasseService classeService;

    @Test
    void shouldConvertClasseToDTO() {
        // Given
        Classe classe = new Classe("Classe Java", 15, "Salle 101");
        
        when(classeRepository.findById(1L)).thenReturn(Optional.of(classe));

        // When
        ClasseDTO result = classeService.getClasseByIdDTO(1L);

        // Then
        assertNotNull(result);
        assertEquals("Classe Java", result.getNom());
        assertEquals(15, result.getNbParticipants());
        assertEquals("Salle 101", result.getLieu());
    }

    @Test
    void shouldCreateClasseFromDTO() {
        // Given
        CreateClasseDTO createDTO = new CreateClasseDTO("Classe Python", 20, "Salle 202", 1L, 1L, 1L);
        
        Classe savedClasse = new Classe("Classe Python", 20, "Salle 202");
        
        when(classeRepository.save(any(Classe.class))).thenReturn(savedClasse);

        // When
        ClasseDTO result = classeService.createClasseDTO(createDTO);

        // Then
        assertNotNull(result);
        assertEquals("Classe Python", result.getNom());
        assertEquals(20, result.getNbParticipants());
        assertEquals("Salle 202", result.getLieu());
        verify(classeRepository, times(1)).save(any(Classe.class));
    }

    @Test
    void shouldReturnNullWhenClasseNotFound() {
        // Given
        when(classeRepository.findById(999L)).thenReturn(Optional.empty());

        // When
        ClasseDTO result = classeService.getClasseByIdDTO(999L);

        // Then
        assertNull(result);
    }
}