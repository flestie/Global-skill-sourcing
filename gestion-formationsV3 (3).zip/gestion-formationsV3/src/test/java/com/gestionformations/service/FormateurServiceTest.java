package com.gestionformations.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.gestionformations.data.Formateur;
import com.gestionformations.dto.FormateurDTO;
import com.gestionformations.dto.CreateFormateurDTO;
import com.gestionformations.repository.FormateurRepository;

@ExtendWith(MockitoExtension.class)
class FormateurServiceTest {

    @Mock
    private FormateurRepository formateurRepository;

    @InjectMocks
    private FormateurService formateurService;

    @Test
    void shouldConvertFormateurToDTO() {
        // Given
        Formateur formateur = new Formateur("Dupont", "Jean", "jean@test.com", 
                                           "0601020304", "Paris", "75001");
        
        when(formateurRepository.findById(1L)).thenReturn(Optional.of(formateur));

        // When
        FormateurDTO result = formateurService.getFormateurByIdDTO(1L);

        // Then
        assertNotNull(result);
        assertEquals("Dupont", result.getNom());
        assertEquals("Jean", result.getPrenom());
        assertEquals("jean@test.com", result.getEmail());
        assertEquals("0601020304", result.getTelephone());
        assertEquals("Paris", result.getVille());
        assertEquals("75001", result.getCodePostal());
    }

    @Test
    void shouldReturnNullWhenFormateurNotFound() {
        // Given
        when(formateurRepository.findById(999L)).thenReturn(Optional.empty());

        // When
        FormateurDTO result = formateurService.getFormateurByIdDTO(999L);

        // Then
        assertNull(result);
    }

    @Test
    void shouldCreateFormateurFromDTO() {
        // Given
        CreateFormateurDTO createDTO = new CreateFormateurDTO("Martin", "Sophie", 
                                                             "sophie@test.com", "0605060708", 
                                                             "Lyon", "69000");
        
        Formateur savedFormateur = new Formateur("Martin", "Sophie", "sophie@test.com", 
                                                "0605060708", "Lyon", "69000");
        
        when(formateurRepository.save(any(Formateur.class))).thenReturn(savedFormateur);

        // When
        FormateurDTO result = formateurService.createFormateurDTO(createDTO);

        // Then
        assertNotNull(result);
        assertEquals("Martin", result.getNom());
        assertEquals("Sophie", result.getPrenom());
        assertEquals("sophie@test.com", result.getEmail());
        verify(formateurRepository, times(1)).save(any(Formateur.class));
    }

    @Test
    void shouldPassCorrectDataToRepository() {
        // Given
        CreateFormateurDTO createDTO = new CreateFormateurDTO("Martin", "Sophie", 
                                                             "sophie@test.com", "0605060708", 
                                                             "Lyon", "69000");
        
        Formateur capturedFormateur = new Formateur("Martin", "Sophie", "sophie@test.com", 
                                                   "0605060708", "Lyon", "69000");
        
        when(formateurRepository.save(any(Formateur.class))).thenReturn(capturedFormateur);

        // When
        formateurService.createFormateurDTO(createDTO);

        // Then
        verify(formateurRepository).save(argThat(formateur -> 
            formateur.getNom().equals("Martin") &&
            formateur.getPrenom().equals("Sophie") &&
            formateur.getEmail().equals("sophie@test.com")
        ));
    }
}