package com.gestionformations.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.gestionformations.data.Formation;
import com.gestionformations.data.Format;
import com.gestionformations.dto.FormationDTO;
import com.gestionformations.repository.FormationRepository;

@ExtendWith(MockitoExtension.class)
class FormationServiceTest {

    @Mock
    private FormationRepository formationRepository;

    @InjectMocks
    private FormationService formationService;

    @Test
    void shouldConvertFormationToDTO() {
        // Given
        Formation formation = new Formation("Spring Boot", 50, "Apprendre Spring", 25, Format.PRESENTIEL);
        
        when(formationRepository.findById(1L)).thenReturn(Optional.of(formation));

        // When
        FormationDTO result = formationService.getFormationByIdDTO(1L);

        // Then
        assertNotNull(result);
        assertEquals("Spring Boot", result.getNom());
        assertEquals(50, result.getDuree());
        assertEquals("Apprendre Spring", result.getObjectifs());
        assertEquals(25, result.getNbParticipantsMax());
        assertEquals("PRESENTIEL", result.getFormat());
    }

    @Test
    void shouldCreateFormationFromDTO() {
        // Given
        FormationDTO formationDTO = new FormationDTO(null, "Java", 40, "Apprendre Java", 20, "DISTANCIEL");
        
        Formation savedFormation = new Formation("Java", 40, "Apprendre Java", 20, Format.DISTANCIEL);
        
        when(formationRepository.save(any(Formation.class))).thenReturn(savedFormation);

        // When
        FormationDTO result = formationService.createFormationDTO(formationDTO);

        // Then
        assertNotNull(result);
        assertEquals("Java", result.getNom());
        assertEquals(40, result.getDuree());
        assertEquals("Apprendre Java", result.getObjectifs());
        verify(formationRepository, times(1)).save(any(Formation.class));
    }

    @Test
    void shouldReturnNullWhenFormationNotFound() {
        // Given
        when(formationRepository.findById(999L)).thenReturn(Optional.empty());

        // When
        FormationDTO result = formationService.getFormationByIdDTO(999L);

        // Then
        assertNull(result);
    }
}